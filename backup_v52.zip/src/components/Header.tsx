'use client';

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Globe, LogOut, Key, User, ChevronDown, LayoutDashboard } from 'lucide-react';

export default function Header() {
  const router = useRouter();
  const [lang, setLang] = useState('ES');
  const [showLangMenu, setShowLangMenu] = useState(false);
  const [userName, setUserName] = useState('Usuario');

  useEffect(() => {
    const name = document.cookie
      .split('; ')
      .find(row => row.startsWith('user_name='))
      ?.split('=')[1];
    if (name) setUserName(decodeURIComponent(name));
  }, []);

  const handleLogout = async () => {
    await fetch('/api/auth/login', { method: 'DELETE' });
    router.push('/login');
  };

  return (
    <header className="glass" style={{
      width: '94%',
      margin: '20px 3%',
      padding: '16px 32px',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      position: 'fixed',
      top: 0,
      left: 0,
      zIndex: 1000,
      borderRadius: '20px',
      border: '1px solid rgba(255, 255, 255, 0.1)'
    }}>
      {/* Left: Crosti Logo */}
      <div 
        onClick={() => router.push('/')}
        style={{ 
          display: 'flex', 
          alignItems: 'center', 
          gap: '16px', 
          cursor: 'pointer',
          transition: 'var(--transition-smooth)'
        }}
        onMouseOver={(e) => (e.currentTarget.style.transform = 'scale(1.02)')}
        onMouseOut={(e) => (e.currentTarget.style.transform = 'scale(1)')}
      >
        <div style={{ position: 'relative' }}>
          <img 
            src="/logo-crosti.jpg" 
            alt="Crosti Logo" 
            style={{ 
              height: '48px', 
              borderRadius: '12px', 
              boxShadow: '0 8px 16px rgba(0,0,0,0.2)' 
            }} 
          />
          <div style={{
            position: 'absolute',
            bottom: '-4px',
            right: '-4px',
            width: '14px',
            height: '14px',
            backgroundColor: '#10B981',
            borderRadius: '50%',
            border: '2px solid var(--primary-red)',
            boxShadow: '0 0 10px rgba(16, 185, 129, 0.5)'
          }} />
        </div>
        <div style={{ display: 'flex', flexDirection: 'column' }}>
          <span style={{ 
            fontSize: '20px', 
            fontWeight: '900', 
            color: 'var(--text-white)',
            letterSpacing: '-0.5px',
            lineHeight: '1'
          }}>
            CROSTI HUB
          </span>
          <span style={{ 
            fontSize: '10px', 
            fontWeight: '600', 
            color: 'var(--accent-yellow)',
            letterSpacing: '1.5px',
            textTransform: 'uppercase',
            marginTop: '4px'
          }}>
            Management Suite
          </span>
        </div>
      </div>

      {/* Right: Actions & Info */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '24px' }}>
        {/* BakeOS Badge */}
        <div className="glass" style={{
          display: 'flex',
          alignItems: 'center',
          gap: '8px',
          padding: '8px 16px',
          borderRadius: '12px',
          backgroundColor: 'rgba(249, 115, 22, 0.15)',
          color: '#F97316',
          fontSize: '11px',
          fontWeight: '800',
          letterSpacing: '0.5px',
          border: '1px solid rgba(249, 115, 22, 0.3)'
        }}>
          <div style={{ width: '8px', height: '8px', borderRadius: '50%', backgroundColor: '#F97316', animation: 'pulse-glow 2s infinite' }} />
          BAKEOS POWERED
        </div>

        <div style={{ width: '1px', height: '32px', backgroundColor: 'rgba(255, 255, 255, 0.1)' }} />

        {/* Language Selector */}
        <div style={{ position: 'relative' }}>
          <button 
            onClick={() => setShowLangMenu(!showLangMenu)}
            style={{
              backgroundColor: 'transparent',
              border: 'none',
              color: 'var(--text-white)',
              padding: '8px',
              borderRadius: '10px',
              fontSize: '13px',
              fontWeight: '700',
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              cursor: 'pointer',
              transition: 'var(--transition-smooth)'
            }}
            onMouseOver={(e) => (e.currentTarget.style.backgroundColor = 'rgba(255,255,255,0.1)')}
            onMouseOut={(e) => (e.currentTarget.style.backgroundColor = 'transparent')}
          >
            <Globe size={18} strokeWidth={2.5} />
            <span style={{ opacity: 0.9 }}>{lang}</span>
            <ChevronDown size={14} strokeWidth={3} style={{ opacity: 0.5 }} />
          </button>
          
          {showLangMenu && (
            <div className="glass" style={{
              position: 'absolute',
              top: '50px',
              right: 0,
              borderRadius: '16px',
              overflow: 'hidden',
              minWidth: '140px',
              padding: '8px'
            }}>
              {['ES', 'EN'].map((l) => (
                <div 
                  key={l}
                  onClick={() => { setLang(l); setShowLangMenu(false); }}
                  style={{ 
                    padding: '10px 16px', 
                    color: 'var(--text-white)', 
                    fontSize: '13px', 
                    fontWeight: '600', 
                    cursor: 'pointer', 
                    borderRadius: '8px',
                    backgroundColor: lang === l ? 'rgba(255,255,255,0.1)' : 'transparent',
                    transition: 'var(--transition-smooth)'
                  }}
                  onMouseOver={(e) => (e.currentTarget.style.backgroundColor = 'rgba(255,255,255,0.15)')}
                  onMouseOut={(e) => (e.currentTarget.style.backgroundColor = lang === l ? 'rgba(255,255,255,0.1)' : 'transparent')}
                >
                  {l === 'ES' ? 'Español' : 'English'}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* User Info */}
        <div style={{ 
          display: 'flex', 
          alignItems: 'center', 
          gap: '12px', 
          paddingLeft: '12px',
          borderLeft: '1px solid rgba(255, 255, 255, 0.1)'
        }}>
          <div style={{ textAlign: 'right', display: 'flex', flexDirection: 'column' }}>
            <span style={{ fontSize: '13px', fontWeight: '700', color: 'var(--text-white)' }}>{userName}</span>
            <span style={{ fontSize: '10px', fontWeight: '500', color: 'var(--text-dim)' }}>Superadmin</span>
          </div>
          <div style={{ 
            width: '40px', 
            height: '40px', 
            borderRadius: '12px', 
            backgroundColor: 'rgba(255, 255, 255, 0.1)', 
            display: 'flex', 
            alignItems: 'center', 
            justifyContent: 'center',
            border: '1px solid rgba(255, 255, 255, 0.1)'
          }}>
            <User size={20} strokeWidth={2} />
          </div>
        </div>

        <button 
          onClick={handleLogout}
          title="Cerrar Sesión"
          style={{ 
            backgroundColor: 'rgba(239, 68, 68, 0.1)', 
            border: '1px solid rgba(239, 68, 68, 0.2)', 
            color: '#EF4444', 
            padding: '10px',
            borderRadius: '12px',
            cursor: 'pointer', 
            transition: 'var(--transition-smooth)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center'
          }}
          onMouseOver={(e) => {
            e.currentTarget.style.backgroundColor = '#EF4444';
            e.currentTarget.style.color = 'white';
            e.currentTarget.style.transform = 'translateY(-2px)';
          }}
          onMouseOut={(e) => {
            e.currentTarget.style.backgroundColor = 'rgba(239, 68, 68, 0.1)';
            e.currentTarget.style.color = '#EF4444';
            e.currentTarget.style.transform = 'translateY(0)';
          }}
        >
          <LogOut size={18} strokeWidth={2.5} />
        </button>
      </div>
    </header>
  );
}
