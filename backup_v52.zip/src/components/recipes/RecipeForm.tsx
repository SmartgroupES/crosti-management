'use client';

import React, { useState } from 'react';
import { Plus, Trash2, Save, X, ChefHat } from 'lucide-react';

interface Ingredient {
  ingredient_name: string;
  is_sub_recipe: boolean;
  unit: string;
  quantity_dirty: number;
  quantity_clean: number;
  cost_dirty: number;
  cost_clean: number;
}

interface RecipeFormProps {
  onClose: () => void;
  onSuccess: () => void;
}

export default function RecipeForm({ onClose, onSuccess }: RecipeFormProps) {
  const [name, setName] = useState('');
  const [microsId, setMicrosId] = useState('');
  const [ingredients, setIngredients] = useState<Ingredient[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const addIngredient = () => {
    setIngredients([...ingredients, {
      ingredient_name: '',
      is_sub_recipe: false,
      unit: '',
      quantity_dirty: 0,
      quantity_clean: 0,
      cost_dirty: 0,
      cost_clean: 0
    }]);
  };

  const removeIngredient = (index: number) => {
    setIngredients(ingredients.filter((_, i) => i !== index));
  };

  const updateIngredient = (index: number, field: keyof Ingredient, value: any) => {
    const newIngredients = [...ingredients];
    newIngredients[index] = { ...newIngredients[index], [field]: value };
    setIngredients(newIngredients);
  };

  const calculateTotalCost = () => {
    return ingredients.reduce((sum, ing) => sum + (Number(ing.cost_dirty) || 0), 0);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const response = await fetch('/api/recetas', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name,
          micros_id: microsId,
          total_cost: calculateTotalCost(),
          ingredients
        }),
      });

      if (response.ok) {
        onSuccess();
        onClose();
      } else {
        alert('Error al guardar la receta');
      }
    } catch (error) {
      console.error('Error:', error);
      alert('Error de conexión');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div style={{
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      backgroundColor: 'rgba(0,0,0,0.5)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      zIndex: 1000,
      padding: '20px',
      backdropFilter: 'blur(4px)'
    }}>
      <div style={{
        backgroundColor: 'white',
        borderRadius: '24px',
        width: '100%',
        maxWidth: '1000px',
        maxHeight: '90vh',
        overflowY: 'auto',
        padding: '40px',
        boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.25)'
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '32px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <div style={{ backgroundColor: '#FEF3C7', padding: '10px', borderRadius: '12px' }}>
              <ChefHat size={24} color="#D97706" />
            </div>
            <h2 style={{ fontSize: '24px', fontWeight: 'bold', margin: 0 }}>Nueva Receta Manual</h2>
          </div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#9CA3AF' }}>
            <X size={24} />
          </button>
        </div>

        <form onSubmit={handleSubmit}>
          <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '20px', marginBottom: '32px' }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
              <label style={{ fontSize: '12px', fontWeight: 'bold', color: '#6B7280', textTransform: 'uppercase' }}>Nombre de la Receta</label>
              <input
                required
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Ej. AGUA DE FRESA"
                style={{ padding: '12px', borderRadius: '12px', border: '1px solid #E5E7EB', fontSize: '14px' }}
              />
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
              <label style={{ fontSize: '12px', fontWeight: 'bold', color: '#6B7280', textTransform: 'uppercase' }}>Micros ID</label>
              <input
                type="text"
                value={microsId}
                onChange={(e) => setMicrosId(e.target.value)}
                placeholder="Ej. 10810001"
                style={{ padding: '12px', borderRadius: '12px', border: '1px solid #E5E7EB', fontSize: '14px' }}
              />
            </div>
          </div>

          <div style={{ marginBottom: '20px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
              <h3 style={{ fontSize: '16px', fontWeight: 'bold', margin: 0 }}>Ingredientes</h3>
              <button
                type="button"
                onClick={addIngredient}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  backgroundColor: '#F0FDF4',
                  color: '#10B981',
                  border: '1px solid #10B981',
                  padding: '8px 16px',
                  borderRadius: '10px',
                  fontSize: '13px',
                  fontWeight: 'bold',
                  cursor: 'pointer'
                }}
              >
                <Plus size={16} /> Agregar Ingrediente
              </button>
            </div>

            <div style={{ overflowX: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '12px' }}>
                <thead>
                  <tr style={{ textAlign: 'left', borderBottom: '2px solid #F3F4F6' }}>
                    <th style={{ padding: '12px 8px' }}>NOMBRE</th>
                    <th style={{ padding: '12px 8px' }}>SUB</th>
                    <th style={{ padding: '12px 8px' }}>UNIDAD</th>
                    <th style={{ padding: '12px 8px' }}>CANT. SUCIA</th>
                    <th style={{ padding: '12px 8px' }}>CANT. LIMPIA</th>
                    <th style={{ padding: '12px 8px' }}>COSTO SUCIO</th>
                    <th style={{ padding: '12px 8px' }}>COSTO LIMPIO</th>
                    <th style={{ padding: '12px 8px' }}></th>
                  </tr>
                </thead>
                <tbody>
                  {ingredients.map((ing, index) => (
                    <tr key={index} style={{ borderBottom: '1px solid #F3F4F6' }}>
                      <td style={{ padding: '8px' }}>
                        <input
                          required
                          type="text"
                          value={ing.ingredient_name}
                          onChange={(e) => updateIngredient(index, 'ingredient_name', e.target.value)}
                          style={{ width: '100%', padding: '8px', borderRadius: '8px', border: '1px solid #E5E7EB' }}
                        />
                      </td>
                      <td style={{ padding: '8px' }}>
                        <select
                          value={ing.is_sub_recipe ? 'Sí' : 'No'}
                          onChange={(e) => updateIngredient(index, 'is_sub_recipe', e.target.value === 'Sí')}
                          style={{ padding: '8px', borderRadius: '8px', border: '1px solid #E5E7EB' }}
                        >
                          <option value="No">No</option>
                          <option value="Sí">Sí</option>
                        </select>
                      </td>
                      <td style={{ padding: '8px' }}>
                        <input
                          type="text"
                          value={ing.unit}
                          onChange={(e) => updateIngredient(index, 'unit', e.target.value)}
                          style={{ width: '80px', padding: '8px', borderRadius: '8px', border: '1px solid #E5E7EB' }}
                        />
                      </td>
                      <td style={{ padding: '8px' }}>
                        <input
                          type="number"
                          step="0.001"
                          value={ing.quantity_dirty}
                          onChange={(e) => updateIngredient(index, 'quantity_dirty', Number(e.target.value))}
                          style={{ width: '80px', padding: '8px', borderRadius: '8px', border: '1px solid #E5E7EB' }}
                        />
                      </td>
                      <td style={{ padding: '8px' }}>
                        <input
                          type="number"
                          step="0.001"
                          value={ing.quantity_clean}
                          onChange={(e) => updateIngredient(index, 'quantity_clean', Number(e.target.value))}
                          style={{ width: '80px', padding: '8px', borderRadius: '8px', border: '1px solid #E5E7EB' }}
                        />
                      </td>
                      <td style={{ padding: '8px' }}>
                        <input
                          type="number"
                          step="0.001"
                          value={ing.cost_dirty}
                          onChange={(e) => updateIngredient(index, 'cost_dirty', Number(e.target.value))}
                          style={{ width: '80px', padding: '8px', borderRadius: '8px', border: '1px solid #E5E7EB' }}
                        />
                      </td>
                      <td style={{ padding: '8px' }}>
                        <input
                          type="number"
                          step="0.001"
                          value={ing.cost_clean}
                          onChange={(e) => updateIngredient(index, 'cost_clean', Number(e.target.value))}
                          style={{ width: '80px', padding: '8px', borderRadius: '8px', border: '1px solid #E5E7EB' }}
                        />
                      </td>
                      <td style={{ padding: '8px' }}>
                        <button
                          type="button"
                          onClick={() => removeIngredient(index)}
                          style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#EF4444' }}
                        >
                          <Trash2 size={16} />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {ingredients.length === 0 && (
                <div style={{ textAlign: 'center', padding: '40px', color: '#9CA3AF', backgroundColor: '#F9FAFB', borderRadius: '12px', marginTop: '12px' }}>
                  No hay ingredientes. Haz clic en "Agregar Ingrediente".
                </div>
              )}
            </div>
          </div>

          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '40px', paddingTop: '24px', borderTop: '1px solid #F3F4F6' }}>
            <div style={{ fontSize: '18px', fontWeight: 'bold' }}>
              Costo Total Estimado: <span style={{ color: '#EF4444' }}>{calculateTotalCost().toFixed(3)} €</span>
            </div>
            <div style={{ display: 'flex', gap: '16px' }}>
              <button
                type="button"
                onClick={onClose}
                style={{
                  padding: '12px 24px',
                  borderRadius: '12px',
                  border: '1px solid #E5E7EB',
                  backgroundColor: 'white',
                  fontWeight: 'bold',
                  cursor: 'pointer'
                }}
              >
                Cancelar
              </button>
              <button
                disabled={isSubmitting || ingredients.length === 0}
                type="submit"
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  padding: '12px 32px',
                  borderRadius: '12px',
                  backgroundColor: '#1A1A1A',
                  color: 'white',
                  border: 'none',
                  fontWeight: 'bold',
                  cursor: (isSubmitting || ingredients.length === 0) ? 'not-allowed' : 'pointer',
                  opacity: (isSubmitting || ingredients.length === 0) ? 0.7 : 1
                }}
              >
                {isSubmitting ? 'Guardando...' : <><Save size={18} /> Guardar Receta</>}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}
