'use client';

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Loader2, Lock, User } from 'lucide-react';

export default function LoginPage() {
  const router = useRouter();
  const [login, setLogin] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [isExiting, setIsExiting] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify({ login, password }),
        headers: { 'Content-Type': 'application/json' }
      });

      const data = await res.json();
      if (data.success) {
        setIsExiting(true);
        setTimeout(() => {
          router.push('/');
        }, 800); // Wait for transition
      } else {
        setError(data.error || 'Acceso denegado');
      }
    } catch (err) {
      setError('Error al conectar con el servidor');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{
      backgroundColor: '#801515', // Rojo Borgoña corporativo
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontFamily: 'var(--font-outfit), system-ui, -apple-system, sans-serif',
      padding: '24px',
      transition: 'opacity 0.8s ease-in-out',
      opacity: isExiting ? 0 : 1
    }}>
      <div className="fade-in" style={{
        backgroundColor: '#FFFFFF',
        width: '100%',
        maxWidth: '420px',
        padding: '64px 48px',
        borderRadius: '48px', // Bordes muy redondeados
        boxShadow: '0 30px 60px rgba(0,0,0,0.3)',
        textAlign: 'center',
        transform: isExiting ? 'scale(1.05)' : 'scale(1)',
        transition: 'all 0.8s cubic-bezier(0.4, 0, 0.2, 1)'
      }}>
        <div style={{ marginBottom: '48px' }}>
          <img 
            src="/logo-crosti.jpg" 
            alt="Crosti Logo" 
            style={{ 
              height: '84px', 
              borderRadius: '20px', 
              marginBottom: '32px',
              boxShadow: '0 12px 24px rgba(0,0,0,0.08)' 
            }} 
          />
          <h1 style={{ 
            fontSize: '26px', 
            fontWeight: '900', 
            margin: '0', 
            color: '#1A1A1A', 
            letterSpacing: '-0.5px' 
          }}>
            Acceso Superadministrador
          </h1>
        </div>

        <form onSubmit={handleLogin} style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          <div style={{ position: 'relative' }}>
            <User size={18} strokeWidth={2} style={{ position: 'absolute', left: '20px', top: '50%', transform: 'translateY(-50%)', color: '#9CA3AF' }} />
            <input
              type="text"
              placeholder="Usuario"
              value={login}
              onChange={(e) => setLogin(e.target.value)}
              required
              style={{
                width: '100%',
                padding: '18px 18px 18px 52px',
                fontSize: '15px',
                borderRadius: '18px',
                border: '1px solid #F3F4F6',
                backgroundColor: '#F9FAFB',
                boxSizing: 'border-box',
                outline: 'none',
                transition: 'all 0.2s',
                fontWeight: '600',
                color: '#111827'
              }}
              onFocus={(e) => {
                e.currentTarget.style.borderColor = '#801515';
                e.currentTarget.style.backgroundColor = '#FFFFFF';
                e.currentTarget.style.boxShadow = '0 0 0 4px rgba(128, 21, 21, 0.1)';
              }}
              onBlur={(e) => {
                e.currentTarget.style.borderColor = '#F3F4F6';
                e.currentTarget.style.backgroundColor = '#F9FAFB';
                e.currentTarget.style.boxShadow = 'none';
              }}
            />
          </div>

          <div style={{ position: 'relative' }}>
            <Lock size={18} strokeWidth={2} style={{ position: 'absolute', left: '20px', top: '50%', transform: 'translateY(-50%)', color: '#9CA3AF' }} />
            <input
              type="password"
              placeholder="Contraseña"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              style={{
                width: '100%',
                padding: '18px 18px 18px 52px',
                fontSize: '15px',
                borderRadius: '18px',
                border: '1px solid #F3F4F6',
                backgroundColor: '#F9FAFB',
                boxSizing: 'border-box',
                outline: 'none',
                transition: 'all 0.2s',
                fontWeight: '600',
                color: '#111827'
              }}
              onFocus={(e) => {
                e.currentTarget.style.borderColor = '#801515';
                e.currentTarget.style.backgroundColor = '#FFFFFF';
                e.currentTarget.style.boxShadow = '0 0 0 4px rgba(128, 21, 21, 0.1)';
              }}
              onBlur={(e) => {
                e.currentTarget.style.borderColor = '#F3F4F6';
                e.currentTarget.style.backgroundColor = '#F9FAFB';
                e.currentTarget.style.boxShadow = 'none';
              }}
            />
          </div>

          {error && (
            <div className="fade-in" style={{ 
              color: '#B91C1C', 
              fontSize: '13px', 
              fontWeight: '700', 
              backgroundColor: '#FEF2F2', 
              padding: '14px', 
              borderRadius: '14px',
              border: '1px solid #FEE2E2'
            }}>
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading || isExiting}
            style={{
              width: '100%',
              padding: '18px',
              fontSize: '16px',
              fontWeight: '800',
              borderRadius: '18px',
              border: 'none',
              backgroundColor: '#801515', // Rojo Borgoña
              color: 'white',
              cursor: (loading || isExiting) ? 'not-allowed' : 'pointer',
              transition: 'all 0.3s ease',
              boxShadow: '0 8px 24px rgba(128, 21, 21, 0.25)',
              marginTop: '12px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '10px'
            }}
            onMouseOver={(e) => {
              if (!loading && !isExiting) {
                e.currentTarget.style.transform = 'translateY(-2px)';
                e.currentTarget.style.boxShadow = '0 12px 28px rgba(128, 21, 21, 0.35)';
                e.currentTarget.style.backgroundColor = '#991B1B';
              }
            }}
            onMouseOut={(e) => {
              if (!loading && !isExiting) {
                e.currentTarget.style.transform = 'translateY(0)';
                e.currentTarget.style.boxShadow = '0 8px 24px rgba(128, 21, 21, 0.25)';
                e.currentTarget.style.backgroundColor = '#801515';
              }
            }}
          >
            {loading ? <Loader2 className="animate-spin" size={20} /> : 'Entrar al Sistema'}
          </button>
        </form>

        <div style={{ 
          marginTop: '48px', 
          fontSize: '12px', 
          color: '#9CA3AF', 
          fontWeight: '500',
          letterSpacing: '0.02em'
        }}>
          &copy; 2026 Crosti Management.
        </div>
      </div>

      <style jsx global>{`
        @keyframes fade-in {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .fade-in {
          animation: fade-in 0.6s ease-out forwards;
        }
      `}</style>
    </div>
  );
}
