'use client';

import React, { useState, useEffect, useRef } from 'react';
import { TrendingUp, Zap, Clock, DollarSign, ShoppingCart, Loader2, RefreshCcw, Upload, BarChart3, ChevronRight } from 'lucide-react';

interface SalesStats {
  hourly: { hour: number; total_amount: number; total_items: number }[];
  kpis: {
    totalRevenue: number;
    totalUnits: number;
    totalTransactions: number;
    avgTicket: number;
  };
  weekly: { week: string; revenue: number }[];
  topProducts: { product_name: string; units: number; revenue: number }[];
  recentTransactions: { id: number; sale_date: string; product_name: string; quantity: number; total_amount: number; location: string }[];
  heatmap: { day_of_week: number; hour: number; total_sales: number }[];
  error?: string;
}

export default function VentasPage() {
  const [data, setData] = useState<SalesStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const fetchData = () => {
    setLoading(true);
    setError(null);
    fetch('/api/sales/hourly')
      .then(res => res.json())
      .then(d => {
        if (d.error) setError(d.error);
        else setData(d);
        setLoading(false);
      })
      .catch(err => {
        console.error("Error loading sales stats:", err);
        setError("Fallo al conectar con el servidor");
        setLoading(false);
      });
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    const formData = new FormData();
    formData.append('file', file);

    try {
      const res = await fetch('/api/sales/upload', {
        method: 'POST',
        body: formData,
      });
      const result = await res.json();
      if (result.success) {
        alert(result.message);
        fetchData();
      } else {
        alert(result.error);
      }
    } catch (err) {
      alert("Error al subir el archivo");
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  if (loading) {
    return (
      <div style={{ height: '80vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: '24px' }}>
        <Loader2 className="animate-spin" size={48} color="#F97316" />
        <p style={{ color: '#666', fontWeight: '600', fontSize: '18px' }}>Sincronizando datos de Crosti...</p>
      </div>
    );
  }

  const hourlyData = data?.hourly || [];
  const maxHourly = hourlyData.length ? Math.max(...hourlyData.map(h => h.total_amount)) : 0;
  const hourlyBars = Array.from({ length: 15 }, (_, i) => {
    const hour = i + 8;
    const found = hourlyData.find(h => h.hour === hour);
    return { hour, amount: found?.total_amount || 0 };
  });

  const kpis = [
    { label: 'Ingresos Totales', value: `${(data?.kpis?.totalRevenue || 0).toLocaleString('de-DE', { minimumFractionDigits: 2 })}€`, icon: <TrendingUp size={20} />, color: '#10B981' },
    { label: 'Ticket Medio', value: `${(data?.kpis?.avgTicket || 0).toFixed(2)}€`, icon: <DollarSign size={20} />, color: '#F97316' },
    { label: 'Unidades', value: (data?.kpis?.totalUnits || 0).toLocaleString(), icon: <ShoppingCart size={20} />, color: '#3B82F6' },
    { label: 'Hora Punta', value: hourlyData.length ? `${hourlyData.reduce((max, curr) => curr.total_amount > max.total_amount ? curr : max).hour}:00` : '--', icon: <Clock size={20} />, color: '#8B5CF6' },
  ];

  // Heatmap helper
  const days = ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'];
  const hours = Array.from({ length: 15 }, (_, i) => i + 8);
  const maxHeat = data?.heatmap?.length ? Math.max(...data.heatmap.map(d => d.total_sales)) : 0;

  const getHeatColor = (val: number) => {
    if (val === 0) return '#F9FAFB';
    const intensity = val / maxHeat;
    if (intensity > 0.8) return '#1A1A1A';
    if (intensity > 0.5) return '#F97316';
    if (intensity > 0.2) return '#FB923C';
    return '#FFEDD5';
  };

  return (
    <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '40px 20px', fontFamily: 'system-ui, -apple-system, sans-serif' }}>
      {/* Header: Logo & Identity */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '60px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '20px' }}>
          <button 
            onClick={() => window.location.href = '/'}
            style={{ 
              backgroundColor: '#F3F4F6', 
              border: 'none', 
              width: '44px', 
              height: '44px', 
              borderRadius: '12px', 
              display: 'flex', 
              alignItems: 'center', 
              justifyContent: 'center', 
              cursor: 'pointer',
              color: '#1A1A1A',
              transition: 'all 0.2s'
            }}>
            <ChevronRight style={{ transform: 'rotate(180deg)' }} size={20} />
          </button>
          <div style={{ width: '64px', height: '64px', backgroundColor: 'transparent', borderRadius: '18px', display: 'flex', alignItems: 'center', justifyContent: 'center', overflow: 'hidden' }}>
             <img src="/logo-crosti.jpg" alt="Crosti Logo" style={{ width: '100%', height: '100%', objectFit: 'contain' }} />
          </div>
          <div>
            <h1 style={{ fontSize: '24px', fontWeight: '900', margin: 0, color: '#1A1A1A', letterSpacing: '-0.5px' }}>Dashboard de Ventas</h1>
            <p style={{ fontSize: '14px', color: '#6B7280', margin: '4px 0 0 0', fontWeight: '500' }}>Análisis de rendimiento Crosti</p>
          </div>
        </div>
        
        <div style={{ display: 'flex', gap: '12px' }}>
          <input type="file" ref={fileInputRef} onChange={handleFileUpload} accept=".xlsx,.xls" style={{ display: 'none' }} />
          <button 
            onClick={() => fileInputRef.current?.click()}
            disabled={uploading}
            style={{ 
              backgroundColor: '#F3F4F6', 
              color: '#1A1A1A', 
              border: 'none', 
              padding: '12px 20px', 
              borderRadius: '12px', 
              fontSize: '13px', 
              fontWeight: '700', 
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              transition: 'all 0.2s'
            }}>
            {uploading ? <Loader2 className="animate-spin" size={16} /> : <Upload size={16} />}
            Importar Excel
          </button>
          <button style={{ backgroundColor: '#1A1A1A', color: 'white', border: 'none', padding: '12px 20px', borderRadius: '12px', fontSize: '13px', fontWeight: '700', cursor: 'pointer', boxShadow: '0 4px 6px -1px rgba(0,0,0,0.1)' }}>
            Reporte PDF
          </button>
        </div>
      </div>

      {/* KPI Section */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '24px', marginBottom: '48px' }}>
        {kpis.map((kpi, i) => (
          <div key={i} style={{ backgroundColor: 'white', padding: '30px', borderRadius: '24px', border: '1px solid #F3F4F6', boxShadow: '0 1px 2px 0 rgba(0,0,0,0.05)' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '16px' }}>
              <div style={{ padding: '10px', borderRadius: '12px', backgroundColor: `${kpi.color}15`, color: kpi.color }}>{kpi.icon}</div>
              <span style={{ fontSize: '12px', fontWeight: '700', color: '#9CA3AF', textTransform: 'uppercase', letterSpacing: '0.5px' }}>{kpi.label}</span>
            </div>
            <div style={{ fontSize: '32px', fontWeight: '900', color: '#1A1A1A' }}>{kpi.value}</div>
          </div>
        ))}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 340px', gap: '32px', marginBottom: '40px' }}>
        {/* Main Chart Card */}
        <div style={{ backgroundColor: 'white', padding: '40px', borderRadius: '32px', border: '1px solid #F3F4F6', boxShadow: '0 4px 6px -1px rgba(0,0,0,0.05)' }}>
          <div style={{ marginBottom: '40px' }}>
            <h2 style={{ fontSize: '20px', fontWeight: '800', margin: 0 }}>Rendimiento Horario</h2>
            <p style={{ fontSize: '14px', color: '#9CA3AF', marginTop: '4px' }}>Volumen de ingresos acumulados por franja</p>
          </div>

          <div style={{ height: '320px', display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', gap: '12px', paddingBottom: '30px', position: 'relative' }}>
            {[0, 0.5, 1].map((p, i) => (
              <div key={i} style={{ position: 'absolute', bottom: `${p * 100}%`, width: '100%', borderTop: '1px solid #F9FAFB', zIndex: 0 }} />
            ))}

            {hourlyBars.map((bar, i) => (
              <div key={i} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '16px', zIndex: 1 }}>
                <div 
                  style={{ 
                    width: '100%', 
                    height: `${maxHourly > 0 ? (bar.amount / maxHourly) * 260 : 0}px`, 
                    backgroundColor: bar.amount === maxHourly && maxHourly > 0 ? '#1A1A1A' : '#F97316', 
                    borderRadius: '10px 10px 4px 4px',
                    transition: 'height 1s cubic-bezier(0.4, 0, 0.2, 1)',
                    position: 'relative'
                  }}
                >
                  {bar.amount > 0 && (
                    <div style={{ position: 'absolute', top: '-28px', width: '100%', textAlign: 'center', fontSize: '11px', fontWeight: '800', color: '#1A1A1A' }}>
                      {Math.round(bar.amount)}€
                    </div>
                  )}
                </div>
                <span style={{ fontSize: '12px', color: '#9CA3AF', fontWeight: '700' }}>{bar.hour}h</span>
              </div>
            ))}
          </div>
        </div>

        {/* Top Products Card */}
        <div style={{ backgroundColor: '#FAFAFA', padding: '40px', borderRadius: '32px', border: '1px solid #F3F4F6' }}>
          <h2 style={{ fontSize: '18px', fontWeight: '800', marginBottom: '32px', display: 'flex', alignItems: 'center', gap: '10px' }}>
            <BarChart3 size={20} /> Ranking Ventas
          </h2>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
            {(data?.topProducts || []).map((p, i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'center', gap: '16px', padding: '16px', backgroundColor: 'white', borderRadius: '20px', boxShadow: '0 1px 3px rgba(0,0,0,0.05)' }}>
                <div style={{ fontSize: '14px', fontWeight: '900', color: '#F97316', minWidth: '24px' }}>#{i + 1}</div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: '14px', fontWeight: '700', color: '#1A1A1A', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{p.product_name}</div>
                  <div style={{ fontSize: '12px', color: '#9CA3AF', fontWeight: '600' }}>{p.units} unidades</div>
                </div>
                <div style={{ fontSize: '14px', fontWeight: '800' }}>{Math.round(p.revenue)}€</div>
              </div>
            ))}
            {!(data?.topProducts || []).length && <p style={{ textAlign: 'center', color: '#9CA3AF', padding: '40px 0' }}>Sin datos disponibles</p>}
          </div>
        </div>
      </div>

      {/* HEATMAP SECTION */}
      <div style={{ backgroundColor: 'white', padding: '40px', borderRadius: '32px', border: '1px solid #F3F4F6', boxShadow: '0 4px 6px -1px rgba(0,0,0,0.05)', marginBottom: '60px' }}>
        <div style={{ marginBottom: '40px' }}>
          <h2 style={{ fontSize: '20px', fontWeight: '800', margin: 0 }}>Mapa de Calor de Ventas</h2>
          <p style={{ fontSize: '14px', color: '#9CA3AF', marginTop: '4px' }}>Distribución de ingresos por día y hora</p>
        </div>

        <div style={{ display: 'flex', gap: '10px' }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '4px', paddingTop: '32px' }}>
             {hours.map(h => (
               <div key={h} style={{ height: '32px', display: 'flex', alignItems: 'center', justifyContent: 'flex-end', fontSize: '11px', color: '#9CA3AF', fontWeight: '700', paddingRight: '10px' }}>
                 {h}:00
               </div>
             ))}
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ display: 'grid', gridTemplateColumns: `repeat(${days.length}, 1fr)`, gap: '4px', marginBottom: '10px' }}>
              {days.map(d => (
                <div key={d} style={{ textAlign: 'center', fontSize: '12px', fontWeight: '800', color: '#1A1A1A' }}>{d}</div>
              ))}
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: `repeat(${days.length}, 1fr)`, gap: '4px' }}>
              {hours.map(h => (
                <React.Fragment key={h}>
                  {[0, 1, 2, 3, 4, 5, 6].map(d => {
                    const cell = data?.heatmap?.find(item => item.day_of_week === d && item.hour === h);
                    const val = cell?.total_sales || 0;
                    return (
                      <div 
                        key={`${d}-${h}`} 
                        title={`${days[d]} ${h}:00 - ${val.toFixed(2)}€`}
                        style={{ 
                          height: '32px', 
                          backgroundColor: getHeatColor(val), 
                          borderRadius: '4px', 
                          transition: 'all 0.3s' 
                        }} 
                      />
                    );
                  })}
                </React.Fragment>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* DETALLE DEL EXCEL (Transaction Table) */}
      <div style={{ backgroundColor: 'white', padding: '40px', borderRadius: '32px', border: '1px solid #F3F4F6', boxShadow: '0 4px 6px -1px rgba(0,0,0,0.05)' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '32px' }}>
          <div>
            <h2 style={{ fontSize: '20px', fontWeight: '800', margin: 0 }}>Detalle de Transacciones</h2>
            <p style={{ fontSize: '14px', color: '#9CA3AF', marginTop: '4px' }}>Registro individual de los datos del Excel</p>
          </div>
          <button style={{ backgroundColor: '#1A1A1A', color: 'white', border: 'none', padding: '10px 20px', borderRadius: '10px', fontSize: '12px', fontWeight: '700' }}>
            Exportar CSV
          </button>
        </div>

        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
            <thead>
              <tr style={{ borderBottom: '1px solid #F3F4F6' }}>
                <th style={{ padding: '16px', fontSize: '12px', color: '#9CA3AF', fontWeight: '800', textTransform: 'uppercase' }}>Fecha/Hora</th>
                <th style={{ padding: '16px', fontSize: '12px', color: '#9CA3AF', fontWeight: '800', textTransform: 'uppercase' }}>Producto</th>
                <th style={{ padding: '16px', fontSize: '12px', color: '#9CA3AF', fontWeight: '800', textTransform: 'uppercase', textAlign: 'center' }}>Cantidad</th>
                <th style={{ padding: '16px', fontSize: '12px', color: '#9CA3AF', fontWeight: '800', textTransform: 'uppercase', textAlign: 'right' }}>Total</th>
                <th style={{ padding: '16px', fontSize: '12px', color: '#9CA3AF', fontWeight: '800', textTransform: 'uppercase' }}>Ubicación</th>
              </tr>
            </thead>
            <tbody>
              {(data?.recentTransactions || []).map((t, i) => (
                <tr key={i} style={{ borderBottom: '1px solid #FAFAFA', transition: 'background 0.2s' }}>
                  <td style={{ padding: '16px', fontSize: '13px', fontWeight: '600', color: '#6B7280' }}>{t.sale_date}</td>
                  <td style={{ padding: '16px', fontSize: '13px', fontWeight: '700', color: '#1A1A1A' }}>{t.product_name}</td>
                  <td style={{ padding: '16px', fontSize: '13px', fontWeight: '700', color: '#1A1A1A', textAlign: 'center' }}>{t.quantity}</td>
                  <td style={{ padding: '16px', fontSize: '13px', fontWeight: '800', color: '#F97316', textAlign: 'right' }}>{t.total_amount.toFixed(2)}€</td>
                  <td style={{ padding: '16px', fontSize: '12px', fontWeight: '600', color: '#9CA3AF' }}>{t.location || 'Tienda'}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {!(data?.recentTransactions || []).length && <p style={{ textAlign: 'center', color: '#9CA3AF', padding: '40px 0' }}>No hay transacciones recientes</p>}
        </div>
      </div>

      <style jsx global>{`
        body { background-color: #FFFFFF; }
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-spin { animation: spin 1s linear infinite; }
        @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
        tbody tr:hover { background-color: #F9FAFB; }
      `}</style>
    </div>
  );
}
