'use client';

import React, { useState, useEffect, Suspense } from 'react';
import Link from 'next/link';
import { useSearchParams } from 'next/navigation';
import { ArrowLeft, Calendar, Clock, Plus, MapPin, User, Save, Loader2 } from 'lucide-react';

function HorariosContent() {
  const searchParams = useSearchParams();
  const employeeId = searchParams.get('id');
  
  const [schedules, setSchedules] = useState<any[]>([]);
  const [employees, setEmployees] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  
  const [newShift, setNewShift] = useState({
    employee_id: employeeId || '',
    date: date,
    start_time: '09:00',
    end_time: '17:00',
    location: 'Downtown'
  });

  const fetchData = async () => {
    setLoading(true);
    const [schedRes, empRes] = await Promise.all([
      fetch(`/api/admin/horarios?date=${date}`),
      fetch('/api/admin/personal')
    ]);
    const schedData = await schedRes.json();
    const empData = await empRes.json();
    setSchedules(schedData);
    setEmployees(empData);
    setLoading(false);
  };

  useEffect(() => {
    fetchData();
  }, [date]);

  const handleAddShift = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await fetch('/api/admin/horarios', {
      method: 'POST',
      body: JSON.stringify(newShift)
    });
    if (res.ok) {
      fetchData();
    }
  };

  const calculateHours = (start: string, end: string) => {
    const s = new Date(`2000-01-01T${start}:00`);
    const e = new Date(`2000-01-01T${end}:00`);
    return (e.getTime() - s.getTime()) / (1000 * 60 * 60);
  };

  const dailyTotalCost = schedules.reduce((acc, s) => {
    const hours = calculateHours(s.start_time, s.end_time);
    return acc + (hours * s.hourly_rate);
  }, 0);

  return (
    <div style={{ backgroundColor: '#FAF9F6', minHeight: '100vh', fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif' }}>
      {/* Header */}
      <header style={{ padding: '30px 40px', backgroundColor: 'white', borderBottom: '1px solid #E5E7EB', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <Link href="/admin/personal" style={{ display: 'flex', alignItems: 'center', gap: '8px', color: '#666', fontSize: '12px', textDecoration: 'none', marginBottom: '8px', fontWeight: 'bold' }}>
            <ArrowLeft size={14} /> VOLVER A PERSONAL
          </Link>
          <h1 style={{ fontSize: '24px', fontWeight: 'bold', margin: 0 }}>Planificador de Horarios</h1>
          <p style={{ fontSize: '13px', color: '#9CA3AF', margin: '4px 0 0 0' }}>Organización de turnos y control de presupuesto diario</p>
        </div>
        <div style={{ display: 'flex', gap: '15px', alignItems: 'center' }}>
          <input 
            type="date" 
            value={date} 
            onChange={e => setDate(e.target.value)}
            style={{ padding: '10px 15px', borderRadius: '12px', border: '1px solid #E5E7EB', fontWeight: 'bold', fontSize: '14px' }}
          />
        </div>
      </header>

      <main style={{ padding: '40px', maxWidth: '1200px', margin: '0 auto', display: 'grid', gridTemplateColumns: '1fr 350px', gap: '40px' }}>
        
        {/* Left: Schedule View */}
        <section>
          <div style={{ backgroundColor: 'white', padding: '30px', borderRadius: '24px', border: '1px solid #E5E7EB', marginBottom: '30px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px' }}>
              <h2 style={{ fontSize: '18px', fontWeight: 'bold', margin: 0 }}>Turnos para el {new Date(date).toLocaleDateString('es-ES', { weekday: 'long', day: 'numeric', month: 'long' })}</h2>
              <div style={{ backgroundColor: '#F0FDF4', color: '#166534', padding: '6px 12px', borderRadius: '8px', fontSize: '12px', fontWeight: 'bold' }}>
                COSTO LABORAL DÍA: {dailyTotalCost.toFixed(2)} €
              </div>
            </div>

            {loading ? <div style={{ textAlign: 'center', padding: '20px' }}>Actualizando cuadrante...</div> : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                {schedules.length === 0 ? <p style={{ textAlign: 'center', color: '#9CA3AF', padding: '40px' }}>No hay turnos asignados para este día.</p> : schedules.map((s, idx) => {
                  const hours = calculateHours(s.start_time, s.end_time);
                  return (
                    <div key={idx} style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr 1fr auto', gap: '20px', padding: '16px 20px', backgroundColor: '#F9FAFB', borderRadius: '16px', alignItems: 'center', border: '1px solid #F3F4F6' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                        <div style={{ width: '8px', height: '8px', borderRadius: '50%', backgroundColor: '#F97316' }}></div>
                        <span style={{ fontWeight: 'bold', fontSize: '14px' }}>{s.employee_name}</span>
                      </div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '6px', color: '#6B7280', fontSize: '13px' }}>
                        <Clock size={14} /> {s.start_time} - {s.end_time} ({hours}h)
                      </div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '6px', color: '#6B7280', fontSize: '13px' }}>
                        <MapPin size={14} /> {s.location}
                      </div>
                      <div style={{ fontSize: '13px', fontWeight: 'bold', color: '#1A1A1A', textAlign: 'right' }}>
                        {(hours * s.hourly_rate).toFixed(2)} €
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </section>

        {/* Right: Add Shift Form */}
        <aside>
          <div style={{ backgroundColor: 'white', padding: '30px', borderRadius: '24px', border: '1px solid #E5E7EB', position: 'sticky', top: '40px' }}>
            <h3 style={{ fontSize: '16px', fontWeight: 'bold', marginBottom: '24px', display: 'flex', alignItems: 'center', gap: '8px' }}>
              <Plus size={18} color="#F97316" /> Asignar Turno
            </h3>
            <form onSubmit={handleAddShift} style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
              <div>
                <label style={{ fontSize: '11px', fontWeight: 'bold', color: '#9CA3AF', display: 'block', marginBottom: '6px' }}>COLABORADOR</label>
                <select 
                  value={newShift.employee_id} 
                  onChange={e => setNewShift({...newShift, employee_id: e.target.value})}
                  style={{ width: '100%', padding: '12px', borderRadius: '12px', border: '1px solid #E5E7EB', backgroundColor: '#F9FAFB' }}
                  required
                >
                  <option value="">— Seleccionar —</option>
                  {employees.map(e => <option key={e.id} value={e.id}>{e.name} ({e.position})</option>)}
                </select>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
                <div>
                  <label style={{ fontSize: '11px', fontWeight: 'bold', color: '#9CA3AF', display: 'block', marginBottom: '6px' }}>INICIO</label>
                  <input 
                    type="time" 
                    value={newShift.start_time} 
                    onChange={e => setNewShift({...newShift, start_time: e.target.value})}
                    style={{ width: '100%', padding: '12px', borderRadius: '12px', border: '1px solid #E5E7EB' }} 
                    required
                  />
                </div>
                <div>
                  <label style={{ fontSize: '11px', fontWeight: 'bold', color: '#9CA3AF', display: 'block', marginBottom: '6px' }}>FIN</label>
                  <input 
                    type="time" 
                    value={newShift.end_time} 
                    onChange={e => setNewShift({...newShift, end_time: e.target.value})}
                    style={{ width: '100%', padding: '12px', borderRadius: '12px', border: '1px solid #E5E7EB' }} 
                    required
                  />
                </div>
              </div>
              <div>
                <label style={{ fontSize: '11px', fontWeight: 'bold', color: '#9CA3AF', display: 'block', marginBottom: '6px' }}>UBICACIÓN / SEDE</label>
                <select 
                  value={newShift.location} 
                  onChange={e => setNewShift({...newShift, location: e.target.value})}
                  style={{ width: '100%', padding: '12px', borderRadius: '12px', border: '1px solid #E5E7EB', backgroundColor: '#F9FAFB' }}
                >
                  <option value="Downtown">Downtown</option>
                  <option value="Residencial">Residencial</option>
                  <option value="Hub Aeropuerto">Hub Aeropuerto</option>
                </select>
              </div>
              <button 
                type="submit" 
                style={{ marginTop: '10px', width: '100%', padding: '16px', borderRadius: '14px', border: 'none', backgroundColor: '#1A1A1A', color: 'white', fontWeight: 'bold', display: 'flex', alignItems: 'center', gap: '8px', justifyContent: 'center' }}
              >
                <Save size={18} /> Confirmar Turno
              </button>
            </form>
          </div>
        </aside>
      </main>
    </div>
  );
}

export default function HorariosPage() {
  return (
    <Suspense fallback={<div style={{ padding: '40px', textAlign: 'center' }}>Cargando planificación...</div>}>
      <HorariosContent />
    </Suspense>
  );
}
