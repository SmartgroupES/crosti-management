'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { ArrowLeft, Users, Clock, Plus, User, Briefcase, DollarSign, Calendar } from 'lucide-react';

export default function PersonalPage() {
  const [employees, setEmployees] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  
  const [newEmp, setNewEmp] = useState({ name: '', position: '', hourly_rate: 0 });

  const fetchEmployees = () => {
    setLoading(true);
    fetch('/api/admin/personal')
      .then(res => res.json())
      .then(json => {
        setEmployees(json);
        setLoading(false);
      })
      .catch(e => console.error(e));
  };

  useEffect(() => {
    fetchEmployees();
  }, []);

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await fetch('/api/admin/personal', {
      method: 'POST',
      body: JSON.stringify(newEmp)
    });
    if (res.ok) {
      setShowAdd(false);
      setNewEmp({ name: '', position: '', hourly_rate: 0 });
      fetchEmployees();
    }
  };

  if (loading) return <div style={{ padding: '40px', textAlign: 'center' }}>Cargando equipo...</div>;

  return (
    <div style={{ backgroundColor: '#FAF9F6', minHeight: '100vh', fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif' }}>
      {/* Header */}
      <header style={{ padding: '30px 40px', backgroundColor: 'white', borderBottom: '1px solid #E5E7EB', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <Link href="/admin/importar" style={{ display: 'flex', alignItems: 'center', gap: '8px', color: '#666', fontSize: '12px', textDecoration: 'none', marginBottom: '8px', fontWeight: 'bold' }}>
            <ArrowLeft size={14} /> VOLVER A PANEL
          </Link>
          <h1 style={{ fontSize: '24px', fontWeight: 'bold', margin: 0 }}>Gestión de Personal</h1>
          <p style={{ fontSize: '13px', color: '#9CA3AF', margin: '4px 0 0 0' }}>Administración de equipo y costos laborales</p>
        </div>
        <div style={{ display: 'flex', gap: '12px' }}>
          <button 
            onClick={() => setShowAdd(true)}
            style={{ backgroundColor: '#1A1A1A', color: 'white', border: 'none', padding: '12px 24px', borderRadius: '14px', fontSize: '14px', fontWeight: 'bold', display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer' }}
          >
            <Plus size={18} /> Nuevo Empleado
          </button>
        </div>
      </header>

      <main style={{ padding: '40px', maxWidth: '1000px', margin: '0 auto' }}>
        {/* KPI Cards */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '20px', marginBottom: '40px' }}>
          <div style={{ backgroundColor: 'white', padding: '24px', borderRadius: '24px', border: '1px solid #E5E7EB' }}>
            <div style={{ fontSize: '12px', color: '#9CA3AF', fontWeight: 'bold', marginBottom: '10px' }}>EQUIPO TOTAL</div>
            <div style={{ fontSize: '24px', fontWeight: 'bold' }}>{employees.length}</div>
          </div>
          <div style={{ backgroundColor: 'white', padding: '24px', borderRadius: '24px', border: '1px solid #E5E7EB' }}>
            <div style={{ fontSize: '12px', color: '#9CA3AF', fontWeight: 'bold', marginBottom: '10px' }}>TARIFA MEDIA</div>
            <div style={{ fontSize: '24px', fontWeight: 'bold' }}>{(employees.reduce((acc, c) => acc + c.hourly_rate, 0) / employees.length).toFixed(2)} €/h</div>
          </div>
        </div>

        {/* Employee List */}
        <div style={{ backgroundColor: 'white', borderRadius: '24px', border: '1px solid #E5E7EB', overflow: 'hidden' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ backgroundColor: '#F9FAFB', textAlign: 'left' }}>
                <th style={{ padding: '16px 24px', fontSize: '11px', color: '#9CA3AF', fontWeight: 'bold' }}>EMPLEADO</th>
                <th style={{ padding: '16px 24px', fontSize: '11px', color: '#9CA3AF', fontWeight: 'bold' }}>PUESTO</th>
                <th style={{ padding: '16px 24px', fontSize: '11px', color: '#9CA3AF', fontWeight: 'bold', textAlign: 'center' }}>TARIFA HORA</th>
                <th style={{ padding: '16px 24px', fontSize: '11px', color: '#9CA3AF', fontWeight: 'bold', textAlign: 'right' }}>ACCIONES</th>
              </tr>
            </thead>
            <tbody>
              {employees.map((emp, idx) => (
                <tr key={idx} style={{ borderBottom: '1px solid #F3F4F6' }}>
                  <td style={{ padding: '20px 24px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                      <div style={{ width: '36px', height: '36px', borderRadius: '50%', backgroundColor: '#F3F4F6', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 'bold', color: '#1A1A1A' }}>
                        {emp.name.charAt(0)}
                      </div>
                      <div style={{ fontSize: '14px', fontWeight: 'bold' }}>{emp.name}</div>
                    </div>
                  </td>
                  <td style={{ padding: '20px 24px' }}>
                    <div style={{ fontSize: '13px', color: '#6B7280' }}>{emp.position}</div>
                  </td>
                  <td style={{ padding: '20px 24px', textAlign: 'center', fontSize: '14px', fontWeight: 'bold' }}>
                    {emp.hourly_rate.toFixed(2)} €
                  </td>
                  <td style={{ padding: '20px 24px', textAlign: 'right' }}>
                    <Link href={`/admin/personal/horarios?id=${emp.id}`} style={{ color: '#F97316', fontSize: '12px', fontWeight: 'bold', textDecoration: 'none', display: 'flex', alignItems: 'center', gap: '4px', justifyContent: 'flex-end' }}>
                      <Clock size={14} /> Ver Horarios
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </main>

      {/* Add Employee Modal (Simplified) */}
      {showAdd && (
        <div style={{ position: 'fixed', inset: 0, backgroundColor: 'rgba(0,0,0,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100 }}>
          <div style={{ backgroundColor: 'white', padding: '40px', borderRadius: '24px', width: '100%', maxWidth: '500px' }}>
            <h2 style={{ fontSize: '20px', fontWeight: 'bold', marginBottom: '24px' }}>Nuevo Miembro del Equipo</h2>
            <form onSubmit={handleAdd} style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
              <div>
                <label style={{ fontSize: '12px', fontWeight: 'bold', color: '#666', display: 'block', marginBottom: '8px' }}>NOMBRE COMPLETO</label>
                <input 
                  type="text" 
                  value={newEmp.name} 
                  onChange={e => setNewEmp({...newEmp, name: e.target.value})}
                  style={{ width: '100%', padding: '12px', borderRadius: '12px', border: '1px solid #E5E7EB' }} 
                  required
                />
              </div>
              <div>
                <label style={{ fontSize: '12px', fontWeight: 'bold', color: '#666', display: 'block', marginBottom: '8px' }}>PUESTO</label>
                <input 
                  type="text" 
                  value={newEmp.position} 
                  onChange={e => setNewEmp({...newEmp, position: e.target.value})}
                  style={{ width: '100%', padding: '12px', borderRadius: '12px', border: '1px solid #E5E7EB' }} 
                  required
                />
              </div>
              <div>
                <label style={{ fontSize: '12px', fontWeight: 'bold', color: '#666', display: 'block', marginBottom: '8px' }}>TARIFA HORA (€)</label>
                <input 
                  type="number" 
                  step="0.01"
                  value={newEmp.hourly_rate} 
                  onChange={e => setNewEmp({...newEmp, hourly_rate: parseFloat(e.target.value)})}
                  style={{ width: '100%', padding: '12px', borderRadius: '12px', border: '1px solid #E5E7EB' }} 
                  required
                />
              </div>
              <div style={{ display: 'flex', gap: '12px', marginTop: '10px' }}>
                <button type="button" onClick={() => setShowAdd(false)} style={{ flex: 1, padding: '14px', borderRadius: '14px', border: '1px solid #E5E7EB', backgroundColor: 'white', fontWeight: 'bold' }}>Cancelar</button>
                <button type="submit" style={{ flex: 1, padding: '14px', borderRadius: '14px', border: 'none', backgroundColor: '#F97316', color: 'white', fontWeight: 'bold' }}>Guardar</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
