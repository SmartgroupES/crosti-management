'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { ArrowLeft, Beaker, TrendingUp, AlertCircle, Info, DollarSign, Calculator, ChevronDown, ChevronUp } from 'lucide-react';

export default function EscandallosPage() {
  const [data, setData] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [expanded, setExpanded] = useState<Record<number, boolean>>({});

  useEffect(() => {
    fetch('/api/escandallos')
      .then(res => res.json())
      .then(json => {
        setData(json);
        setLoading(false);
      })
      .catch(e => console.error(e));
  }, []);

  const toggleExpand = (id: number) => {
    setExpanded(prev => ({ ...prev, [id]: !prev[id] }));
  };

  if (loading) return <div style={{ padding: '40px', textAlign: 'center' }}>Calculando escandallos...</div>;

  return (
    <div style={{ backgroundColor: '#FAF9F6', minHeight: '100vh', fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif' }}>
      {/* Header */}
      <header style={{ padding: '30px 40px', backgroundColor: 'white', borderBottom: '1px solid #E5E7EB', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <Link href="/admin" style={{ display: 'flex', alignItems: 'center', gap: '8px', color: '#666', fontSize: '12px', textDecoration: 'none', marginBottom: '8px', fontWeight: 'bold' }}>
            <ArrowLeft size={14} /> VOLVER A PANEL
          </Link>
          <h1 style={{ fontSize: '24px', fontWeight: 'bold', margin: 0 }}>Ingeniería de Menú (Escandallos)</h1>
          <p style={{ fontSize: '13px', color: '#9CA3AF', margin: '4px 0 0 0' }}>Análisis técnico de costos y márgenes de contribución</p>
        </div>
        <div style={{ display: 'flex', gap: '12px' }}>
          <Link href="/admin/simulador">
            <button style={{ backgroundColor: '#1A1A1A', color: 'white', border: 'none', padding: '10px 20px', borderRadius: '12px', fontSize: '13px', fontWeight: 'bold', display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer' }}>
              <Calculator size={16} /> Simulador de Impacto
            </button>
          </Link>
        </div>
      </header>

      <main style={{ padding: '40px', maxWidth: '1200px', margin: '0 auto' }}>
        {/* Legend */}
        <div style={{ display: 'flex', gap: '20px', marginBottom: '30px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '12px', color: '#10B981', fontWeight: 'bold' }}>
            <div style={{ width: '10px', height: '10px', borderRadius: '50%', backgroundColor: '#10B981' }}></div> Rentable (>70%)
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '12px', color: '#F59E0B', fontWeight: 'bold' }}>
            <div style={{ width: '10px', height: '10px', borderRadius: '50%', backgroundColor: '#F59E0B' }}></div> Alerta (50-70%)
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '12px', color: '#EF4444', fontWeight: 'bold' }}>
            <div style={{ width: '10px', height: '10px', borderRadius: '50%', backgroundColor: '#EF4444' }}></div> Crítico (&lt;50%)
          </div>
        </div>

        {/* List of Products */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
          {data.map((item) => (
            <div key={item.id} style={{ backgroundColor: 'white', borderRadius: '20px', border: '1px solid #E5E7EB', overflow: 'hidden', boxShadow: '0 1px 3px rgba(0,0,0,0.05)' }}>
              {/* Main Info */}
              <div 
                onClick={() => toggleExpand(item.id)}
                style={{ padding: '24px 30px', cursor: 'pointer', display: 'grid', gridTemplateColumns: '2fr 1fr 1fr 1fr 1fr auto', gap: '20px', alignItems: 'center' }}
              >
                <div>
                  <div style={{ fontSize: '16px', fontWeight: 'bold' }}>{item.name}</div>
                  <div style={{ fontSize: '12px', color: '#9CA3AF' }}>ID: {item.id}</div>
                </div>

                <div style={{ textAlign: 'center' }}>
                  <div style={{ fontSize: '11px', color: '#9CA3AF', fontWeight: 'bold' }}>COSTO TOTAL</div>
                  <div style={{ fontSize: '15px', fontWeight: 'bold' }}>{item.total_cost.toFixed(3)} €</div>
                </div>

                <div style={{ textAlign: 'center' }}>
                  <div style={{ fontSize: '11px', color: '#9CA3AF', fontWeight: 'bold' }}>PRECIO VENTA</div>
                  <div style={{ fontSize: '15px', fontWeight: 'bold' }}>{item.sale_price.toFixed(2)} €</div>
                </div>

                <div style={{ textAlign: 'center' }}>
                  <div style={{ fontSize: '11px', color: '#9CA3AF', fontWeight: 'bold' }}>MARGEN REAL</div>
                  <div style={{ 
                    fontSize: '15px', 
                    fontWeight: 'bold', 
                    color: item.status === 'good' ? '#10B981' : (item.status === 'warning' ? '#F59E0B' : '#EF4444')
                  }}>
                    {(item.current_margin * 100).toFixed(1)}%
                  </div>
                </div>

                <div style={{ textAlign: 'center' }}>
                  <div style={{ fontSize: '11px', color: '#F97316', fontWeight: 'bold' }}>P. SUGERIDO</div>
                  <div style={{ fontSize: '15px', fontWeight: 'bold', color: '#F97316' }}>{item.suggested_price.toFixed(2)} €</div>
                </div>

                {expanded[item.id] ? <ChevronUp size={20} color="#9CA3AF" /> : <ChevronDown size={20} color="#9CA3AF" />}
              </div>

              {/* Ingredients Detail */}
              {expanded[item.id] && (
                <div style={{ backgroundColor: '#F9FAFB', borderTop: '1px solid #E5E7EB', padding: '30px' }}>
                  <div style={{ fontSize: '13px', fontWeight: 'bold', marginBottom: '20px', display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <Info size={16} color="#6B7280" /> DESGLOSE TÉCNICO DE INGREDIENTES
                  </div>
                  
                  <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '13px' }}>
                    <thead>
                      <tr style={{ textAlign: 'left', borderBottom: '2px solid #E5E7EB' }}>
                        <th style={{ padding: '12px 0', color: '#6B7280' }}>INGREDIENTE</th>
                        <th style={{ padding: '12px 0', color: '#6B7280', textAlign: 'center' }}>CANT. RECETA</th>
                        <th style={{ padding: '12px 0', color: '#6B7280', textAlign: 'center' }}>COSTO MERCADO</th>
                        <th style={{ padding: '12px 0', color: '#6B7280', textAlign: 'center' }}>FACTOR MERMA</th>
                        <th style={{ padding: '12px 0', color: '#6B7280', textAlign: 'right' }}>COSTO FINAL</th>
                      </tr>
                    </thead>
                    <tbody>
                      {item.ingredients.map((ing: any, idx: number) => (
                        <tr key={idx} style={{ borderBottom: '1px solid #E5E7EB' }}>
                          <td style={{ padding: '15px 0', fontWeight: 'bold' }}>{ing.name}</td>
                          <td style={{ padding: '15px 0', textAlign: 'center' }}>{ing.qty} {ing.unit}</td>
                          <td style={{ padding: '15px 0', textAlign: 'center' }}>{ing.unit_cost.toFixed(3)} €/{ing.unit}</td>
                          <td style={{ padding: '15px 0', textAlign: 'center', color: ing.waste_factor > 1 ? '#EF4444' : '#6B7280' }}>
                            x{ing.waste_factor.toFixed(2)}
                          </td>
                          <td style={{ padding: '15px 0', textAlign: 'right', fontWeight: 'bold' }}>{ing.total_cost.toFixed(3)} €</td>
                        </tr>
                      ))}
                    </tbody>
                    <tfoot>
                      <tr>
                        <td colSpan={4} style={{ padding: '20px 0', textAlign: 'right', fontWeight: 'bold', color: '#6B7280' }}>COSTO VARIABLE TOTAL (MATERIA PRIMA):</td>
                        <td style={{ padding: '20px 0', textAlign: 'right', fontSize: '18px', fontWeight: 'bold', color: '#1A1A1A' }}>{item.total_cost.toFixed(3)} €</td>
                      </tr>
                    </tfoot>
                  </table>

                  {/* Profitability Analysis Box */}
                  <div style={{ marginTop: '30px', backgroundColor: 'white', padding: '24px', borderRadius: '16px', border: '1px solid #E5E7EB', display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '30px' }}>
                    <div>
                      <div style={{ fontSize: '11px', fontWeight: 'bold', color: '#9CA3AF', marginBottom: '8px' }}>UTILIDAD POR UNIDAD</div>
                      <div style={{ fontSize: '20px', fontWeight: 'bold', color: '#10B981' }}>{(item.sale_price - item.total_cost).toFixed(2)} €</div>
                    </div>
                    <div>
                      <div style={{ fontSize: '11px', fontWeight: 'bold', color: '#9CA3AF', marginBottom: '8px' }}>PUNTO DE EQUILIBRIO (GASTOS FIJOS)</div>
                      <div style={{ fontSize: '14px', color: '#666' }}>Se requieren vender <strong style={{ color: '#1A1A1A' }}>~240 unid</strong> para cubrir gastos.</div>
                    </div>
                    <div style={{ borderLeft: '1px solid #F3F4F6', paddingLeft: '30px' }}>
                      <div style={{ fontSize: '11px', fontWeight: 'bold', color: '#F97316', marginBottom: '8px' }}>ESTRATEGIA SUGERIDA</div>
                      <div style={{ fontSize: '13px', fontWeight: 'bold', color: item.status === 'critical' ? '#EF4444' : '#1A1A1A' }}>
                        {item.status === 'critical' ? 'INCREMENTO DE PRECIO URGENTE' : (item.status === 'warning' ? 'REVISAR RECETA O PROVEEDOR' : 'MANTENER Y POTENCIAR')}
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}
