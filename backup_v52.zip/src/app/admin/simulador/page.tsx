'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { ArrowLeft, Calculator, TrendingUp, DollarSign, Users, Zap, Home, Package, RefreshCcw } from 'lucide-react';

export default function SimuladorCostosPage() {
  const [fixedCosts, setFixedCosts] = useState<any[]>([]);
  const [escandallos, setEscandallos] = useState<any[]>([]);
  const [productionVolume, setProductionVolume] = useState(5000);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      fetch('/api/admin/fixed-costs').then(res => res.json()),
      fetch('/api/escandallos').then(res => res.json())
    ]).then(([costsData, escandallosData]) => {
      setFixedCosts(costsData.fixedCosts || []);
      setEscandallos(escandallosData || []);
      if (costsData.realMonthlyVolume > 0) {
        setProductionVolume(costsData.realMonthlyVolume);
      }
      setLoading(false);
    }).catch(e => console.error(e));
  }, []);

  const handleCostChange = (id: number, newValue: number) => {
    setFixedCosts(prev => prev.map(c => c.id === id ? { ...c, amount: newValue } : c));
  };

  const totalFixedCosts = fixedCosts.reduce((acc, curr) => acc + curr.amount, 0);
  const unitFixedCost = productionVolume > 0 ? totalFixedCosts / productionVolume : 0;

  if (loading) return <div style={{ padding: '40px', textAlign: 'center' }}>Cargando simulador...</div>;

  return (
    <div style={{ backgroundColor: '#FAF9F6', minHeight: '100vh', fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif' }}>
      {/* Header */}
      <header style={{ padding: '30px 40px', backgroundColor: 'white', borderBottom: '1px solid #E5E7EB', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <Link href="/admin/escandallos" style={{ display: 'flex', alignItems: 'center', gap: '8px', color: '#666', fontSize: '12px', textDecoration: 'none', marginBottom: '8px', fontWeight: 'bold' }}>
            <ArrowLeft size={14} /> VOLVER A ESCANDALLOS
          </Link>
          <h1 style={{ fontSize: '24px', fontWeight: 'bold', margin: 0 }}>Simulador de Punto de Equilibrio</h1>
          <p style={{ fontSize: '13px', color: '#9CA3AF', margin: '4px 0 0 0' }}>Análisis de impacto de gastos operativos en el beneficio neto</p>
        </div>
        <Calculator size={32} color="#F97316" />
      </header>

      <main style={{ padding: '40px', maxWidth: '1200px', margin: '0 auto', display: 'grid', gridTemplateColumns: '350px 1fr', gap: '40px' }}>
        
        {/* Left Sidebar: Controls */}
        <aside style={{ display: 'flex', flexDirection: 'column', gap: '30px' }}>
          <div style={{ backgroundColor: 'white', padding: '24px', borderRadius: '24px', border: '1px solid #E5E7EB' }}>
            <h3 style={{ fontSize: '14px', fontWeight: 'bold', marginBottom: '20px', display: 'flex', alignItems: 'center', gap: '8px' }}>
              <Package size={16} color="#F97316" /> VOLUMEN MENSUAL
            </h3>
            <input 
              type="range" 
              min="500" 
              max="20000" 
              step="100"
              value={productionVolume}
              onChange={(e) => setProductionVolume(parseInt(e.target.value))}
              style={{ width: '100%', accentColor: '#F97316', marginBottom: '12px' }}
            />
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ fontSize: '18px', fontWeight: 'bold' }}>{productionVolume.toLocaleString()}</span>
              <span style={{ fontSize: '12px', color: '#6B7280' }}>unidades/mes</span>
            </div>
          </div>

          <div style={{ backgroundColor: 'white', padding: '24px', borderRadius: '24px', border: '1px solid #E5E7EB' }}>
            <h3 style={{ fontSize: '14px', fontWeight: 'bold', marginBottom: '20px' }}>GASTOS FIJOS (MENSUAL)</h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
              {fixedCosts.map(cost => (
                <div key={cost.id}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                    <label style={{ fontSize: '12px', color: '#666', fontWeight: 'bold' }}>{cost.category.toUpperCase()}</label>
                    <span style={{ fontSize: '12px', fontWeight: 'bold' }}>{cost.amount} €</span>
                  </div>
                  <input 
                    type="range" 
                    min="0" 
                    max={cost.amount * 3} 
                    step="50"
                    value={cost.amount}
                    onChange={(e) => handleCostChange(cost.id, parseInt(e.target.value))}
                    style={{ width: '100%', accentColor: '#1A1A1A' }}
                  />
                </div>
              ))}
            </div>
            <div style={{ marginTop: '24px', paddingTop: '20px', borderTop: '1px solid #F3F4F6', display: 'flex', justifyContent: 'space-between' }}>
              <span style={{ fontSize: '13px', fontWeight: 'bold' }}>TOTAL GASTOS</span>
              <span style={{ fontSize: '16px', fontWeight: 'bold', color: '#EF4444' }}>{totalFixedCosts.toLocaleString()} €</span>
            </div>
          </div>
        </aside>

        {/* Right Content: Analysis */}
        <section style={{ display: 'flex', flexDirection: 'column', gap: '30px' }}>
          {/* Summary Cards */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
            <div style={{ backgroundColor: '#1A1A1A', color: 'white', padding: '30px', borderRadius: '24px' }}>
              <div style={{ fontSize: '12px', fontWeight: 'bold', opacity: 0.6, marginBottom: '8px', letterSpacing: '1px' }}>COSTO FIJO POR UNIDAD</div>
              <div style={{ fontSize: '32px', fontWeight: 'bold' }}>{unitFixedCost.toFixed(3)} €</div>
              <div style={{ fontSize: '13px', opacity: 0.8, marginTop: '8px' }}>Lo que cuesta "abrir" la tienda por cada galleta</div>
            </div>
            <div style={{ backgroundColor: '#F0FDF4', border: '1px solid #BBF7D0', padding: '30px', borderRadius: '24px' }}>
              <div style={{ fontSize: '12px', fontWeight: 'bold', color: '#166534', marginBottom: '8px', letterSpacing: '1px' }}>BENEFICIO NETO PROYECTADO</div>
              <div style={{ fontSize: '32px', fontWeight: 'bold', color: '#166534' }}>
                {escandallos.length > 0 ? (
                  (escandallos.reduce((acc, curr) => acc + (curr.sale_price - curr.total_cost - unitFixedCost), 0) / escandallos.length * productionVolume).toLocaleString('es-ES')
                ) : 0} €
              </div>
              <div style={{ fontSize: '13px', color: '#166534', opacity: 0.8, marginTop: '8px' }}>Resultado mensual antes de impuestos</div>
            </div>
          </div>

          {/* Impact Table */}
          <div style={{ backgroundColor: 'white', borderRadius: '24px', border: '1px solid #E5E7EB', overflow: 'hidden' }}>
            <div style={{ padding: '24px', borderBottom: '1px solid #F3F4F6' }}>
              <h3 style={{ fontSize: '16px', fontWeight: 'bold', margin: 0 }}>Impacto en Productos Estrella</h3>
            </div>
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr style={{ backgroundColor: '#F9FAFB', textAlign: 'left' }}>
                  <th style={{ padding: '16px 24px', fontSize: '11px', color: '#9CA3AF', fontWeight: 'bold' }}>PRODUCTO</th>
                  <th style={{ padding: '16px 24px', fontSize: '11px', color: '#9CA3AF', fontWeight: 'bold', textAlign: 'center' }}>COSTO MP</th>
                  <th style={{ padding: '16px 24px', fontSize: '11px', color: '#9CA3AF', fontWeight: 'bold', textAlign: 'center' }}>COSTO FIJO</th>
                  <th style={{ padding: '16px 24px', fontSize: '11px', color: '#9CA3AF', fontWeight: 'bold', textAlign: 'center' }}>COSTO TOTAL</th>
                  <th style={{ padding: '16px 24px', fontSize: '11px', color: '#9CA3AF', fontWeight: 'bold', textAlign: 'center' }}>PRECIO VENTA</th>
                  <th style={{ padding: '16px 24px', fontSize: '11px', color: '#9CA3AF', fontWeight: 'bold', textAlign: 'right' }}>BENEFICIO NETO</th>
                </tr>
              </thead>
              <tbody>
                {escandallos.slice(0, 8).map((p, idx) => {
                  const totalUnitCost = p.total_cost + unitFixedCost;
                  const netProfit = p.sale_price - totalUnitCost;
                  return (
                    <tr key={idx} style={{ borderBottom: '1px solid #F3F4F6' }}>
                      <td style={{ padding: '20px 24px', fontSize: '14px', fontWeight: 'bold' }}>{p.name}</td>
                      <td style={{ padding: '20px 24px', textAlign: 'center' }}>{p.total_cost.toFixed(2)} €</td>
                      <td style={{ padding: '20px 24px', textAlign: 'center', color: '#6B7280' }}>{unitFixedCost.toFixed(2)} €</td>
                      <td style={{ padding: '20px 24px', textAlign: 'center', fontWeight: 'bold' }}>{totalUnitCost.toFixed(2)} €</td>
                      <td style={{ padding: '20px 24px', textAlign: 'center' }}>{p.sale_price.toFixed(2)} €</td>
                      <td style={{ padding: '20px 24px', textAlign: 'right', fontWeight: 'bold', color: netProfit > 0 ? '#10B981' : '#EF4444' }}>
                        {netProfit.toFixed(2)} €
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Break-even Info */}
          <div style={{ backgroundColor: '#FFF7ED', border: '1px solid #FFEDD5', padding: '24px', borderRadius: '24px', display: 'flex', alignItems: 'center', gap: '20px' }}>
            <div style={{ backgroundColor: '#F97316', color: 'white', width: '48px', height: '48px', borderRadius: '12px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <TrendingUp size={24} />
            </div>
            <div>
              <div style={{ fontSize: '14px', fontWeight: 'bold', color: '#9A3412' }}>PUNTO DE EQUILIBRIO OPERATIVO</div>
              <div style={{ fontSize: '13px', color: '#C2410C' }}>
                Necesitas vender un promedio de <strong style={{ fontSize: '16px' }}>{(totalFixedCosts / (escandallos.reduce((a,c) => a + (c.sale_price - c.total_cost), 0) / escandallos.length)).toFixed(0)}</strong> galletas al mes para cubrir el 100% de tus costos fijos.
              </div>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}
