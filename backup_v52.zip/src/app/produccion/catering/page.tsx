'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { Calendar, Users, Package, Clock, CheckCircle, Plus, ChevronRight, AlertCircle } from 'lucide-react';

export default function CateringPage() {
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/catering')
      .then(res => res.json())
      .then(data => {
        setOrders(data);
        setLoading(false);
      })
      .catch(err => {
        console.error(err);
        setLoading(false);
      });
  }, []);

  return (
    <div style={{ backgroundColor: '#F8FAFC', minHeight: '100vh', fontFamily: 'Inter, system-ui, sans-serif', color: '#1E293B' }}>
      {/* Header */}
      <header style={{ backgroundColor: '#1E293B', color: 'white', padding: '20px 40px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <div style={{ backgroundColor: '#F97316', padding: '8px', borderRadius: '10px' }}>
            <Users size={20} color="white" />
          </div>
          <div>
            <h1 style={{ fontSize: '18px', fontWeight: '800', margin: 0 }}>Gestión de Catering</h1>
            <p style={{ fontSize: '12px', color: '#94A3B8', margin: 0 }}>BakeOS Operations — Pre-ventas 24/48h</p>
          </div>
        </div>
        <Link href="/" style={{ fontSize: '13px', color: '#94A3B8', textDecoration: 'none', fontWeight: '600' }}>← Dashboard</Link>
      </header>

      <main style={{ padding: '40px', maxWidth: '1200px', margin: '0 auto' }}>
        
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '30px' }}>
          <h2 style={{ fontSize: '24px', fontWeight: '900' }}>Pedidos Próximos</h2>
          <button style={{ backgroundColor: '#F97316', color: 'white', border: 'none', padding: '12px 25px', borderRadius: '12px', fontSize: '14px', fontWeight: 'bold', display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer' }}>
            <Plus size={18} /> Nuevo Pedido
          </button>
        </div>

        {/* Notifications Bar (BakeOS Phase 4) */}
        <div style={{ marginBottom: '30px', backgroundColor: 'white', borderRadius: '20px', padding: '15px 25px', border: '1px solid #E2E8F0', display: 'flex', alignItems: 'center', gap: '15px' }}>
          <div style={{ position: 'relative' }}>
            <AlertCircle color="#F97316" size={20} />
            <div style={{ position: 'absolute', top: -4, right: -4, width: '10px', height: '10px', backgroundColor: '#EF4444', borderRadius: '50%', border: '2px solid white' }}></div>
          </div>
          <div style={{ flex: 1 }}>
            <p style={{ margin: 0, fontSize: '13px', fontWeight: 'bold' }}>Alertas de BakeOS</p>
            <p style={{ margin: 0, fontSize: '11px', color: '#64748B' }}>1 nuevo pedido detectado. Revisar ventana de horneado (06:00 - 08:30).</p>
          </div>
          <button style={{ backgroundColor: '#F1F5F9', border: 'none', padding: '8px 15px', borderRadius: '10px', fontSize: '11px', fontWeight: 'bold', color: '#475569', cursor: 'pointer' }}>Marcar como leído</button>
        </div>

        {loading ? (
          <div style={{ textAlign: 'center', padding: '100px', color: '#64748B' }}>Cargando pedidos de catering...</div>
        ) : orders.length === 0 ? (
          <div style={{ 
            backgroundColor: 'white', 
            borderRadius: '24px', 
            padding: '80px', 
            textAlign: 'center', 
            border: '2px dashed #E2E8F0' 
          }}>
            <Package size={48} color="#CBD5E1" style={{ margin: '0 auto 20px auto' }} />
            <h3 style={{ fontSize: '18px', fontWeight: '800', color: '#64748B' }}>No hay pedidos programados</h3>
            <p style={{ color: '#94A3B8', fontSize: '14px' }}>Los pedidos de catering aparecerán aquí para integrarse en la producción diaria.</p>
          </div>
        ) : (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(350px, 1fr))', gap: '20px' }}>
            {orders.map((order, i) => (
              <div key={i} style={{ backgroundColor: 'white', borderRadius: '20px', padding: '25px', border: '1px solid #E2E8F0', boxShadow: '0 4px 6px -1px rgba(0,0,0,0.05)' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '15px' }}>
                  <span style={{ 
                    fontSize: '11px', 
                    fontWeight: 'bold', 
                    padding: '4px 10px', 
                    borderRadius: '10px', 
                    backgroundColor: order.status === 'pending' ? '#FEF3C7' : '#DCFCE7',
                    color: order.status === 'pending' ? '#92400E' : '#166534'
                  }}>
                    {order.status === 'pending' ? 'PENDIENTE' : 'PREPARANDO'}
                  </span>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '5px', color: '#64748B', fontSize: '12px' }}>
                    <Calendar size={14} /> {order.delivery_date}
                  </div>
                </div>

                <h3 style={{ fontSize: '18px', fontWeight: '800', margin: '0 0 10px 0' }}>{order.customer_name}</h3>
                
                <div style={{ backgroundColor: '#F8FAFC', padding: '15px', borderRadius: '12px', marginBottom: '20px' }}>
                  <p style={{ margin: 0, fontSize: '11px', color: '#94A3B8', textTransform: 'uppercase', marginBottom: '8px' }}>Productos</p>
                  <p style={{ margin: 0, fontSize: '13px', color: '#1E293B', fontWeight: '600' }}>{order.items || 'Sin items'}</p>
                </div>

                {order.status === 'ready_to_dispatch' ? (
                  <div style={{ backgroundColor: '#DCFCE7', color: '#166534', padding: '10px', borderRadius: '12px', fontSize: '12px', fontWeight: 'bold', textAlign: 'center', marginBottom: '20px', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px' }}>
                    <CheckCircle size={16} /> CALIDAD VALIDADA POR IA
                  </div>
                ) : (
                  <div style={{ display: 'flex', gap: '10px', marginBottom: '20px' }}>
                    <input 
                      type="file" 
                      id={`val-${order.id}`} 
                      hidden 
                      onChange={async (e) => {
                        const file = e.target.files?.[0];
                        if (!file) return;
                        const reader = new FileReader();
                        reader.onloadend = async () => {
                          const base64 = reader.result as string;
                          const res = await fetch('/api/catering/validate', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ orderId: order.id, image: base64 })
                          });
                          const data = await res.json();
                          if (data.status === 'ready_to_dispatch') {
                            alert("Caja validada con éxito. Listo para despachar.");
                            window.location.reload();
                          } else {
                            const recoveryMsg = data.analysis.recovery_path === 'store_discount' 
                              ? "SUGERENCIA: Venta en Tienda (Crunchy Special - 30% Dto)"
                              : data.analysis.recovery_path === 'tgtg'
                              ? "SUGERENCIA: Liquidar en TooGoodToGo"
                              : "SUGERENCIA: Descarte total (Calidad Crítica)";
                            
                            alert(`CALIDAD RECHAZADA: ${data.analysis.observations}\n\n${recoveryMsg}`);
                            window.location.reload();
                          }
                        };
                        reader.readAsDataURL(file);
                      }} 
                    />
                    <button 
                      onClick={() => document.getElementById(`val-${order.id}`)?.click()}
                      style={{ 
                        flex: 1, 
                        backgroundColor: '#F97316', 
                        color: 'white', 
                        border: 'none', 
                        padding: '10px', 
                        borderRadius: '10px', 
                        fontSize: '12px', 
                        fontWeight: 'bold', 
                        cursor: 'pointer',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        gap: '5px'
                      }}
                    >
                      <Plus size={14} /> Validar Caja (IA)
                    </button>
                  </div>
                )}

                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: '#64748B', fontSize: '13px' }}>
                    <Clock size={16} /> {order.delivery_time || 'Por definir'}
                  </div>
                  <button style={{ background: 'none', border: 'none', color: '#F97316', fontWeight: 'bold', fontSize: '13px', display: 'flex', alignItems: 'center', gap: '5px', cursor: 'pointer' }}>
                    Ver detalle <ChevronRight size={16} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Integration Alert */}
        <div style={{ marginTop: '40px', backgroundColor: '#EFF6FF', border: '1px solid #DBEAFE', borderRadius: '20px', padding: '25px', display: 'flex', gap: '20px', alignItems: 'center' }}>
          <div style={{ backgroundColor: '#3B82F6', padding: '12px', borderRadius: '12px' }}>
            <AlertCircle color="white" size={24} />
          </div>
          <div>
            <h4 style={{ margin: 0, fontSize: '15px', fontWeight: '800', color: '#1E40AF' }}>Integración con Producción</h4>
            <p style={{ margin: '4px 0 0 0', fontSize: '13px', color: '#1E40AF', lineHeight: '1.5' }}>
              Los pedidos de catering se suman automáticamente a la <strong>Planificación de Producción</strong>. Asegúrate de revisar las mermas proyectadas considerando estas pre-ventas.
            </p>
          </div>
        </div>

      </main>
    </div>
  );
}
