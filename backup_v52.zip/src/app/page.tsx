'use client';

import React from 'react';
import Header from '@/components/Header';
import { 
  BarChart3, 
  TrendingUp, 
  Calculator, 
  BookOpen, 
  Calendar, 
  ChefHat, 
  Trash2, 
  ShoppingCart, 
  Package, 
  Settings, 
  Camera, 
  Zap, 
  Layout, 
  CheckCircle2, 
  Users, 
  Clock, 
  ShieldCheck,
  LayoutDashboard
} from 'lucide-react';

export default function HomePage() {

  const sections = [
    {
      title: "ANÁLISIS",
      icon: <BarChart3 size={16} />,
      items: [
        { label: "Seguimiento de Ventas", href: "/consulta/ventas", icon: <TrendingUp size={18} /> },
        { label: "Rentabilidad", href: "/analisis/rentabilidad", icon: <Calculator size={18} /> },
        { label: "Simulador de Costos", href: "/admin/simulador", icon: <LayoutDashboard size={18} /> },
        { label: "Gestión de Recetas", href: "/admin/escandallos", icon: <BookOpen size={18} /> }
      ]
    },
    {
      title: "OPERACIONES",
      icon: <Settings size={16} />,
      items: [
        { label: "Planificación", href: "/planificacion", icon: <Calendar size={18} /> },
        { label: "Gestión Catering", href: "/produccion/catering", icon: <ChefHat size={18} /> },
        { label: "Gestión de Merma", href: "/produccion/merma", icon: <Trash2 size={18} /> },
        { label: "Compras", href: "/inventario/compras", icon: <ShoppingCart size={18} /> },
        { label: "Control de Stock", href: "/inventario/stock", icon: <Package size={18} /> },
        { label: "Mantenimiento", href: "/admin/mantenimiento", icon: <Settings size={18} /> }
      ]
    },
    {
      title: "BAKEOS IA",
      icon: <Zap size={16} />,
      items: [
        { label: "Control Calidad (Foto)", href: "/inventario/foto", icon: <Camera size={18} /> },
        { label: "Sincro Omnicanal", href: "/analisis/omnichannel", icon: <Zap size={18} /> },
        { label: "Layout & Merchandising", href: "/analisis/layout", icon: <Layout size={18} /> },
        { label: "Score Calidad Visual", href: "/analisis/calidad", icon: <CheckCircle2 size={18} /> }
      ]
    },
    {
      title: "EQUIPO & SISTEMA",
      icon: <Users size={16} />,
      items: [
        { label: "Personal y Equipo", href: "/admin/personal", icon: <Users size={18} /> },
        { label: "Horarios y Turnos", href: "/admin/personal/horarios", icon: <Clock size={18} /> },
        { label: "Control Sanitario", href: "/admin/appcc", icon: <ShieldCheck size={18} /> },
        { label: "Configuración", href: "/admin/configuracion", icon: <Settings size={18} /> }
      ]
    }
  ];

  return (
    <div className="fade-in" style={{ 
      minHeight: '100vh', 
      width: '100%',
      padding: '120px 5% 60px 5%',
      display: 'flex',
      flexDirection: 'column',
      position: 'relative'
    }}>
      <Header />

      <div style={{
        maxWidth: '1400px',
        margin: '0 auto',
        width: '100%'
      }}>
        {/* Welcome Header */}
        <div style={{ marginBottom: '40px' }}>
          <h1 style={{ fontSize: '32px', marginBottom: '8px' }}>Panel de Gestión</h1>
          <p style={{ color: 'var(--text-dim)', fontSize: '16px' }}>Bienvenido de nuevo a Crosti Hub. Gestiona tus operaciones con inteligencia.</p>
        </div>

        {/* 4-Column Grid */}
        <div style={{ 
          display: 'grid', 
          gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', 
          gap: '32px',
          width: '100%'
        }}>
          {sections.map((section, idx) => (
            <div key={idx} className="glass" style={{ 
              padding: '24px', 
              borderRadius: '24px',
              display: 'flex', 
              flexDirection: 'column', 
              gap: '16px' 
            }}>
              {/* Section Header */}
              <div style={{ 
                display: 'flex', 
                alignItems: 'center', 
                gap: '10px',
                color: 'var(--accent-yellow)',
                marginBottom: '8px'
              }}>
                {section.icon}
                <span style={{ 
                  fontSize: '12px', 
                  fontWeight: '900', 
                  letterSpacing: '2px',
                  textTransform: 'uppercase'
                }}>
                  {section.title}
                </span>
              </div>
              
              <div style={{ display: 'grid', gap: '12px' }}>
                {section.items.map((item, i) => (
                  <button 
                    key={i}
                    onClick={() => window.location.href = item.href}
                    style={{
                      backgroundColor: 'rgba(255, 255, 255, 0.05)',
                      border: '1px solid rgba(255, 255, 255, 0.1)',
                      padding: '16px 20px',
                      borderRadius: '14px',
                      color: 'var(--text-white)',
                      fontSize: '14px',
                      fontWeight: '600',
                      cursor: 'pointer',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '12px',
                      transition: 'var(--transition-smooth)',
                      textAlign: 'left'
                    }}
                    onMouseOver={(e) => {
                      e.currentTarget.style.backgroundColor = 'var(--accent-yellow)';
                      e.currentTarget.style.color = 'var(--primary-red)';
                      e.currentTarget.style.transform = 'translateX(5px)';
                    }}
                    onMouseOut={(e) => {
                      e.currentTarget.style.backgroundColor = 'rgba(255, 255, 255, 0.05)';
                      e.currentTarget.style.color = 'var(--text-white)';
                      e.currentTarget.style.transform = 'translateX(0)';
                    }}
                  >
                    <span style={{ opacity: 0.8 }}>{item.icon}</span>
                    {item.label}
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
