'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { ArrowLeft, Box, AlertTriangle, TrendingDown, RefreshCcw, Search } from 'lucide-react';

export default function StockRealTimePage() {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  const fetchStock = () => {
    setLoading(true);
    fetch('/api/inventario/stock')
      .then(res => res.json())
      .then(json => {
        setData(json);
        setLoading(false);
      })
      .catch(e => console.error(e));
  };

  useEffect(() => {
    fetchStock();
  }, []);

  if (loading && !data) {
    return <div style={{ padding: '40px', textAlign: 'center' }}>Cargando inventario...</div>;
  }

  const materials = data?.materials?.filter((m: any) => 
    m.name.toLowerCase().includes(searchTerm.toLowerCase())
  ) || [];

  return (
    <div style={{ backgroundColor: '#FAF9F6', minHeight: '100vh', fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif', color: '#1A1A1A' }}>
      {/* Header */}
      <header style={{ padding: '30px 40px', backgroundColor: 'white', borderBottom: '1px solid #E5E7EB', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <Link href="/inventario" style={{ display: 'flex', alignItems: 'center', gap: '8px', color: '#666', fontSize: '12px', textDecoration: 'none', marginBottom: '8px', fontWeight: 'bold' }}>
            <ArrowLeft size={14} /> VOLVER A INVENTARIO
          </Link>
          <h1 style={{ fontSize: '24px', fontWeight: 'bold', margin: 0 }}>Stock en Tiempo Real</h1>
          <p style={{ fontSize: '13px', color: '#9CA3AF', margin: '4px 0 0 0' }}>Materias Primas y Suministros</p>
        </div>
        <div style={{ display: 'flex', gap: '12px' }}>
          <button onClick={fetchStock} style={{ backgroundColor: 'white', border: '1px solid #E5E7EB', padding: '10px 20px', borderRadius: '12px', fontSize: '13px', fontWeight: 'bold', display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer' }}>
            <RefreshCcw size={16} /> Actualizar
          </button>
          <Link href="/inventario/compras">
            <button style={{ backgroundColor: '#1A1A1A', color: 'white', border: 'none', padding: '10px 20px', borderRadius: '12px', fontSize: '13px', fontWeight: 'bold', cursor: 'pointer' }}>
              Registrar Compra
            </button>
          </Link>
        </div>
      </header>

      <main style={{ padding: '40px', maxWidth: '1200px', margin: '0 auto' }}>
        {/* KPI Cards */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: '20px', marginBottom: '40px' }}>
          <div style={{ backgroundColor: 'white', padding: '24px', borderRadius: '20px', border: '1px solid #E5E7EB' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '16px' }}>
              <div style={{ fontSize: '11px', fontWeight: 'bold', color: '#9CA3AF', letterSpacing: '1px' }}>VALOR TOTAL</div>
              <Box size={18} color="#10B981" />
            </div>
            <div style={{ fontSize: '28px', fontWeight: 'bold', marginBottom: '4px' }}>{data?.summary?.totalValue.toLocaleString('es-ES')} €</div>
            <div style={{ fontSize: '12px', color: '#6B7280' }}>Costo acumulado en almacén</div>
          </div>

          <div style={{ backgroundColor: 'white', padding: '24px', borderRadius: '20px', border: '1px solid #E5E7EB' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '16px' }}>
              <div style={{ fontSize: '11px', fontWeight: 'bold', color: '#9CA3AF', letterSpacing: '1px' }}>ALERTAS DE STOCK</div>
              <AlertTriangle size={18} color="#EF4444" />
            </div>
            <div style={{ fontSize: '28px', fontWeight: 'bold', marginBottom: '4px', color: data?.summary?.lowStockItems > 0 ? '#EF4444' : '#1A1A1A' }}>{data?.summary?.lowStockItems}</div>
            <div style={{ fontSize: '12px', color: '#6B7280' }}>Items bajo el límite de seguridad</div>
          </div>

          <div style={{ backgroundColor: 'white', padding: '24px', borderRadius: '20px', border: '1px solid #E5E7EB' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '16px' }}>
              <div style={{ fontSize: '11px', fontWeight: 'bold', color: '#9CA3AF', letterSpacing: '1px' }}>CONSUMO DIARIO</div>
              <TrendingDown size={18} color="#2563EB" />
            </div>
            <div style={{ fontSize: '28px', fontWeight: 'bold', marginBottom: '4px' }}>-12.4%</div>
            <div style={{ fontSize: '12px', color: '#6B7280' }}>Variación vs. ayer</div>
          </div>
        </div>

        {/* Search and Table */}
        <div style={{ backgroundColor: 'white', borderRadius: '24px', border: '1px solid #E5E7EB', overflow: 'hidden' }}>
          <div style={{ padding: '24px', borderBottom: '1px solid #F3F4F6', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div style={{ position: 'relative', width: '300px' }}>
              <Search size={16} style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: '#9CA3AF' }} />
              <input 
                type="text" 
                placeholder="Buscar ingrediente..." 
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                style={{ width: '100%', padding: '10px 10px 10px 40px', borderRadius: '12px', border: '1px solid #E5E7EB', fontSize: '13px' }}
              />
            </div>
          </div>

          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ backgroundColor: '#F9FAFB', textAlign: 'left' }}>
                <th style={{ padding: '16px 24px', fontSize: '11px', color: '#9CA3AF', fontWeight: 'bold' }}>MATERIA PRIMA</th>
                <th style={{ padding: '16px 24px', fontSize: '11px', color: '#9CA3AF', fontWeight: 'bold', textAlign: 'right' }}>STOCK ACTUAL</th>
                <th style={{ padding: '16px 24px', fontSize: '11px', color: '#9CA3AF', fontWeight: 'bold', textAlign: 'right' }}>UNIDAD</th>
                <th style={{ padding: '16px 24px', fontSize: '11px', color: '#9CA3AF', fontWeight: 'bold', textAlign: 'right' }}>ALERTA</th>
                <th style={{ padding: '16px 24px', fontSize: '11px', color: '#9CA3AF', fontWeight: 'bold', textAlign: 'right' }}>VALOR STOCK</th>
                <th style={{ padding: '16px 24px', fontSize: '11px', color: '#9CA3AF', fontWeight: 'bold' }}>ESTADO</th>
              </tr>
            </thead>
            <tbody>
              {materials.map((m: any, idx: number) => {
                const isLow = m.current_stock <= m.min_stock_alert;
                return (
                  <tr key={idx} style={{ borderBottom: '1px solid #F3F4F6' }}>
                    <td style={{ padding: '20px 24px' }}>
                      <div style={{ fontSize: '14px', fontWeight: 'bold' }}>{m.name}</div>
                    </td>
                    <td style={{ padding: '20px 24px', textAlign: 'right', fontSize: '16px', fontWeight: 'bold', color: isLow ? '#EF4444' : '#1A1A1A' }}>
                      {m.current_stock.toLocaleString('es-ES')}
                    </td>
                    <td style={{ padding: '20px 24px', textAlign: 'right', fontSize: '13px', color: '#6B7280' }}>{m.unit_measure}</td>
                    <td style={{ padding: '20px 24px', textAlign: 'right', fontSize: '13px', color: '#9CA3AF' }}>{m.min_stock_alert} {m.unit_measure}</td>
                    <td style={{ padding: '20px 24px', textAlign: 'right', fontSize: '14px', fontWeight: '500' }}>
                      {(m.current_stock * m.average_cost_per_unit).toLocaleString('es-ES', { minimumFractionDigits: 2 })} €
                    </td>
                    <td style={{ padding: '20px 24px' }}>
                      <span style={{ 
                        fontSize: '10px', 
                        fontWeight: 'bold', 
                        padding: '4px 8px', 
                        borderRadius: '6px',
                        backgroundColor: isLow ? '#FEF2F2' : '#F0FDF4',
                        color: isLow ? '#EF4444' : '#10B981',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '4px',
                        width: 'fit-content'
                      }}>
                        {isLow ? <AlertTriangle size={10} /> : null}
                        {isLow ? 'STOCK BAJO' : 'OK'}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </main>
    </div>
  );
}
