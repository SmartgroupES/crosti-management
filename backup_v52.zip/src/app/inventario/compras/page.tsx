'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { ArrowLeft, ShoppingCart, Calendar, User, Package, DollarSign, CheckCircle, Loader2, Camera } from 'lucide-react';

export default function RegistroComprasPage() {
  const [materials, setMaterials] = useState<any[]>([]);
  const [suppliers, setSuppliers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);

  const [formData, setFormData] = useState({
    material_id: '',
    supplier_id: '',
    quantity: '',
    total_cost: '',
    date: new Date().toISOString().split('T')[0]
  });

  const handleScan = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setSubmitting(true);
    const body = new FormData();
    body.append('file', file);

    try {
      const res = await fetch('/api/vision/invoice', {
        method: 'POST',
        body
      });
      const data = await res.json();
      
      if (data.error) throw new Error(data.error);

      // Simple matching for supplier
      if (data.supplier) {
        const foundSupplier = suppliers.find(s => 
          s.name.toLowerCase().includes(data.supplier.toLowerCase()) ||
          data.supplier.toLowerCase().includes(s.name.toLowerCase())
        );
        if (foundSupplier) setFormData(prev => ({ ...prev, supplier_id: foundSupplier.id.toString() }));
      }

      // If multiple items, we'll pick the first for now (or improve to handle multiple)
      if (data.items && data.items.length > 0) {
        const firstItem = data.items[0];
        
        // Simple matching for material
        const foundMaterial = materials.find(m => 
          m.name.toLowerCase().includes(firstItem.name.toLowerCase()) ||
          firstItem.name.toLowerCase().includes(m.name.toLowerCase())
        );

        setFormData(prev => ({ 
          ...prev, 
          material_id: foundMaterial ? foundMaterial.id.toString() : prev.material_id,
          quantity: firstItem.quantity?.toString() || prev.quantity,
          total_cost: firstItem.cost?.toString() || prev.total_cost,
          date: data.date || prev.date
        }));
      }

    } catch (e: any) {
      alert('Error al analizar factura: ' + e.message);
    } finally {
      setSubmitting(false);
    }
  };

  useEffect(() => {
    Promise.all([
      fetch('/api/inventario/stock').then(res => res.json()),
      fetch('/api/suppliers').then(res => res.json())
    ]).then(([stockJson, suppliersJson]) => {
      setMaterials(stockJson.materials || []);
      setSuppliers(suppliersJson || []);
      setLoading(false);
    }).catch(e => console.error(e));
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const res = await fetch('/api/inventario/compras', {
        method: 'POST',
        body: JSON.stringify(formData)
      });
      const json = await res.json();
      if (json.success) {
        setSuccess(true);
        setFormData({
          material_id: '',
          supplier_id: '',
          quantity: '',
          total_cost: '',
          date: new Date().toISOString().split('T')[0]
        });
        setTimeout(() => setSuccess(false), 3000);
      } else {
        alert('Error: ' + json.error);
      }
    } catch (e) {
      alert('Error al registrar la compra');
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) return <div style={{ padding: '40px', textAlign: 'center' }}>Cargando datos...</div>;

  const selectedMaterial = materials.find(m => m.id === parseInt(formData.material_id));
  const unitPrice = formData.quantity && formData.total_cost ? (parseFloat(formData.total_cost) / parseFloat(formData.quantity)).toFixed(2) : '0.00';

  return (
    <div style={{ backgroundColor: '#FAF9F6', minHeight: '100vh', fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif', color: '#1A1A1A' }}>
      {/* Header */}
      <header style={{ padding: '30px 40px', backgroundColor: 'white', borderBottom: '1px solid #E5E7EB', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <Link href="/inventario" style={{ display: 'flex', alignItems: 'center', gap: '8px', color: '#666', fontSize: '12px', textDecoration: 'none', marginBottom: '8px', fontWeight: 'bold' }}>
            <ArrowLeft size={14} /> VOLVER A INVENTARIO
          </Link>
          <h1 style={{ fontSize: '24px', fontWeight: 'bold', margin: 0 }}>Registrar Compra</h1>
          <p style={{ fontSize: '13px', color: '#9CA3AF', margin: '4px 0 0 0' }}>Ingreso de mercadería y actualización de costos</p>
        </div>
        <ShoppingCart size={32} color="#F97316" />
      </header>

      <main style={{ padding: '40px', maxWidth: '600px', margin: '0 auto' }}>
        <div style={{ backgroundColor: 'white', padding: '40px', borderRadius: '24px', border: '1px solid #E5E7EB', boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.05)' }}>
          {/* Smart Scan Button */}
          <div style={{ marginBottom: '32px', textAlign: 'center' }}>
            <label style={{ 
              display: 'inline-flex', 
              alignItems: 'center', 
              gap: '10px', 
              backgroundColor: '#F97316', 
              color: 'white', 
              padding: '16px 24px', 
              borderRadius: '16px', 
              cursor: 'pointer',
              fontWeight: 'bold',
              fontSize: '14px',
              boxShadow: '0 4px 12px rgba(249, 115, 22, 0.2)'
            }}>
              <Camera size={20} />
              {submitting ? 'Analizando Factura...' : 'Escanear Factura con IA'}
              <input type="file" accept="image/*" capture="environment" onChange={handleScan} hidden disabled={submitting} />
            </label>
            <p style={{ fontSize: '11px', color: '#9CA3AF', marginTop: '10px' }}>Toma una foto para rellenar los datos automáticamente</p>
          </div>

          <div style={{ height: '1px', backgroundColor: '#F3F4F6', marginBottom: '32px' }} />

          {success && (
            <div style={{ backgroundColor: '#F0FDF4', color: '#166534', padding: '16px', borderRadius: '12px', marginBottom: '24px', display: 'flex', alignItems: 'center', gap: '12px', fontSize: '14px', fontWeight: 'bold' }}>
              <CheckCircle size={20} /> ¡Compra registrada y stock actualizado con éxito!
            </div>
          )}

          <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
            {/* Insumo */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
              <label style={{ fontSize: '12px', fontWeight: 'bold', color: '#666', display: 'flex', alignItems: 'center', gap: '6px' }}>
                <Package size={14} /> MATERIA PRIMA
              </label>
              <select 
                required
                value={formData.material_id}
                onChange={(e) => setFormData({...formData, material_id: e.target.value})}
                style={{ padding: '14px', borderRadius: '12px', border: '1px solid #E5E7EB', fontSize: '14px', backgroundColor: '#F9FAFB' }}
              >
                <option value="">Selecciona un insumo...</option>
                {materials.map(m => (
                  <option key={m.id} value={m.id}>{m.name} ({m.unit_measure})</option>
                ))}
              </select>
            </div>

            {/* Proveedor */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
              <label style={{ fontSize: '12px', fontWeight: 'bold', color: '#666', display: 'flex', alignItems: 'center', gap: '6px' }}>
                <User size={14} /> PROVEEDOR
              </label>
              <select 
                value={formData.supplier_id}
                onChange={(e) => setFormData({...formData, supplier_id: e.target.value})}
                style={{ padding: '14px', borderRadius: '12px', border: '1px solid #E5E7EB', fontSize: '14px', backgroundColor: '#F9FAFB' }}
              >
                <option value="">Selecciona un proveedor (opcional)...</option>
                {suppliers.map(s => (
                  <option key={s.id} value={s.id}>{s.name}</option>
                ))}
              </select>
            </div>

            {/* Cantidad y Costo */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                <label style={{ fontSize: '12px', fontWeight: 'bold', color: '#666' }}>CANTIDAD ({selectedMaterial?.unit_measure || '-'})</label>
                <input 
                  type="number" 
                  step="0.01"
                  required
                  placeholder="0.00"
                  value={formData.quantity}
                  onChange={(e) => setFormData({...formData, quantity: e.target.value})}
                  style={{ padding: '14px', borderRadius: '12px', border: '1px solid #E5E7EB', fontSize: '14px' }}
                />
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                <label style={{ fontSize: '12px', fontWeight: 'bold', color: '#666' }}>COSTO TOTAL (€)</label>
                <input 
                  type="number" 
                  step="0.01"
                  required
                  placeholder="0.00"
                  value={formData.total_cost}
                  onChange={(e) => setFormData({...formData, total_cost: e.target.value})}
                  style={{ padding: '14px', borderRadius: '12px', border: '1px solid #E5E7EB', fontSize: '14px' }}
                />
              </div>
            </div>

            {/* Resumen Costo Unitario */}
            <div style={{ backgroundColor: '#F9FAFB', padding: '16px', borderRadius: '12px', border: '1px solid #E5E7EB', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div style={{ fontSize: '12px', color: '#666' }}>Costo Unitario de esta compra:</div>
              <div style={{ fontSize: '16px', fontWeight: 'bold' }}>{unitPrice} € / {selectedMaterial?.unit_measure || 'unid'}</div>
            </div>

            {/* Fecha */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
              <label style={{ fontSize: '12px', fontWeight: 'bold', color: '#666', display: 'flex', alignItems: 'center', gap: '6px' }}>
                <Calendar size={14} /> FECHA DE FACTURA
              </label>
              <input 
                type="date" 
                value={formData.date}
                onChange={(e) => setFormData({...formData, date: e.target.value})}
                style={{ padding: '14px', borderRadius: '12px', border: '1px solid #E5E7EB', fontSize: '14px' }}
              />
            </div>

            <button 
              type="submit" 
              disabled={submitting}
              style={{ 
                backgroundColor: '#1A1A1A', 
                color: 'white', 
                padding: '16px', 
                borderRadius: '12px', 
                border: 'none', 
                fontWeight: 'bold', 
                fontSize: '16px', 
                cursor: 'pointer',
                marginTop: '10px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '10px'
              }}
            >
              {submitting ? <Loader2 size={20} className="animate-spin" /> : 'Guardar Registro'}
            </button>
          </form>
        </div>
      </main>
    </div>
  );
}
