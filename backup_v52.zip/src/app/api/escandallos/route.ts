import { NextRequest, NextResponse } from 'next/server';

export const runtime = 'edge';

export async function GET(req: NextRequest, context: any) {
  const { DB } = context.env;
  if (!DB) return NextResponse.json({ error: "DB not found" }, { status: 500 });

  try {
    const { results: escandallos } = await DB.prepare(`
      SELECT 
        p.id as product_id,
        p.name as product_name,
        p.sale_price,
        p.target_margin,
        r.quantity_needed,
        r.waste_factor,
        rm.name as material_name,
        rm.average_cost_per_unit as cost_per_unit,
        rm.unit_measure
      FROM products p
      JOIN recipes r ON p.id = r.product_id
      JOIN raw_materials rm ON r.material_id = rm.id
      WHERE p.is_active = 1
    `).all();

    // Group by product
    const grouped = escandallos.reduce((acc: any, curr: any) => {
      if (!acc[curr.product_id]) {
        acc[curr.product_id] = {
          id: curr.product_id,
          name: curr.product_name,
          sale_price: curr.sale_price,
          target_margin: curr.target_margin,
          total_cost: 0,
          ingredients: []
        };
      }
      
      const ingredientCost = curr.quantity_needed * curr.cost_per_unit * (curr.waste_factor || 1.0);
      acc[curr.product_id].total_cost += ingredientCost;
      acc[curr.product_id].ingredients.push({
        name: curr.material_name,
        qty: curr.quantity_needed,
        unit: curr.unit_measure,
        unit_cost: curr.cost_per_unit,
        waste_factor: curr.waste_factor || 1.0,
        total_cost: ingredientCost
      });
      
      return acc;
    }, {});

    const results = Object.values(grouped).map((p: any) => {
      const margin = p.sale_price > 0 ? (p.sale_price - p.total_cost) / p.sale_price : 0;
      const suggested_price = p.target_margin < 1 ? p.total_cost / (1 - p.target_margin) : p.total_cost * 4;
      
      return {
        ...p,
        current_margin: margin,
        suggested_price,
        status: margin < 0.5 ? 'critical' : (margin < 0.7 ? 'warning' : 'good')
      };
    });

    return NextResponse.json(results);
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
