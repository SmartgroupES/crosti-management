import { NextRequest, NextResponse } from 'next/server';

export const runtime = 'edge';

export async function GET(req: NextRequest, context: any) {
  const { DB } = context.env;
  if (!DB) return NextResponse.json({ error: "DB not found" }, { status: 500 });

  try {
    const { results: materials } = await DB.prepare("SELECT * FROM raw_materials ORDER BY name ASC").all();
    
    // Calculate total inventory value
    const totalValue = materials.reduce((acc: number, curr: any) => acc + (curr.current_stock * curr.average_cost_per_unit), 0);

    return NextResponse.json({
      materials,
      summary: {
        totalItems: materials.length,
        totalValue,
        lowStockItems: materials.filter((m: any) => m.current_stock <= m.min_stock_alert).length
      }
    });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
