import { NextRequest, NextResponse } from "next/server";
import { getRequestContext } from '@cloudflare/next-on-pages';

export const runtime = "edge";

export async function GET(req: NextRequest) {
  const { env } = getRequestContext();
  const key = env.GOOGLE_AI_API_KEY;
  
  if (!key) return NextResponse.json({ error: "No key" });

  try {
    const res = await fetch(`https://generativelanguage.googleapis.com/v1/models?key=${key}`);
    const data = await res.json();
    return NextResponse.json(data);
  } catch (e: any) {
    return NextResponse.json({ error: e.message });
  }
}
