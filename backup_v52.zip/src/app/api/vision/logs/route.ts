import { NextRequest, NextResponse } from "next/server";
import { getRequestContext } from '@cloudflare/next-on-pages';

export const runtime = "edge";

export async function GET(req: NextRequest) {
  const { env } = getRequestContext();
  const DB = env.DB;

  if (!DB) {
    return NextResponse.json({ error: "Database not found" }, { status: 500 });
  }

  try {
    const { results } = await DB.prepare(`
      SELECT * FROM vision_logs 
      ORDER BY timestamp DESC 
      LIMIT 50
    `).all();

    return NextResponse.json(results);
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
