import { NextRequest, NextResponse } from 'next/server';
import { getRequestContext } from '@cloudflare/next-on-pages';

export const runtime = 'edge';

export async function GET(req: NextRequest) {
  const { env } = getRequestContext();
  const DB = env.DB;
  
  if (!DB) return NextResponse.json({ error: "DB not found" }, { status: 500 });

  try {
    // 1. Hourly Distribution (Aggregated from all available data)
    // We try to extract hour from sale_date if it's in the 'sales' table, 
    // or use the 'hour' column if it's in 'sales_data'
    const hourlySales = await DB.prepare(`
      SELECT 
        h as hour, 
        SUM(amount) as total_amount,
        SUM(qty) as total_items
      FROM (
        SELECT CAST(hour as INTEGER) as h, total_sales as amount, quantity as qty FROM sales_data
        UNION ALL
        SELECT CAST(strftime('%H', sale_date) as INTEGER) as h, total_amount as amount, quantity as qty FROM sales WHERE sale_date IS NOT NULL
      )
      WHERE h IS NOT NULL
      GROUP BY h
      ORDER BY h ASC
    `).all();

    // 2. Global KPIs
    const kpis = await DB.prepare(`
      SELECT 
        SUM(amount) as total_revenue,
        SUM(qty) as total_units,
        COUNT(*) as total_transactions,
        AVG(amount) as avg_ticket
      FROM (
        SELECT total_sales as amount, quantity as qty FROM sales_data
        UNION ALL
        SELECT total_amount as amount, quantity as qty FROM sales
      )
    `).first();

    // 3. Weekly Trend (Last 4 weeks)
    const weeklyTrend = await DB.prepare(`
      SELECT 
        strftime('%Y-%W', date) as week,
        SUM(amount) as revenue
      FROM (
        SELECT date, total_sales as amount FROM sales_data
        UNION ALL
        SELECT date(sale_date) as date, total_amount as amount FROM sales
      )
      GROUP BY week
      ORDER BY week DESC
      LIMIT 8
    `).all();

    // 4. Top Products
    const topProducts = await DB.prepare(`
      SELECT 
        product_name, 
        SUM(qty) as units,
        SUM(amount) as revenue
      FROM (
        SELECT product_name, quantity as qty, total_sales as amount FROM sales_data
        UNION ALL
        SELECT product_name, quantity as qty, total_amount as amount FROM sales
      )
      GROUP BY product_name
      ORDER BY revenue DESC
      LIMIT 10
    `).all();

    // 5. Recent Transactions (Detail)
    const recentTransactions = await DB.prepare(`
      SELECT 
        id, 
        sale_date, 
        product_name, 
        quantity, 
        total_amount,
        location
      FROM sales
      ORDER BY sale_date DESC
      LIMIT 100
    `).all();

    // 6. Heatmap Data (Day of week vs Hour)
    const heatmapData = await DB.prepare(`
      SELECT 
        CAST(strftime('%w', sale_date) as INTEGER) as day_of_week,
        CAST(strftime('%H', sale_date) as INTEGER) as hour,
        SUM(total_amount) as total_sales
      FROM sales
      WHERE sale_date IS NOT NULL
      GROUP BY day_of_week, hour
      HAVING hour BETWEEN 8 AND 22
    `).all();

    return NextResponse.json({
      hourly: hourlySales.results,
      kpis: {
        totalRevenue: kpis?.total_revenue || 0,
        totalUnits: kpis?.total_units || 0,
        totalTransactions: kpis?.total_transactions || 0,
        avgTicket: kpis?.avg_ticket || 0
      },
      weekly: weeklyTrend.results.reverse(),
      topProducts: topProducts.results,
      recentTransactions: recentTransactions.results,
      heatmap: heatmapData.results
    });


  } catch (e: any) {
    console.error("Sales Stats Error:", e);
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
