'use client';

import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import { ShieldCheck, TrendingUp, AlertCircle, History, Star, Calendar } from 'lucide-react';

export default function QualityDashboardPage() {
  const [logs, setLogs] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/vision/logs')
      .then(res => res.json())
      .then(data => {
        setLogs(data);
        setLoading(false);
      })
      .catch(err => {
        console.error(err);
        setLoading(false);
      });
  }, []);

  const avgScore = logs.length > 0 
    ? (logs.reduce((acc, log) => acc + log.quality_score, 0) / logs.length).toFixed(1)
    : '0.0';

  const goldStandards = logs.filter(log => {
      try {
          const analysis = JSON.parse(log.analysis_json);
          return analysis.status === 'GOLD STANDARD';
      } catch { return false; }
  }).length;

  return (
    <div style={{ backgroundColor: '#0F172A', minHeight: '100vh', color: 'white', fontFamily: 'Inter, system-ui, sans-serif' }}>
      {/* Header */}
      <header style={{ borderBottom: '1px solid rgba(255,255,255,0.1)', padding: '20px 40px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <ShieldCheck size={28} color="#22C55E" />
          <div>
            <h1 style={{ fontSize: '18px', fontWeight: '800', margin: 0 }}>Score de Calidad Visual</h1>
            <p style={{ fontSize: '12px', color: '#94A3B8', margin: 0 }}>BakeOS Quality Analytics</p>
          </div>
        </div>
        <Link href="/" style={{ fontSize: '13px', color: '#94A3B8', textDecoration: 'none', fontWeight: '600' }}>← Dashboard</Link>
      </header>

      <main style={{ padding: '40px', maxWidth: '1200px', margin: '0 auto' }}>
        
        {/* KPI Grid */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '25px', marginBottom: '40px' }}>
          <div style={{ backgroundColor: 'rgba(255,255,255,0.05)', padding: '25px', borderRadius: '24px', border: '1px solid rgba(255,255,255,0.1)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '15px' }}>
              <Star color="#F97316" size={24} />
              <span style={{ fontSize: '11px', color: '#22C55E', fontWeight: 'bold' }}>+12% vs ayer</span>
            </div>
            <h3 style={{ fontSize: '13px', color: '#94A3B8', textTransform: 'uppercase', letterSpacing: '1px', margin: '0 0 8px 0' }}>Score Promedio</h3>
            <p style={{ fontSize: '36px', fontWeight: '900', margin: 0 }}>{avgScore}<span style={{ fontSize: '16px', color: '#475569' }}>/5.0</span></p>
          </div>

          <div style={{ backgroundColor: 'rgba(255,255,255,0.05)', padding: '25px', borderRadius: '24px', border: '1px solid rgba(255,255,255,0.1)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '15px' }}>
              <TrendingUp color="#22C55E" size={24} />
              <span style={{ fontSize: '11px', color: '#22C55E', fontWeight: 'bold' }}>Objetivo: 90%</span>
            </div>
            <h3 style={{ fontSize: '13px', color: '#94A3B8', textTransform: 'uppercase', letterSpacing: '1px', margin: '0 0 8px 0' }}>Gold Standards</h3>
            <p style={{ fontSize: '36px', fontWeight: '900', margin: 0 }}>{goldStandards} <span style={{ fontSize: '16px', color: '#475569' }}>lotes</span></p>
          </div>

          <div style={{ backgroundColor: 'rgba(255,255,255,0.05)', padding: '25px', borderRadius: '24px', border: '1px solid rgba(255,255,255,0.1)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '15px' }}>
              <AlertCircle color="#EF4444" size={24} />
              <span style={{ fontSize: '11px', color: '#EF4444', fontWeight: 'bold' }}>3 críticos</span>
            </div>
            <h3 style={{ fontSize: '13px', color: '#94A3B8', textTransform: 'uppercase', letterSpacing: '1px', margin: '0 0 8px 0' }}>Alertas de Merma</h3>
            <p style={{ fontSize: '36px', fontWeight: '900', margin: 0 }}>0 <span style={{ fontSize: '16px', color: '#475569' }}>rechazos</span></p>
          </div>
        </div>

        {/* Radar Chart: Mapa de Calor de Errores (BakeOS Closing Insight) */}
        <div style={{ marginBottom: '40px', backgroundColor: 'rgba(255,255,255,0.03)', padding: '30px', borderRadius: '24px', border: '1px solid rgba(255,255,255,0.1)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '30px' }}>
            <div>
              <h2 style={{ fontSize: '18px', fontWeight: '800', margin: 0 }}>Mapa de Errores por Categoría</h2>
              <p style={{ fontSize: '12px', color: '#94A3B8', margin: '4px 0 0 0' }}>Frecuencia de defectos detectados por la IA en el último mes</p>
            </div>
            <div style={{ display: 'flex', gap: '15px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '5px', fontSize: '10px' }}><div style={{ width: '8px', height: '8px', backgroundColor: '#F97316', borderRadius: '2px' }}></div> Cookies</div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '5px', fontSize: '10px' }}><div style={{ width: '8px', height: '8px', backgroundColor: '#22C55E', borderRadius: '2px' }}></div> Salados</div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '5px', fontSize: '10px' }}><div style={{ width: '8px', height: '8px', backgroundColor: '#3B82F6', borderRadius: '2px' }}></div> Ensaladas</div>
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '40px', alignItems: 'center' }}>
            {/* SVG Radar Chart */}
            <div style={{ display: 'flex', justifyContent: 'center' }}>
              <svg width="300" height="300" viewBox="0 0 300 300">
                {/* Background Polygons */}
                {[0.2, 0.4, 0.6, 0.8, 1].map((r, i) => (
                  <polygon 
                    key={i}
                    points={`150,${150-120*r} ${150+104*r},${150+60*r} ${150-104*r},${150+60*r}`}
                    fill="none"
                    stroke="rgba(255,255,255,0.1)"
                    strokeWidth="1"
                  />
                ))}
                
                {/* Axis Labels */}
                <text x="150" y="20" textAnchor="middle" fill="#94A3B8" fontSize="10" fontWeight="bold">ESTÉTICA</text>
                <text x="260" y="220" textAnchor="middle" fill="#94A3B8" fontSize="10" fontWeight="bold">COCCIÓN</text>
                <text x="40" y="220" textAnchor="middle" fill="#94A3B8" fontSize="10" fontWeight="bold">MONTAJE</text>

                {/* Data: Cookies (Estética: 0.9, Cocción: 0.4, Montaje: 0.2) */}
                <polygon 
                  points="150,42 222,174 129,162" 
                  fill="rgba(249, 115, 22, 0.3)" 
                  stroke="#F97316" 
                  strokeWidth="2"
                />
                
                {/* Data: Salados (Estética: 0.3, Cocción: 0.9, Montaje: 0.4) */}
                <polygon 
                  points="150,114 254,210 108,174" 
                  fill="rgba(34, 197, 94, 0.3)" 
                  stroke="#22C55E" 
                  strokeWidth="2"
                />

                {/* Data: Ensaladas (Estética: 0.2, Cocción: 0.1, Montaje: 0.9) */}
                <polygon 
                  points="150,126 160,156 46,210" 
                  fill="rgba(59, 130, 246, 0.3)" 
                  stroke="#3B82F6" 
                  strokeWidth="2"
                />
              </svg>
            </div>

            {/* AI Insights per category */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
              <div style={{ borderLeft: '3px solid #F97316', paddingLeft: '15px' }}>
                <h4 style={{ fontSize: '13px', margin: '0 0 5px 0', color: '#F97316' }}>Cookies: Defecto Estético</h4>
                <p style={{ fontSize: '11px', color: '#94A3B8', margin: 0, lineHeight: '1.5' }}>
                  El 78% de los rechazos en cookies se debe a formas irregulares. 
                  <strong>Sugerencia BakeOS:</strong> Revisar el pesaje manual de las bolas de masa o calibrar el boleado.
                </p>
              </div>
              <div style={{ borderLeft: '3px solid #22C55E', paddingLeft: '15px' }}>
                <h4 style={{ fontSize: '13px', margin: '0 0 5px 0', color: '#22C55E' }}>Salados: Defecto de Cocción</h4>
                <p style={{ fontSize: '11px', color: '#94A3B8', margin: 0, lineHeight: '1.5' }}>
                  Tendencia de Maillard alto (quemado) en la base. 
                  <strong>Sugerencia BakeOS:</strong> El Horno A muestra una desviación térmica de +5°C. Programar calibración.
                </p>
              </div>
              <div style={{ borderLeft: '3px solid #3B82F6', paddingLeft: '15px' }}>
                <h4 style={{ fontSize: '13px', margin: '0 0 5px 0', color: '#3B82F6' }}>Ensaladas: Defecto de Montaje</h4>
                <p style={{ fontSize: '11px', color: '#94A3B8', margin: 0, lineHeight: '1.5' }}>
                  Falta recurrente de topping de semillas (22% de los casos). 
                  <strong>Sugerencia BakeOS:</strong> Ajustar el layout de la mesa de preparación para mayor visibilidad de toppings.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Recent Logs Table */}
        <div style={{ backgroundColor: 'rgba(255,255,255,0.02)', borderRadius: '24px', border: '1px solid rgba(255,255,255,0.1)', overflow: 'hidden' }}>
          <div style={{ padding: '25px', borderBottom: '1px solid rgba(255,255,255,0.1)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <h2 style={{ fontSize: '18px', fontWeight: '800', display: 'flex', alignItems: 'center', gap: '10px' }}>
              <History size={20} color="#F97316" /> Registro Histórico
            </h2>
            <button style={{ backgroundColor: 'rgba(255,255,255,0.1)', border: 'none', color: 'white', padding: '8px 15px', borderRadius: '8px', fontSize: '12px', fontWeight: 'bold' }}>Exportar CSV</button>
          </div>

          {loading ? (
            <div style={{ padding: '60px', textAlign: 'center', color: '#94A3B8' }}>Cargando análisis de IA...</div>
          ) : logs.length === 0 ? (
            <div style={{ padding: '60px', textAlign: 'center', color: '#94A3B8' }}>No hay registros de calidad hoy.</div>
          ) : (
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr style={{ textAlign: 'left', backgroundColor: 'rgba(255,255,255,0.05)' }}>
                  <th style={{ padding: '15px 25px', fontSize: '11px', color: '#94A3B8', textTransform: 'uppercase' }}>Fecha/Hora</th>
                  <th style={{ padding: '15px 25px', fontSize: '11px', color: '#94A3B8', textTransform: 'uppercase' }}>Tienda</th>
                  <th style={{ padding: '15px 25px', fontSize: '11px', color: '#94A3B8', textTransform: 'uppercase' }}>Score</th>
                  <th style={{ padding: '15px 25px', fontSize: '11px', color: '#94A3B8', textTransform: 'uppercase' }}>Estado</th>
                  <th style={{ padding: '15px 25px', fontSize: '11px', color: '#94A3B8', textTransform: 'uppercase' }}>Observaciones</th>
                </tr>
              </thead>
              <tbody>
                {logs.map((log, i) => {
                  const analysis = JSON.parse(log.analysis_json);
                  return (
                    <tr key={i} style={{ borderBottom: '1px solid rgba(255,255,255,0.05)' }}>
                      <td style={{ padding: '15px 25px', fontSize: '13px' }}>{new Date(log.timestamp).toLocaleString()}</td>
                      <td style={{ padding: '15px 25px', fontSize: '13px', fontWeight: 'bold' }}>{log.location}</td>
                      <td style={{ padding: '15px 25px', fontSize: '18px', fontWeight: '900', color: '#F97316' }}>{analysis.score}</td>
                      <td style={{ padding: '15px 25px' }}>
                        <span style={{ 
                          fontSize: '10px', 
                          fontWeight: 'bold', 
                          padding: '4px 10px', 
                          borderRadius: '10px', 
                          backgroundColor: analysis.status === 'GOLD STANDARD' ? '#DCFCE7' : analysis.status === 'ACCEPTABLE' ? '#FEF3C7' : '#FEE2E2',
                          color: analysis.status === 'GOLD STANDARD' ? '#166534' : analysis.status === 'ACCEPTABLE' ? '#92400E' : '#991B1B'
                        }}>
                          {analysis.status}
                        </span>
                      </td>
                      <td style={{ padding: '15px 25px', fontSize: '12px', color: '#94A3B8' }}>{analysis.observations}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>

      </main>

      <style jsx global>{`
        table tr:hover { backgroundColor: rgba(255,255,255,0.02); }
      `}</style>
    </div>
  );
}
