'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { Box, RefreshCw, ShoppingBag, CheckCircle2, AlertCircle, TrendingDown } from 'lucide-react';

export default function OmnichannelSyncPage() {
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncData, setSyncData] = useState<any>(null);
  const [stock, setStock] = useState<any[]>([]);

  const fetchStock = async () => {
    const res = await fetch('/api/vision/sync', { method: 'POST' });
    const data = await res.json();
    setSyncData(data);
    setStock(data.stock_snapshot || []);
  };

  useEffect(() => {
    fetchStock();
  }, []);

  const handleSync = async () => {
    setIsSyncing(true);
    await fetchStock();
    setIsSyncing(false);
  };

  const platforms = syncData?.report || [
    { platform: 'Glovo', status: 'Sincronizado', items_synced: 0, timestamp: '-' },
    { platform: 'Uber Eats', status: 'Sincronizado', items_synced: 0, timestamp: '-' },
    { platform: 'Just Eat', status: 'Sincronizado', items_synced: 0, timestamp: '-' },
  ];

  return (
    <div style={{ backgroundColor: '#F8FAFC', minHeight: '100vh', fontFamily: 'Inter, system-ui, sans-serif', color: '#1E293B' }}>
      {/* Header */}
      <header style={{ backgroundColor: 'white', borderBottom: '1px solid #E2E8F0', padding: '20px 40px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', position: 'sticky', top: 0, zIndex: 10 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <div style={{ backgroundColor: '#F97316', padding: '8px', borderRadius: '10px' }}>
            <RefreshCw size={20} color="white" />
          </div>
          <div>
            <h1 style={{ fontSize: '18px', fontWeight: '800', margin: 0 }}>Sincronización Omnicanal</h1>
            <p style={{ fontSize: '12px', color: '#64748B', margin: 0 }}>BakeOS Inventory Bridge</p>
          </div>
        </div>
        <Link href="/" style={{ fontSize: '13px', color: '#64748B', textDecoration: 'none', fontWeight: '600' }}>← Volver</Link>
      </header>

      <main style={{ padding: '40px', maxWidth: '1200px', margin: '0 auto' }}>
        
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: '30px' }}>
          
          {/* Left Column: Platforms */}
          <div>
            <div style={{ 
              backgroundColor: 'white', 
              borderRadius: '24px', 
              padding: '30px', 
              boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)',
              marginBottom: '30px',
              textAlign: 'center'
            }}>
              <div style={{ width: '60px', height: '60px', borderRadius: '50%', backgroundColor: '#DCFCE7', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 20px auto' }}>
                <CheckCircle2 size={30} color="#22C55E" />
              </div>
              <h2 style={{ fontSize: '20px', fontWeight: '800', marginBottom: '8px' }}>Bridge Activo</h2>
              <p style={{ color: '#64748B', fontSize: '13px', marginBottom: '25px' }}>Stock sincronizado con IA.</p>
              
              <button 
                onClick={handleSync}
                disabled={isSyncing}
                style={{ 
                  width: '100%',
                  backgroundColor: '#F97316', 
                  color: 'white', 
                  border: 'none', 
                  padding: '14px', 
                  borderRadius: '12px', 
                  fontSize: '14px', 
                  fontWeight: 'bold', 
                  cursor: isSyncing ? 'default' : 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: '10px'
                }}
              >
                <RefreshCw size={16} className={isSyncing ? 'animate-spin' : ''} />
                {isSyncing ? 'Sincronizando...' : 'Sincronizar Manual'}
              </button>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}>
              {platforms.map((platform: any, i: number) => (
                <div key={i} style={{ backgroundColor: 'white', padding: '20px', borderRadius: '16px', border: '1px solid #E2E8F0', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                    <ShoppingBag size={20} color="#64748B" />
                    <div>
                      <h3 style={{ fontSize: '14px', fontWeight: '700', margin: 0 }}>{platform.platform}</h3>
                      <p style={{ fontSize: '11px', color: '#94A3B8', margin: 0 }}>{platform.items_synced} ítems</p>
                    </div>
                  </div>
                  <span style={{ fontSize: '10px', fontWeight: 'bold', padding: '4px 8px', borderRadius: '8px', backgroundColor: '#DCFCE7', color: '#166534' }}>{platform.status}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Right Column: Inventory Snapshot */}
          <div style={{ backgroundColor: 'white', borderRadius: '24px', border: '1px solid #E2E8F0', overflow: 'hidden' }}>
            <div style={{ padding: '25px', borderBottom: '1px solid #E2E8F0', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <h2 style={{ fontSize: '18px', fontWeight: '800', display: 'flex', alignItems: 'center', gap: '10px' }}>
                <Box size={20} color="#F97316" /> Snapshot de Inventario IA
              </h2>
            </div>
            
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr style={{ textAlign: 'left', backgroundColor: '#F8FAFC' }}>
                  <th style={{ padding: '15px 25px', fontSize: '11px', color: '#64748B', textTransform: 'uppercase' }}>Producto</th>
                  <th style={{ padding: '15px 25px', fontSize: '11px', color: '#64748B', textTransform: 'uppercase' }}>Stock Real</th>
                  <th style={{ padding: '15px 25px', fontSize: '11px', color: '#64748B', textTransform: 'uppercase' }}>Estado Delivery</th>
                </tr>
              </thead>
              <tbody>
                {stock.map((item, i) => (
                  <tr key={i} style={{ borderBottom: '1px solid #F1F5F9' }}>
                    <td style={{ padding: '15px 25px', fontSize: '14px', fontWeight: '600' }}>{item.name}</td>
                    <td style={{ padding: '15px 25px', fontSize: '18px', fontWeight: '800' }}>{item.stock_available}</td>
                    <td style={{ padding: '15px 25px' }}>
                      {item.stock_available < 3 ? (
                        <span style={{ color: '#EF4444', fontSize: '11px', fontWeight: 'bold', display: 'flex', alignItems: 'center', gap: '5px' }}>
                          <TrendingDown size={14} /> PAUSADO / BAJO
                        </span>
                      ) : (
                        <span style={{ color: '#22C55E', fontSize: '11px', fontWeight: 'bold' }}>DISPONIBLE</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

        </div>

      </main>

      <style jsx global>{`
        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        .animate-spin {
          animation: spin 1s linear infinite;
        }
      `}</style>
    </div>
  );
}
