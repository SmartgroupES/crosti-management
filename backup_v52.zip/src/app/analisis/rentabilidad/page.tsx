'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { TrendingUp, Target, PieChart, DollarSign, ArrowLeft, Info, HelpCircle, Zap } from 'lucide-react';

export default function RentabilidadDashboard() {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/analysis/profitability')
      .then(res => res.json())
      .then(json => {
        setData(json);
        setLoading(false);
      })
      .catch(e => console.error(e));
  }, []);

  if (loading) {
    return (
      <div style={{ backgroundColor: '#FAF9F6', minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontSize: '14px', fontWeight: 'bold', marginBottom: '10px' }}>Calculando Rentabilidad...</div>
          <div style={{ color: '#9CA3AF', fontSize: '12px' }}>Cruzando ventas con costos operativos</div>
        </div>
      </div>
    );
  }

  const products = data?.products || [];
  const summary = data?.summary || {};

  const bcgProducts = products.map((p: any) => {
    let type = 'Perro';
    const avgUnits = products.reduce((acc: number, curr: any) => acc + curr.units, 0) / products.length;
    const highVolume = p.units > avgUnits;
    const highMargin = p.marginPercent > 40;

    if (highVolume && highMargin) type = 'Estrella';
    else if (highVolume && !highMargin) type = 'Vaca';
    else if (!highVolume && highMargin) type = 'Interrogante';

    return { ...p, type };
  });

  const stats = [
    { label: 'CONTRIBUCIÓN TOTAL', value: `${summary.totalContribution?.toLocaleString('es-ES')} €`, sub: 'Margen Bruto Acumulado', icon: <TrendingUp size={18} color="#10B981" /> },
    { label: 'GASTOS FIJOS', value: `${summary.totalFixed?.toLocaleString('es-ES')} €`, sub: 'Alquiler + Nómina + Serv.', icon: <Zap size={18} color="#EF4444" /> },
    { label: 'RECUPERACIÓN (BAKEOS)', value: `${summary.recoveryProfit?.toLocaleString('es-ES')} €`, sub: 'Merma evitada (Crunchy/TGTG)', icon: <Zap size={18} color="#F97316" /> },
    { label: 'PUNTO DE EQUILIBRIO', value: `${summary.breakEven?.toLocaleString('es-ES')} €`, sub: 'Ventas mínimas requeridas', icon: <Target size={18} color="#F97316" /> },
  ];

  const bcgMatrix = [
    { name: 'ESTRELLAS', description: 'Alta rentabilidad, alta rotación', items: ['Choco Chip Classic', 'Red Velvet Stuffed'], color: '#EF4444', bg: '#FEF2F2' },
    { name: 'VACAS', description: 'Rentabilidad media, flujo masivo', items: ['Mantequilla', 'Pack 6 Unidades'], color: '#10B981', bg: '#ECFDF5' },
    { name: 'INTERROGANTES', description: 'Alta rentabilidad, baja rotación', items: ['Pistacho Gourmet', 'Lemon Curd'], color: '#F97316', bg: '#FFF7ED' },
    { name: 'PERROS', description: 'Baja rentabilidad, alta merma', items: ['Galleta de Avena (V)', 'Seasonal Pumpkin'], color: '#6B7280', bg: '#F9FAFB' },
  ];

  const realWaste = 350; 
  const avoidedWaste = summary.recoveryProfit || 174;
  const totalPotentialWaste = realWaste + avoidedWaste;
  const avoidedPct = (avoidedWaste / totalPotentialWaste) * 100;
  const realPct = (realWaste / totalPotentialWaste) * 100;

  return (
    <div style={{ backgroundColor: '#FAF9F6', minHeight: '100vh', fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif', color: '#1A1A1A' }}>
      {/* Header */}
      <header style={{ padding: '30px 40px', backgroundColor: 'white', borderBottom: '1px solid #E5E7EB', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <Link href="/" style={{ display: 'flex', alignItems: 'center', gap: '8px', color: '#666', fontSize: '12px', textDecoration: 'none', marginBottom: '8px', fontWeight: 'bold' }}>
            <ArrowLeft size={14} /> VOLVER AL DASHBOARD
          </Link>
          <h1 style={{ fontSize: '24px', fontWeight: 'bold', margin: 0 }}>Análisis de Rentabilidad</h1>
        </div>
        <div style={{ display: 'flex', gap: '12px' }}>
          <button style={{ backgroundColor: 'white', border: '1px solid #E5E7EB', padding: '10px 20px', borderRadius: '12px', fontSize: '13px', fontWeight: 'bold', cursor: 'pointer' }}>Configurar Costos Fijos</button>
          <button style={{ backgroundColor: '#1A1A1A', color: 'white', border: 'none', padding: '10px 20px', borderRadius: '12px', fontSize: '13px', fontWeight: 'bold', cursor: 'pointer' }}>Simular Nuevo Producto</button>
        </div>
      </header>

      <main style={{ padding: '40px', maxWidth: '1200px', margin: '0 auto' }}>
        {/* KPI Cards */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '20px', marginBottom: '40px' }}>
          {stats.map((kpi, idx) => (
            <div key={idx} style={{ backgroundColor: 'white', padding: '24px', borderRadius: '20px', border: '1px solid #E5E7EB' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '16px' }}>
                <div style={{ fontSize: '11px', fontWeight: 'bold', color: '#9CA3AF', letterSpacing: '1px' }}>{kpi.label}</div>
                {kpi.icon}
              </div>
              <div style={{ fontSize: '28px', fontWeight: 'bold', marginBottom: '4px' }}>{kpi.value}</div>
              <div style={{ fontSize: '12px', color: '#6B7280' }}>{kpi.sub}</div>
            </div>
          ))}
        </div>

        {/* Waste Chart (BakeOS Phase 4) */}
        <div style={{ backgroundColor: 'white', padding: '30px', borderRadius: '24px', border: '1px solid #E5E7EB', marginBottom: '40px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '25px' }}>
            <h3 style={{ fontSize: '18px', fontWeight: 'bold', margin: 0 }}>Impacto en Desperdicio de Alimentos</h3>
            <div style={{ fontSize: '12px', color: '#10B981', fontWeight: 'bold' }}>{avoidedPct.toFixed(1)}% MERMA EVITADA POR IA</div>
          </div>
          
          <div style={{ display: 'flex', gap: '5px', alignItems: 'center', height: '60px', backgroundColor: '#F9FAFB', borderRadius: '30px', padding: '5px', overflow: 'hidden' }}>
            <div style={{ width: `${avoidedPct}%`, height: '100%', backgroundColor: '#10B981', borderRadius: '25px', display: 'flex', alignItems: 'center', paddingLeft: '20px', color: 'white', fontSize: '11px', fontWeight: 'bold' }}>
              RECUPERADO: {avoidedWaste}€
            </div>
            <div style={{ width: `${realPct}%`, height: '100%', backgroundColor: '#EF4444', borderRadius: '25px', display: 'flex', alignItems: 'center', justifyContent: 'flex-end', paddingRight: '20px', color: 'white', fontSize: '11px', fontWeight: 'bold' }}>
              MERMA REAL: {realWaste}€
            </div>
          </div>
          <p style={{ marginTop: '15px', fontSize: '12px', color: '#6B7280', textAlign: 'center' }}>
            BakeOS ha rescatado <strong>{avoidedWaste}€</strong> este mes mediante redirección a canales de venta secundaria.
          </p>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.5fr', gap: '30px', marginBottom: '40px' }}>
          {/* BCG Matrix Visualization */}
          <div style={{ backgroundColor: 'white', padding: '30px', borderRadius: '24px', border: '1px solid #E5E7EB' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '24px' }}>
               <h3 style={{ fontSize: '18px', fontWeight: 'bold', margin: 0 }}>Matriz de Portafolio (BCG)</h3>
               <HelpCircle size={16} color="#9CA3AF" cursor="help" />
            </div>
            
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
              {bcgMatrix.map((quadrant, idx) => (
                <div key={idx} style={{ backgroundColor: quadrant.bg, padding: '20px', borderRadius: '16px', border: `1px solid ${quadrant.color}20` }}>
                  <div style={{ fontSize: '11px', fontWeight: 'bold', color: quadrant.color, marginBottom: '4px' }}>{quadrant.name}</div>
                  <div style={{ fontSize: '10px', color: '#666', marginBottom: '12px', lineHeight: '1.4' }}>{quadrant.description}</div>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
                    {quadrant.items.map((item, i) => (
                      <div key={i} style={{ fontSize: '11px', fontWeight: '600', color: '#1A1A1A' }}>• {item}</div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Marginal Contribution Table */}
          <div style={{ backgroundColor: 'white', padding: '30px', borderRadius: '24px', border: '1px solid #E5E7EB' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px' }}>
               <h3 style={{ fontSize: '18px', fontWeight: 'bold', margin: 0 }}>Margen de Contribución por SKU</h3>
               <div style={{ fontSize: '12px', color: '#EF4444', fontWeight: 'bold', cursor: 'pointer' }}>Ver todo →</div>
            </div>

            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr style={{ textAlign: 'left', borderBottom: '1px solid #F3F4F6' }}>
                  <th style={{ padding: '12px 8px', fontSize: '11px', color: '#9CA3AF', fontWeight: 'bold' }}>PRODUCTO</th>
                  <th style={{ padding: '12px 8px', fontSize: '11px', color: '#9CA3AF', fontWeight: 'bold', textAlign: 'right' }}>UNIDADES</th>
                  <th style={{ padding: '12px 8px', fontSize: '11px', color: '#9CA3AF', fontWeight: 'bold', textAlign: 'right' }}>COSTO (CV)</th>
                  <th style={{ padding: '12px 8px', fontSize: '11px', color: '#9CA3AF', fontWeight: 'bold', textAlign: 'right' }}>MARGEN %</th>
                  <th style={{ padding: '12px 8px', fontSize: '11px', color: '#9CA3AF', fontWeight: 'bold', textAlign: 'right' }}>CONTRIBUCIÓN</th>
                  <th style={{ padding: '12px 8px', fontSize: '11px', color: '#9CA3AF', fontWeight: 'bold', textAlign: 'center' }}>TIPO</th>
                </tr>
              </thead>
              <tbody>
                {bcgProducts.map((p: any, idx: number) => (
                  <tr key={idx} style={{ borderBottom: '1px solid #F3F4F6' }}>
                    <td style={{ padding: '16px' }}>
                      <div style={{ fontSize: '14px', fontWeight: 'bold' }}>{p.name}</div>
                    </td>
                    <td style={{ padding: '16px', textAlign: 'right', fontSize: '14px' }}>{p.units}</td>
                    <td style={{ padding: '16px', textAlign: 'right', fontSize: '14px' }}>{p.unitCost?.toFixed(2)} €</td>
                    <td style={{ padding: '16px', textAlign: 'right', fontSize: '14px', fontWeight: 'bold' }}>{p.marginPercent?.toFixed(1)}%</td>
                    <td style={{ padding: '16px', textAlign: 'right', fontSize: '14px', fontWeight: 'bold', color: '#10B981' }}>{p.totalContribution?.toLocaleString('es-ES')} €</td>
                    <td style={{ padding: '16px', textAlign: 'center' }}>
                      <span style={{ 
                        fontSize: '10px', 
                        fontWeight: 'bold', 
                        padding: '4px 8px', 
                        borderRadius: '4px',
                        backgroundColor: p.type === 'Estrella' ? '#FEF2F2' : (p.type === 'Vaca' ? '#F0FDF4' : (p.type === 'Interrogante' ? '#FFFBEB' : '#F3F4F6')),
                        color: p.type === 'Estrella' ? '#EF4444' : (p.type === 'Vaca' ? '#10B981' : (p.type === 'Interrogante' ? '#D97706' : '#6B7280'))
                      }}>
                        {p.type}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Strategic Insights Section */}
        <div style={{ backgroundColor: '#1A1A1A', padding: '40px', borderRadius: '24px', color: 'white' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '20px' }}>
            <Info size={20} color="#EF4444" />
            <h3 style={{ fontSize: '18px', fontWeight: 'bold', margin: 0 }}>Insights Estratégicos de IA</h3>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '24px' }}>
            <div style={{ borderLeft: '3px solid #EF4444', paddingLeft: '20px' }}>
              <div style={{ fontSize: '14px', fontWeight: 'bold', color: '#EF4444', marginBottom: '8px' }}>Oportunidad de Venta Cruzada</div>
              <div style={{ fontSize: '13px', color: '#9CA3AF', lineHeight: '1.6' }}>
                Los "Dilemas" (Pistacho Gourmet) tienen un margen alto pero rotación baja. Se sugiere crear un combo con una "Vaca" (Mantequilla) para incentivar el ticket promedio.
              </div>
            </div>
            <div style={{ borderLeft: '3px solid #10B981', paddingLeft: '20px' }}>
              <div style={{ fontSize: '14px', fontWeight: 'bold', color: '#10B981', marginBottom: '8px' }}>Optimización de Portafolio</div>
              <div style={{ fontSize: '13px', color: '#9CA3AF', lineHeight: '1.6' }}>
                La galleta "Seasonal Pumpkin" es un "Perro" con alta merma. Considerar retiro o cambio de receta para reducir costos de insumos exóticos.
              </div>
            </div>
            <div style={{ borderLeft: '3px solid #F97316', paddingLeft: '20px' }}>
              <div style={{ fontSize: '14px', fontWeight: 'bold', color: '#F97316', marginBottom: '8px' }}>Expansión Sugerida</div>
              <div style={{ fontSize: '13px', color: '#9CA3AF', lineHeight: '1.6' }}>
                La base de "The Dark Side" es muy rentable. Lanzar una variante con relleno de crema de maní aprovecharía insumos de bajo costo y alta visibilidad.
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
