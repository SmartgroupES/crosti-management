'use client';

import React, { useState, useEffect } from 'react';
import { 
  BookOpen, 
  Search, 
  Plus, 
  ChevronRight,
  Database,
  ChefHat,
  CheckCircle,
  Info
} from 'lucide-react';

import RecipeForm from '@/components/recipes/RecipeForm';

export default function RecetasView() {
  const [data, setData] = useState<{ recetas: any[], subRecetas: any[] }>({ recetas: [], subRecetas: [] });
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [activeItems, setActiveItems] = useState<Record<string, boolean>>({});
  const [hoveredRecipe, setHoveredRecipe] = useState<any>(null);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });

  const fetchData = () => {
    setLoading(true);
    fetch('/api/recetas')
      .then(res => res.json())
      .then(json => {
        const rawRecetas = Array.isArray(json.recetas) ? json.recetas : [];
        const rawSubRecetas = Array.isArray(json.subRecetas) ? json.subRecetas : [];
        
        // Agrupar por Producto Terminado
        const groupByProduct = (list: any[]) => {
          const grouped: Record<string, any> = {};
          list.forEach(item => {
            const id = item['PROD. TERMINADO'] || item['SUB RECETA'];
            if (!grouped[id]) {
              grouped[id] = {
                ...item,
                INGREDIENTES: []
              };
            }
            grouped[id].INGREDIENTES.push({
              nombre: item['DESCRIPCIÓN INGREDIENTE'],
              cantidad: item['CANTIDAD'],
              unidad: item['UNIDAD MANEJO'] || item['UNIDAD'],
              costo: item['COSTO INGREDIENTE'] || item['COSTO INGREDIENTES']
            });
          });
          return Object.values(grouped);
        };

        const recetas = groupByProduct(rawRecetas);
        const subRecetas = groupByProduct(rawSubRecetas);
        
        setData({ recetas, subRecetas });
        
        const initialActive: Record<string, boolean> = {};
        [...recetas, ...subRecetas].forEach((item, idx) => {
          const id = item['PROD. TERMINADO'] || item['SUB RECETA'] || `item-${idx}`;
          initialActive[id] = false;
        });
        setActiveItems(initialActive);
        
        setLoading(false);
      })
      .catch(e => {
        console.error(e);
        setLoading(false);
      });
  };

  useEffect(() => {
    fetchData();
  }, []);

  const toggleActive = (id: string) => {
    setActiveItems(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const [viewTab, setViewTab] = useState<'activas' | 'maestro'>('maestro');

  const filterList = (list: any[]) => list.filter(r => {
    const searchLower = searchTerm.toLowerCase();
    const matchesSearch = 
      (r['PROD. TERMINADO']?.toString().toLowerCase() || '').includes(searchLower) ||
      (r['GRUPO']?.toString().toLowerCase() || '').includes(searchLower) ||
      (r['FAMILIA']?.toString().toLowerCase() || '').includes(searchLower);
      
    const id = r['PROD. TERMINADO'] || r['SUB RECETA'];
    const isActive = activeItems[id];
    
    if (viewTab === 'activas') {
      return matchesSearch && isActive;
    } else {
      return matchesSearch || isActive;
    }
  });

  const filteredRecetas = filterList(data.recetas);
  const filteredSubRecetas = filterList(data.subRecetas);

  const Table = ({ title, items, icon: Icon, type }: { title: string, items: any[], icon: any, type: string }) => (
    <div style={{ backgroundColor: 'white', borderRadius: '24px', border: '1px solid #E5E7EB', overflow: 'hidden', marginBottom: '30px' }}>
      <div style={{ padding: '16px 24px', borderBottom: '1px solid #F3F4F6', display: 'flex', justifyContent: 'space-between', alignItems: 'center', backgroundColor: '#FAF9F6' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          {Icon}
          <h3 style={{ fontSize: '14px', fontWeight: '900', color: '#1A1A1A' }}>{title}</h3>
        </div>
        <span style={{ fontSize: '10px', fontWeight: '900', color: '#801515', backgroundColor: '#FEE2E2', padding: '4px 10px', borderRadius: '10px' }}>
          {items.length} PRODUCTOS
        </span>
      </div>
      <div style={{ overflowX: 'auto' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ backgroundColor: '#F9FAFB', textAlign: 'left' }}>
              <th style={{ padding: '12px 24px', width: '40px' }}>
                <input 
                   type="checkbox"
                   checked={items.length > 0 && items.every(item => activeItems[item['PROD. TERMINADO'] || item['SUB RECETA']])}
                   onChange={(e) => {
                     const newValue = e.target.checked;
                     const newActive = { ...activeItems };
                     items.forEach(item => {
                       const id = item['PROD. TERMINADO'] || item['SUB RECETA'];
                       newActive[id] = newValue;
                     });
                     setActiveItems(newActive);
                   }}
                   style={{ width: '18px', height: '18px', cursor: 'pointer', accentColor: '#801515' }}
                />
              </th>
              <th style={{ padding: '12px 24px', fontSize: '10px', color: '#9CA3AF', fontWeight: '900' }}>DESCRIPCIÓN PROD. TERMINADO</th>
              <th style={{ padding: '12px 24px', fontSize: '10px', color: '#9CA3AF', fontWeight: '900' }}>GRUPO</th>
              <th style={{ padding: '12px 24px', fontSize: '10px', color: '#9CA3AF', fontWeight: '900' }}>FAMILIA</th>
              <th style={{ padding: '12px 24px', fontSize: '10px', color: '#9CA3AF', fontWeight: '900', textAlign: 'right' }}>COSTO TOTAL RECETA</th>
              <th style={{ padding: '12px 24px', fontSize: '10px', color: '#9CA3AF', fontWeight: '900', textAlign: 'center' }}>INGREDIENTES</th>
            </tr>
          </thead>
          <tbody>
            {items.map((item, idx) => {
              const id = item['PROD. TERMINADO'] || item['SUB RECETA'];
              const isActive = activeItems[id] || false;
              
              return (
                <tr key={idx} style={{ 
                  borderBottom: '1px solid #F3F4F6',
                  opacity: (viewTab === 'activas' || isActive) ? 1 : 0.4,
                  backgroundColor: (viewTab === 'activas' || isActive) ? 'transparent' : '#F9FAFB',
                  transition: 'all 0.2s'
                }}>
                  <td style={{ padding: '12px 24px' }}>
                    <input 
                      type="checkbox" 
                      checked={isActive} 
                      onChange={() => toggleActive(id)}
                      style={{ width: '18px', height: '18px', cursor: 'pointer', accentColor: '#801515' }}
                    />
                  </td>
                  <td 
                    onMouseEnter={(e) => {
                      setHoveredRecipe(item);
                      setMousePos({ x: e.clientX, y: e.clientY });
                    }}
                    onMouseMove={(e) => setMousePos({ x: e.clientX, y: e.clientY })}
                    onMouseLeave={() => setHoveredRecipe(null)}
                    style={{ 
                      padding: '12px 24px', fontSize: '13px', fontWeight: '900', cursor: 'help',
                      color: (isActive || viewTab === 'activas') ? '#1A1A1A' : '#9CA3AF' 
                    }}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                      {item['PROD. TERMINADO'] || item['SUB RECETA']}
                      <Info size={12} color="#801515" style={{ opacity: 0.5 }} />
                    </div>
                  </td>
                  <td style={{ padding: '12px 24px', fontSize: '11px', fontWeight: '800', color: (isActive || viewTab === 'activas') ? '#801515' : '#9CA3AF' }}>
                    {item['GRUPO'] || 'OTROS'}
                  </td>
                  <td style={{ padding: '12px 24px', fontSize: '11px', fontWeight: '800', color: (isActive || viewTab === 'activas') ? '#B45309' : '#9CA3AF' }}>
                    {item['FAMILIA'] || 'VARIOS'}
                  </td>
                  <td style={{ padding: '12px 24px', fontSize: '14px', fontWeight: '900', textAlign: 'right', color: (isActive || viewTab === 'activas') ? '#10B981' : '#9CA3AF' }}>
                    {Number(item['COSTO RECETA']).toFixed(3)}€
                  </td>
                  <td style={{ padding: '12px 24px', textAlign: 'center' }}>
                    <span style={{ fontSize: '10px', fontWeight: '900', color: '#6B7280', backgroundColor: '#F3F4F6', padding: '2px 8px', borderRadius: '6px' }}>
                      {item.INGREDIENTES?.length || 0} ITEMS
                    </span>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '20px', position: 'relative' }}>
      {/* Tooltip Detalle de Receta */}
      {hoveredRecipe && (
        <div style={{
          position: 'fixed',
          top: mousePos.y + 10,
          left: mousePos.x + 10,
          backgroundColor: 'white',
          borderRadius: '16px',
          boxShadow: '0 20px 40px rgba(0,0,0,0.2)',
          border: '1px solid #E5E7EB',
          padding: '20px',
          zIndex: 9999,
          maxWidth: '400px',
          maxHeight: '400px',
          overflowY: 'auto',
          pointerEvents: 'none'
        }}>
          <div style={{ borderBottom: '1px solid #F3F4F6', paddingBottom: '10px', marginBottom: '10px' }}>
            <h4 style={{ fontSize: '12px', fontWeight: '900', color: '#801515', textTransform: 'uppercase' }}>DETALLE DE RECETA</h4>
            <div style={{ fontSize: '14px', fontWeight: '900', marginTop: '4px' }}>{hoveredRecipe['PROD. TERMINADO'] || hoveredRecipe['SUB RECETA']}</div>
          </div>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ textAlign: 'left', fontSize: '9px', color: '#9CA3AF', fontWeight: '900' }}>
                <th style={{ padding: '4px' }}>INGREDIENTE</th>
                <th style={{ padding: '4px', textAlign: 'center' }}>CANT.</th>
                <th style={{ padding: '4px', textAlign: 'right' }}>COSTO</th>
              </tr>
            </thead>
            <tbody>
              {hoveredRecipe.INGREDIENTES?.map((ing: any, i: number) => (
                <tr key={i} style={{ borderBottom: '1px solid #F9FAFB' }}>
                  <td style={{ padding: '6px 4px', fontSize: '11px', fontWeight: '700', color: '#374151' }}>{ing.nombre}</td>
                  <td style={{ padding: '6px 4px', fontSize: '11px', fontWeight: '800', textAlign: 'center' }}>{Number(ing.cantidad).toFixed(3)} {ing.unidad}</td>
                  <td style={{ padding: '6px 4px', fontSize: '11px', fontWeight: '900', textAlign: 'right', color: '#10B981' }}>{Number(ing.costo).toFixed(3)}€</td>
                </tr>
              ))}
            </tbody>
          </table>
          <div style={{ marginTop: '12px', paddingTop: '10px', borderTop: '2px solid #F3F4F6', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ fontSize: '10px', fontWeight: '900', color: '#6B7280' }}>COSTO TOTAL:</span>
            <span style={{ fontSize: '14px', fontWeight: '900', color: '#801515' }}>{Number(hoveredRecipe['COSTO RECETA']).toFixed(3)}€</span>
          </div>
        </div>
      )}

      {/* 1. Header and Actions */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
         <div style={{ display: 'flex', gap: '20px', alignItems: 'center' }}>
            <div>
              <h2 style={{ fontSize: '14px', fontWeight: '900', color: '#1A1A1A', marginBottom: '4px' }}>RECETARIO MAESTRO</h2>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: '#801515', fontWeight: '800', fontSize: '12px' }}>
                 <Database size={14} /> {Object.values(activeItems).filter(v => v).length} ACTIVAS
              </div>
            </div>
            
            <div style={{ display: 'flex', backgroundColor: '#F3F4F6', padding: '4px', borderRadius: '12px', gap: '4px' }}>
              <button 
                onClick={() => setViewTab('activas')}
                style={{ 
                  padding: '6px 16px', borderRadius: '10px', border: 'none', fontSize: '10px', fontWeight: '900',
                  backgroundColor: viewTab === 'activas' ? 'white' : 'transparent',
                  color: viewTab === 'activas' ? '#801515' : '#6B7280',
                  cursor: 'pointer', transition: 'all 0.2s', boxShadow: viewTab === 'activas' ? '0 2px 4px rgba(0,0,0,0.05)' : 'none'
                }}
              >
                PRODUCTOS ACTIVOS
              </button>
              <button 
                onClick={() => setViewTab('maestro')}
                style={{ 
                  padding: '6px 16px', borderRadius: '10px', border: 'none', fontSize: '10px', fontWeight: '900',
                  backgroundColor: viewTab === 'maestro' ? 'white' : 'transparent',
                  color: viewTab === 'maestro' ? '#801515' : '#6B7280',
                  cursor: 'pointer', transition: 'all 0.2s', boxShadow: viewTab === 'maestro' ? '0 2px 4px rgba(0,0,0,0.05)' : 'none'
                }}
              >
                MAESTRO (TOTAL)
              </button>
            </div>
         </div>
         <button 
           onClick={() => setShowForm(true)}
           style={{ 
            backgroundColor: '#1A1A1A', color: 'white', padding: '10px 20px', 
            borderRadius: '12px', fontSize: '11px', fontWeight: '900', border: 'none',
            display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer'
         }}>
            <Plus size={14} color="#F97316" /> NUEVA RECETA
         </button>
      </div>

      {/* 2. Search & Bulk Actions */}
      <div style={{ display: 'flex', gap: '12px' }}>
         <div style={{ position: 'relative', flex: 1 }}>
            <Search size={18} style={{ position: 'absolute', left: '16px', top: '50%', transform: 'translateY(-50%)', color: '#801515' }} />
            <input 
               type="text" 
               placeholder="BUSCAR PRODUCTO O CATEGORÍA..."
               value={searchTerm}
               onChange={(e) => setSearchTerm(e.target.value)}
               style={{ 
                  width: '100%', padding: '14px 14px 14px 48px', borderRadius: '16px',
                  border: '1px solid #E5E7EB', fontSize: '13px', fontWeight: '700',
                  boxShadow: '0 4px 15px rgba(0,0,0,0.03)', outline: 'none'
               }}
            />
         </div>
         {searchTerm && (
           <button 
             onClick={() => {
               const newActive = { ...activeItems };
               [...filteredRecetas, ...filteredSubRecetas].forEach(item => {
                 const id = item['PROD. TERMINADO'] || item['SUB RECETA'];
                 newActive[id] = true;
               });
               setActiveItems(newActive);
             }}
             style={{ 
               backgroundColor: '#801515', color: 'white', padding: '0 20px', 
               borderRadius: '16px', fontSize: '11px', fontWeight: '900', border: 'none',
               cursor: 'pointer', transition: 'all 0.2s', display: 'flex', alignItems: 'center', gap: '8px'
             }}
           >
              <CheckCircle size={16} /> ACTIVAR RESULTADOS
           </button>
         )}
      </div>

      {loading ? (
        <div style={{ padding: '60px', textAlign: 'center' }}>
          <div style={{ fontSize: '13px', fontWeight: '800', color: '#9CA3AF' }}>SINCRONIZANDO RECETAS...</div>
        </div>
      ) : (
        <>
          <Table 
            title="PRODUCTOS TERMINADOS" 
            items={filteredRecetas} 
            icon={<BookOpen size={18} color="#801515" />} 
            type="receta"
          />
          <Table 
            title="SUB-RECETAS / ELABORACIONES" 
            items={filteredSubRecetas} 
            icon={<ChefHat size={18} color="#F97316" />} 
            type="subreceta"
          />
        </>
      )}

      {showForm && (
        <RecipeForm 
          onClose={() => setShowForm(false)} 
          onSuccess={() => {
            fetchData();
            setShowForm(false);
          }} 
        />
      )}
    </div>
  );
}
