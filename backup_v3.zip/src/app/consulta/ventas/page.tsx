'use client';

import React from 'react';
import { TrendingUp, Package, Trash2, AlertTriangle, Zap } from 'lucide-react';

export default function VentasPage() {
  const kpis = [
    { label: 'Ø VENTA SEMANAL (4 SEM)', value: '0', subvalue: 'Esperando datos de Crosti', icon: <TrendingUp size={24} color="#666" /> },
    { label: 'PRODUCCIÓN PLANIFICADA', value: '0', subvalue: 'unidades esta semana', icon: <Package size={24} color="#F97316" /> },
    { label: 'Ø MERMA SEMANAL', value: '0', subvalue: '(0%) unidades desperdicio', icon: <Trash2 size={24} color="#666" /> },
    { label: 'MAYOR MERMA', value: '-', subvalue: 'Sin registros', icon: <AlertTriangle size={24} color="#666" /> },
  ];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      {/* Quick Action Button */}
      <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
        <button style={{ 
          backgroundColor: '#F97316', 
          color: 'white', 
          border: 'none', 
          padding: '10px 20px', 
          borderRadius: '10px', 
          fontSize: '12px', 
          fontWeight: 'bold', 
          display: 'flex', 
          alignItems: 'center', 
          gap: '8px',
          boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
        }}>
          <Zap size={16} fill="white" /> Corte en Vivo <span style={{ backgroundColor: 'rgba(0,0,0,0.2)', padding: '2px 6px', borderRadius: '4px', fontSize: '10px' }}>ANÁLISIS RÁPIDO</span>
        </button>
      </div>

      {/* KPI Cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '20px' }}>
        {kpis.map((kpi, idx) => (
          <div key={idx} style={{ backgroundColor: 'white', padding: '24px', borderRadius: '16px', border: '1px solid #E5E7EB' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '12px' }}>
              <div style={{ fontSize: '11px', fontWeight: 'bold', color: '#9CA3AF', letterSpacing: '0.5px' }}>{kpi.label}</div>
              {kpi.icon}
            </div>
            <div style={{ fontSize: '28px', fontWeight: '900', color: '#1A1A1A', marginBottom: '4px' }}>{kpi.value}</div>
            <div style={{ fontSize: '12px', color: '#6B7280' }}>{kpi.subvalue}</div>
          </div>
        ))}
      </div>

      {/* Main Chart Section */}
      <div style={{ backgroundColor: 'white', padding: '30px', borderRadius: '20px', border: '1px solid #E5E7EB' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '30px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <div style={{ backgroundColor: '#FEE2E2', padding: '6px', borderRadius: '6px' }}><TrendingUp size={16} color="#EF4444" /></div>
            <h3 style={{ fontSize: '16px', fontWeight: 'bold', margin: 0 }}>Venta por Mes y Año</h3>
          </div>
          <div style={{ display: 'flex', gap: '15px', fontSize: '12px', color: '#666' }}>
            {['2023', '2024', '2025', '2026'].map(year => (
              <label key={year} style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                <input type="checkbox" checked={year === '2025' || year === '2026'} readOnly /> {year}
              </label>
            ))}
            <label style={{ display: 'flex', alignItems: 'center', gap: '4px', marginLeft: '10px' }}>
              <input type="checkbox" checked readOnly /> Promedio
            </label>
          </div>
        </div>

        {/* Mock Chart Area */}
        <div style={{ height: '300px', width: '100%', position: 'relative', borderBottom: '1px solid #E5E7EB', borderLeft: '1px solid #E5E7EB', display: 'flex', alignItems: 'flex-end', paddingBottom: '30px' }}>
          {/* Y-axis labels */}
          <div style={{ position: 'absolute', left: '-45px', height: '100%', display: 'flex', flexDirection: 'column', justifyContent: 'space-between', fontSize: '10px', color: '#9CA3AF' }}>
            <span>700K €</span><span>600K €</span><span>500K €</span><span>400K €</span><span>300K €</span><span>200K €</span><span>100K €</span><span>0K €</span>
          </div>

          {/* Average Line */}
          <div style={{ position: 'absolute', bottom: '150px', width: '100%', borderTop: '2px dashed #9CA3AF', opacity: 0.5 }}></div>

          {/* Chart Path Placeholder */}
          <svg style={{ width: '100%', height: '100%', overflow: 'visible' }}>
            <path d="M0 50 L100 80 L200 40 L300 250 L400 280" fill="none" stroke="#F97316" strokeWidth="3" />
            <circle cx="0" cy="50" r="4" fill="#F97316" />
            <circle cx="100" cy="80" r="4" fill="#F97316" />
            <circle cx="200" cy="40" r="4" fill="#F97316" />
            <circle cx="300" cy="250" r="4" fill="#F97316" />
          </svg>

          {/* X-axis labels */}
          <div style={{ position: 'absolute', bottom: '-25px', width: '100%', display: 'flex', justifyContent: 'space-between', fontSize: '10px', color: '#9CA3AF' }}>
            <span>Enero</span><span>Febrero</span><span>Marzo</span><span>Abril</span><span>Mayo</span><span>Junio</span><span>Julio</span><span>Agosto</span><span>Septiembre</span><span>Octubre</span><span>Noviembre</span><span>Diciembre</span>
          </div>
        </div>
      </div>

      {/* Secondary Chart Section */}
      <div style={{ backgroundColor: 'white', padding: '30px', borderRadius: '20px', border: '1px solid #E5E7EB' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '20px' }}>
           <div style={{ backgroundColor: '#DBEAFE', padding: '6px', borderRadius: '6px' }}><TrendingUp size={16} color="#2563EB" /></div>
           <h3 style={{ fontSize: '16px', fontWeight: 'bold', margin: 0 }}>Venta por Semana 2026</h3>
        </div>
        <div style={{ height: '150px', backgroundColor: '#F9FAFB', borderRadius: '12px', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#9CA3AF', fontSize: '14px' }}>
          Gráfico de tendencia semanal...
        </div>
      </div>
    </div>
  );
}
