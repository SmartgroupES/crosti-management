'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { Camera, Box, Upload, X } from 'lucide-react';

export default function InventarioFotoPage() {
  const [selectedStore, setSelectedStore] = useState('');
  
  return (
    <div style={{ backgroundColor: '#F3F4F6', minHeight: '100vh', fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif' }}>
      {/* Header */}
      <header style={{ backgroundColor: '#F97316', color: 'white', padding: '15px 40px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
           <div style={{ backgroundColor: 'rgba(255,255,255,0.2)', padding: '6px', borderRadius: '6px' }}><Box size={20} /></div>
           <div>
             <h1 style={{ fontSize: '16px', fontWeight: 'bold', margin: 0 }}>Inventario de Cierre</h1>
             <p style={{ fontSize: '11px', margin: 0, opacity: 0.9 }}>Maison Kayser — Conteo diario al cierre</p>
           </div>
        </div>
        <Link href="/inventario" style={{ fontSize: '12px', color: 'white', textDecoration: 'none', fontWeight: 'bold' }}>← Cambiar modo</Link>
      </header>

      {/* Select Store */}
      <div style={{ padding: '20px 40px', backgroundColor: 'white', borderBottom: '1px solid #E5E7EB' }}>
        <label style={{ fontSize: '12px', color: '#666', display: 'block', marginBottom: '8px' }}>Selecciona tu tienda:</label>
        <select 
          value={selectedStore}
          onChange={(e) => setSelectedStore(e.target.value)}
          style={{ width: '100%', padding: '12px', borderRadius: '8px', border: '1px solid #E5E7EB', fontSize: '14px', backgroundColor: '#F9FAFB' }}
        >
          <option value="">— Seleccionar —</option>
          <option value="ALCALA">ALCALÁ</option>
          <option value="RETIRO">RETIRO</option>
        </select>
      </div>

      <main style={{ padding: '40px' }}>
        {/* Upload Area */}
        <div style={{ 
          backgroundColor: 'white', 
          border: '2px dashed #D1D5DB', 
          borderRadius: '20px', 
          padding: '60px 40px',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          textAlign: 'center',
          cursor: 'pointer',
          marginBottom: '24px'
        }}>
          <Camera size={48} color="#9CA3AF" style={{ marginBottom: '20px' }} />
          <h3 style={{ fontSize: '18px', fontWeight: 'bold', marginBottom: '8px' }}>Toca para tomar o seleccionar fotos</h3>
          <p style={{ fontSize: '12px', color: '#9CA3AF' }}>Máximo 5 fotos - JPG o PNG</p>
        </div>

        {/* Note Area */}
        <div style={{ backgroundColor: 'white', borderRadius: '12px', border: '1px solid #E5E7EB', padding: '15px' }}>
          <label style={{ fontSize: '12px', fontWeight: 'bold', color: '#6B7280', display: 'block', marginBottom: '10px' }}>Nota opcional:</label>
          <textarea 
            placeholder="Ej: Faltó contar la vitrina de pan..."
            style={{ width: '100%', border: 'none', resize: 'none', outline: 'none', fontSize: '14px', minHeight: '80px', color: '#1A1A1A' }}
          />
        </div>

        <div style={{ textAlign: 'center', marginTop: '20px', fontSize: '12px', color: '#F97316', fontWeight: 'bold' }}>
          Domingo 26 de abril 2026
        </div>
      </main>

      {/* Footer Bar */}
      <div style={{ position: 'fixed', bottom: 0, left: 0, right: 0, backgroundColor: 'white', borderTop: '1px solid #E5E7EB', padding: '15px 40px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div style={{ fontSize: '12px', color: '#666' }}>
          <strong>0</strong> foto(s) seleccionada(s)
        </div>
        <button style={{ backgroundColor: '#D1D5DB', color: 'white', border: 'none', padding: '12px 30px', borderRadius: '12px', fontSize: '14px', fontWeight: 'bold', cursor: 'default' }}>
          Enviar Fotos
        </button>
      </div>
    </div>
  );
}
