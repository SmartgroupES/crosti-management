'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { ArrowLeft, Box, ChevronRight, Send } from 'lucide-react';

export default function InventarioFormularioPage() {
  const [selectedStore, setSelectedStore] = useState('');
  
  const products = [
    { id: '60210002', name: 'Croissant', count: 0 },
    { id: '60210009', name: 'Pan de chocolate', count: 0 },
    { id: '30010001', name: 'Mini Croissant', count: 0 },
    { id: '60210006', name: 'Mini Pan Chocolate', count: 0 },
    { id: '60210001', name: 'Caracol', count: 0 },
    { id: '60110003', name: 'Brioche con Manteq. y Mermelada', count: 0 },
    { id: '60110002', name: 'Brioche con Nutella', count: 0 },
    { id: '60110007', name: 'Brioche Nature pequeña', count: 0 },
    { id: '70010008', name: 'Madalena', count: 0 },
  ];

  return (
    <div style={{ backgroundColor: '#F3F4F6', minHeight: '100vh', fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif' }}>
      {/* Header */}
      <header style={{ backgroundColor: '#F97316', color: 'white', padding: '15px 40px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
           <div style={{ backgroundColor: 'rgba(255,255,255,0.2)', padding: '6px', borderRadius: '6px' }}><Box size={20} /></div>
           <div>
             <h1 style={{ fontSize: '16px', fontWeight: 'bold', margin: 0 }}>Inventario de Cierre</h1>
             <p style={{ fontSize: '11px', margin: 0, opacity: 0.9 }}>Maison Kayser — Conteo diario al cierre</p>
           </div>
        </div>
        <Link href="/inventario" style={{ fontSize: '12px', color: 'white', textDecoration: 'none', fontWeight: 'bold' }}>← Cambiar modo</Link>
      </header>

      {/* Select Store */}
      <div style={{ padding: '20px 40px', backgroundColor: 'white', borderBottom: '1px solid #E5E7EB' }}>
        <label style={{ fontSize: '12px', color: '#666', display: 'block', marginBottom: '8px' }}>Selecciona tu tienda:</label>
        <select 
          value={selectedStore}
          onChange={(e) => setSelectedStore(e.target.value)}
          style={{ width: '100%', padding: '12px', borderRadius: '8px', border: '1px solid #E5E7EB', fontSize: '14px', backgroundColor: '#F9FAFB' }}
        >
          <option value="">— Seleccionar —</option>
          <option value="ALCALA">ALCALÁ</option>
          <option value="RETIRO">RETIRO</option>
        </select>
      </div>

      <div style={{ padding: '15px 40px', fontSize: '12px', color: '#F97316', fontWeight: 'bold' }}>
        Domingo 26 de abril 2026
      </div>

      {/* Product List */}
      <div style={{ padding: '0 40px 100px 40px' }}>
        <div style={{ backgroundColor: '#F97316', color: 'white', padding: '12px 20px', borderRadius: '12px 12px 0 0', fontSize: '13px', fontWeight: 'bold', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
           Bollería (28)
           <ChevronRight size={16} />
        </div>
        <div style={{ backgroundColor: 'white', borderRadius: '0 0 12px 12px', border: '1px solid #E5E7EB', borderTop: 'none' }}>
           {products.map((p, idx) => (
             <div key={idx} style={{ padding: '15px 20px', borderBottom: idx === products.length - 1 ? 'none' : '1px solid #F3F4F6', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
               <div>
                 <div style={{ fontSize: '13px', fontWeight: 'bold', color: '#1A1A1A' }}>{p.name}</div>
                 <div style={{ fontSize: '10px', color: '#9CA3AF' }}>{p.id}</div>
               </div>
               <input 
                 type="number" 
                 defaultValue={0}
                 style={{ width: '60px', padding: '10px', borderRadius: '8px', border: '1px solid #E5E7EB', textAlign: 'right', fontSize: '14px', fontWeight: 'bold' }}
               />
             </div>
           ))}
        </div>
      </div>

      {/* Footer Bar */}
      <div style={{ position: 'fixed', bottom: 0, left: 0, right: 0, backgroundColor: 'white', borderTop: '1px solid #E5E7EB', padding: '15px 40px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div style={{ fontSize: '12px', color: '#666' }}>
          <strong>0 de 97</strong> productos
        </div>
        <button style={{ backgroundColor: '#D1D5DB', color: 'white', border: 'none', padding: '12px 30px', borderRadius: '12px', fontSize: '14px', fontWeight: 'bold', cursor: 'default' }}>
          Enviar
        </button>
      </div>
    </div>
  );
}
