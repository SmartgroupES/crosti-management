'use client';

import React from 'react';
import Link from 'next/link';
import { Printer, Download, ArrowLeft, CheckCircle2, AlertTriangle, Zap, Cookie } from 'lucide-react';

export default function PropuestaProduccionPage() {
  const suggestedProduction = [
    { name: 'Choco Chip Classic', target: 120, closing: 5, production: 115, status: 'HIGH' },
    { name: 'Red Velvet Stuffed', target: 80, closing: 2, production: 78, status: 'NORMAL' },
    { name: 'Pistacho Gourmet', target: 40, closing: 0, production: 40, status: 'TRENDING' },
    { name: 'Biscoff Lava', target: 60, closing: 3, production: 57, status: 'NORMAL' },
  ];

  return (
    <div style={{ backgroundColor: '#FAF9F6', minHeight: '100vh', fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif', color: '#1A1A1A' }}>
      {/* Header */}
      <header style={{ padding: '30px 40px', backgroundColor: 'white', borderBottom: '1px solid #E5E7EB', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <Link href="/planificacion" style={{ display: 'flex', alignItems: 'center', gap: '8px', color: '#666', fontSize: '12px', textDecoration: 'none', marginBottom: '8px', fontWeight: 'bold' }}>
            <ArrowLeft size={14} /> VOLVER A PLANIFICACIÓN
          </Link>
          <h1 style={{ fontSize: '24px', fontWeight: 'bold', margin: 0 }}>Propuesta de Producción</h1>
          <p style={{ fontSize: '13px', color: '#9CA3AF', margin: '4px 0 0 0' }}>Plan para mañana: {new Date(Date.now() + 86400000).toLocaleDateString('es-ES', { day: 'numeric', month: 'long' })}</p>
        </div>
        <div style={{ display: 'flex', gap: '12px' }}>
          <button style={{ backgroundColor: 'white', border: '1px solid #E5E7EB', padding: '10px 20px', borderRadius: '12px', fontSize: '13px', fontWeight: 'bold', display: 'flex', alignItems: 'center', gap: '8px' }}>
            <Printer size={16} /> Imprimir Hoja
          </button>
          <button style={{ backgroundColor: '#1A1A1A', color: 'white', border: 'none', padding: '10px 20px', borderRadius: '12px', fontSize: '13px', fontWeight: 'bold', display: 'flex', alignItems: 'center', gap: '8px' }}>
            <CheckCircle2 size={16} /> Aprobar Todo
          </button>
        </div>
      </header>

      <main style={{ padding: '40px', maxWidth: '1000px', margin: '0 auto' }}>
        
        {/* Intelligence Alert */}
        <div style={{ backgroundColor: '#F0FDF4', border: '1px solid #BBF7D0', padding: '20px', borderRadius: '24px', display: 'flex', gap: '16px', marginBottom: '40px' }}>
          <div style={{ backgroundColor: '#BBF7D0', width: '40px', height: '40px', borderRadius: '12px', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
            <Zap size={20} color="#166534" />
          </div>
          <div>
            <div style={{ fontSize: '14px', fontWeight: 'bold', color: '#166534', marginBottom: '4px' }}>Análisis de IA Completado</div>
            <p style={{ fontSize: '13px', color: '#166534', margin: 0, opacity: 0.8, lineHeight: '1.5' }}>
              La propuesta se ha ajustado considerando el inventario de cierre de hoy y la tendencia de ventas para los jueves. Se ha detectado un aumento en la demanda de "Pistacho Gourmet" (+15%) en los últimos 7 días.
            </p>
          </div>
        </div>

        {/* Bake Sheet Table */}
        <div style={{ backgroundColor: 'white', borderRadius: '24px', border: '1px solid #E5E7EB', overflow: 'hidden' }}>
          <div style={{ padding: '24px', borderBottom: '1px solid #F3F4F6', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <h3 style={{ fontSize: '16px', fontWeight: 'bold', margin: 0 }}>Hoja de Horneado (Bake Sheet)</h3>
            <div style={{ fontSize: '12px', color: '#9CA3AF' }}>Total Unidades: 290</div>
          </div>
          
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ backgroundColor: '#F9FAFB', textAlign: 'left' }}>
                <th style={{ padding: '16px 24px', fontSize: '11px', color: '#9CA3AF', fontWeight: 'bold' }}>PRODUCTO</th>
                <th style={{ padding: '16px 24px', fontSize: '11px', color: '#9CA3AF', fontWeight: 'bold', textAlign: 'right' }}>CIERRE HOY</th>
                <th style={{ padding: '16px 24px', fontSize: '11px', color: '#9CA3AF', fontWeight: 'bold', textAlign: 'right' }}>OBJETIVO STOCK</th>
                <th style={{ padding: '16px 24px', fontSize: '11px', color: '#9CA3AF', fontWeight: 'bold', textAlign: 'right' }}>A HORNEAR</th>
                <th style={{ padding: '16px 24px', fontSize: '11px', color: '#9CA3AF', fontWeight: 'bold' }}>PRIORIDAD</th>
              </tr>
            </thead>
            <tbody>
              {suggestedProduction.map((item, idx) => (
                <tr key={idx} style={{ borderBottom: '1px solid #F3F4F6' }}>
                  <td style={{ padding: '20px 24px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                      <div style={{ backgroundColor: '#FAF9F6', padding: '8px', borderRadius: '8px' }}><Cookie size={16} color="#D97706" /></div>
                      <span style={{ fontSize: '14px', fontWeight: 'bold' }}>{item.name}</span>
                    </div>
                  </td>
                  <td style={{ padding: '20px 24px', textAlign: 'right', fontSize: '14px', color: '#6B7280' }}>{item.closing}</td>
                  <td style={{ padding: '20px 24px', textAlign: 'right', fontSize: '14px', color: '#6B7280' }}>{item.target}</td>
                  <td style={{ padding: '20px 24px', textAlign: 'right', fontSize: '18px', fontWeight: 'bold', color: '#1A1A1A' }}>{item.production}</td>
                  <td style={{ padding: '20px 24px' }}>
                    <span style={{ 
                      fontSize: '10px', 
                      fontWeight: 'bold', 
                      padding: '4px 8px', 
                      borderRadius: '4px',
                      backgroundColor: item.status === 'HIGH' ? '#FEF2F2' : (item.status === 'TRENDING' ? '#FEF3C7' : '#F0FDF4'),
                      color: item.status === 'HIGH' ? '#EF4444' : (item.status === 'TRENDING' ? '#D97706' : '#10B981')
                    }}>
                      {item.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div style={{ marginTop: '30px', display: 'flex', justifyContent: 'flex-end', gap: '20px' }}>
           <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: '#9CA3AF', fontSize: '12px' }}>
              <AlertTriangle size={14} /> Los valores pueden ajustarse manualmente si hay eventos especiales.
           </div>
        </div>

      </main>
    </div>
  );
}
