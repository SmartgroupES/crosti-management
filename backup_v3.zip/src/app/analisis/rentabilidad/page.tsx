'use client';

import React from 'react';
import Link from 'next/link';
import { TrendingUp, Target, PieChart, DollarSign, ArrowLeft, Info, HelpCircle } from 'lucide-react';

export default function RentabilidadPage() {
  const kpis = [
    { label: 'MARGEN PROMEDIO', value: '68%', subvalue: '+2.4% vs mes anterior', icon: <PieChart size={20} color="#10B981" /> },
    { label: 'PUNTO DE EQUILIBRIO', value: '420', subvalue: 'galletas/día para cubrir fijos', icon: <Target size={20} color="#F97316" /> },
    { label: 'PRODUCTO ESTRELLA', value: 'Choco Chip', subvalue: 'Margen: 74% | Vol: Alto', icon: <TrendingUp size={20} color="#EF4444" /> },
    { label: 'COSTOS FIJOS', value: '4.500 €', subvalue: 'Presupuesto mensual', icon: <DollarSign size={20} color="#6B7280" /> },
  ];

  const bcgMatrix = [
    { name: 'ESTRELLAS', description: 'Alta rentabilidad, alta rotación', items: ['Choco Chip Classic', 'Red Velvet Stuffed'], color: '#EF4444', bg: '#FEF2F2' },
    { name: 'VACAS', description: 'Rentabilidad media, flujo masivo', items: ['Mantequilla', 'Pack 6 Unidades'], color: '#10B981', bg: '#ECFDF5' },
    { name: 'DILEMAS', description: 'Alta rentabilidad, baja rotación', items: ['Pistacho Gourmet', 'Lemon Curd'], color: '#F97316', bg: '#FFF7ED' },
    { name: 'PERROS', description: 'Baja rentabilidad, alta merma', items: ['Galleta de Avena (V)', 'Seasonal Pumpkin'], color: '#6B7280', bg: '#F9FAFB' },
  ];

  const productMargins = [
    { name: 'Choco Chip Classic', price: '3.50 €', cost: '0.91 €', margin: '2.59 €', index: '74%', status: 'STAR' },
    { name: 'Red Velvet Stuffed', price: '4.50 €', cost: '1.20 €', margin: '3.30 €', index: '73%', status: 'STAR' },
    { name: 'Pistacho Gourmet', price: '5.00 €', cost: '2.10 €', margin: '2.90 €', index: '58%', status: 'DILEMA' },
    { name: 'Mantequilla Simple', price: '2.80 €', cost: '0.70 €', margin: '2.10 €', index: '75%', status: 'VACA' },
    { name: 'Biscoff Lava', price: '4.80 €', cost: '1.80 €', margin: '3.00 €', index: '62%', status: 'DILEMA' },
  ];

  return (
    <div style={{ backgroundColor: '#FAF9F6', minHeight: '100vh', fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif', color: '#1A1A1A' }}>
      {/* Header */}
      <header style={{ padding: '30px 40px', backgroundColor: 'white', borderBottom: '1px solid #E5E7EB', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <Link href="/" style={{ display: 'flex', alignItems: 'center', gap: '8px', color: '#666', fontSize: '12px', textDecoration: 'none', marginBottom: '8px', fontWeight: 'bold' }}>
            <ArrowLeft size={14} /> VOLVER AL DASHBOARD
          </Link>
          <h1 style={{ fontSize: '24px', fontWeight: 'bold', margin: 0 }}>Análisis de Rentabilidad</h1>
        </div>
        <div style={{ display: 'flex', gap: '12px' }}>
          <button style={{ backgroundColor: 'white', border: '1px solid #E5E7EB', padding: '10px 20px', borderRadius: '12px', fontSize: '13px', fontWeight: 'bold', cursor: 'pointer' }}>Configurar Costos Fijos</button>
          <button style={{ backgroundColor: '#1A1A1A', color: 'white', border: 'none', padding: '10px 20px', borderRadius: '12px', fontSize: '13px', fontWeight: 'bold', cursor: 'pointer' }}>Simular Nuevo Producto</button>
        </div>
      </header>

      <main style={{ padding: '40px', maxWidth: '1200px', margin: '0 auto' }}>
        {/* KPI Cards */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: '20px', marginBottom: '40px' }}>
          {kpis.map((kpi, idx) => (
            <div key={idx} style={{ backgroundColor: 'white', padding: '24px', borderRadius: '20px', border: '1px solid #E5E7EB' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '16px' }}>
                <div style={{ fontSize: '11px', fontWeight: 'bold', color: '#9CA3AF', letterSpacing: '1px' }}>{kpi.label}</div>
                {kpi.icon}
              </div>
              <div style={{ fontSize: '28px', fontWeight: 'bold', marginBottom: '4px' }}>{kpi.value}</div>
              <div style={{ fontSize: '12px', color: '#6B7280' }}>{kpi.subvalue}</div>
            </div>
          ))}
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.5fr', gap: '30px', marginBottom: '40px' }}>
          {/* BCG Matrix Visualization */}
          <div style={{ backgroundColor: 'white', padding: '30px', borderRadius: '24px', border: '1px solid #E5E7EB' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '24px' }}>
               <h3 style={{ fontSize: '18px', fontWeight: 'bold', margin: 0 }}>Matriz de Portafolio (BCG)</h3>
               <HelpCircle size={16} color="#9CA3AF" cursor="help" />
            </div>
            
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
              {bcgMatrix.map((quadrant, idx) => (
                <div key={idx} style={{ backgroundColor: quadrant.bg, padding: '20px', borderRadius: '16px', border: `1px solid ${quadrant.color}20` }}>
                  <div style={{ fontSize: '11px', fontWeight: 'bold', color: quadrant.color, marginBottom: '4px' }}>{quadrant.name}</div>
                  <div style={{ fontSize: '10px', color: '#666', marginBottom: '12px', lineHeight: '1.4' }}>{quadrant.description}</div>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
                    {quadrant.items.map((item, i) => (
                      <div key={i} style={{ fontSize: '11px', fontWeight: '600', color: '#1A1A1A' }}>• {item}</div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Marginal Contribution Table */}
          <div style={{ backgroundColor: 'white', padding: '30px', borderRadius: '24px', border: '1px solid #E5E7EB' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px' }}>
               <h3 style={{ fontSize: '18px', fontWeight: 'bold', margin: 0 }}>Margen de Contribución por SKU</h3>
               <div style={{ fontSize: '12px', color: '#EF4444', fontWeight: 'bold', cursor: 'pointer' }}>Ver todo →</div>
            </div>

            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr style={{ textAlign: 'left', borderBottom: '1px solid #F3F4F6' }}>
                  <th style={{ padding: '12px 8px', fontSize: '11px', color: '#9CA3AF', fontWeight: 'bold' }}>PRODUCTO</th>
                  <th style={{ padding: '12px 8px', fontSize: '11px', color: '#9CA3AF', fontWeight: 'bold', textAlign: 'right' }}>PVP</th>
                  <th style={{ padding: '12px 8px', fontSize: '11px', color: '#9CA3AF', fontWeight: 'bold', textAlign: 'right' }}>COSTO (CV)</th>
                  <th style={{ padding: '12px 8px', fontSize: '11px', color: '#9CA3AF', fontWeight: 'bold', textAlign: 'right' }}>MARGEN €</th>
                  <th style={{ padding: '12px 8px', fontSize: '11px', color: '#9CA3AF', fontWeight: 'bold', textAlign: 'right' }}>ÍNDICE %</th>
                </tr>
              </thead>
              <tbody>
                {productMargins.map((product, idx) => (
                  <tr key={idx} style={{ borderBottom: '1px solid #F9FAFB' }}>
                    <td style={{ padding: '16px 8px', fontSize: '13px', fontWeight: '600' }}>{product.name}</td>
                    <td style={{ padding: '16px 8px', fontSize: '13px', textAlign: 'right' }}>{product.price}</td>
                    <td style={{ padding: '16px 8px', fontSize: '13px', textAlign: 'right', color: '#666' }}>{product.cost}</td>
                    <td style={{ padding: '16px 8px', fontSize: '13px', textAlign: 'right', fontWeight: 'bold', color: '#10B981' }}>{product.margin}</td>
                    <td style={{ padding: '16px 8px', fontSize: '13px', textAlign: 'right' }}>
                      <span style={{ 
                        backgroundColor: parseInt(product.index) > 70 ? '#ECFDF5' : '#FFF7ED', 
                        color: parseInt(product.index) > 70 ? '#059669' : '#D97706', 
                        padding: '4px 8px', 
                        borderRadius: '6px', 
                        fontWeight: 'bold',
                        fontSize: '11px'
                      }}>
                        {product.index}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Strategic Insights Section */}
        <div style={{ backgroundColor: '#1A1A1A', padding: '40px', borderRadius: '24px', color: 'white' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '20px' }}>
            <Info size={20} color="#EF4444" />
            <h3 style={{ fontSize: '18px', fontWeight: 'bold', margin: 0 }}>Insights Estratégicos de IA</h3>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '24px' }}>
            <div style={{ borderLeft: '3px solid #EF4444', paddingLeft: '20px' }}>
              <div style={{ fontSize: '14px', fontWeight: 'bold', color: '#EF4444', marginBottom: '8px' }}>Oportunidad de Venta Cruzada</div>
              <div style={{ fontSize: '13px', color: '#9CA3AF', lineHeight: '1.6' }}>
                Los "Dilemas" (Pistacho Gourmet) tienen un margen alto pero rotación baja. Se sugiere crear un combo con una "Vaca" (Mantequilla) para incentivar el ticket promedio.
              </div>
            </div>
            <div style={{ borderLeft: '3px solid #10B981', paddingLeft: '20px' }}>
              <div style={{ fontSize: '14px', fontWeight: 'bold', color: '#10B981', marginBottom: '8px' }}>Optimización de Portafolio</div>
              <div style={{ fontSize: '13px', color: '#9CA3AF', lineHeight: '1.6' }}>
                La galleta "Seasonal Pumpkin" es un "Perro" con alta merma. Considerar retiro o cambio de receta para reducir costos de insumos exóticos.
              </div>
            </div>
            <div style={{ borderLeft: '3px solid #F97316', paddingLeft: '20px' }}>
              <div style={{ fontSize: '14px', fontWeight: 'bold', color: '#F97316', marginBottom: '8px' }}>Expansión Sugerida</div>
              <div style={{ fontSize: '13px', color: '#9CA3AF', lineHeight: '1.6' }}>
                La base de "The Dark Side" es muy rentable. Lanzar una variante con relleno de crema de maní aprovecharía insumos de bajo costo y alta visibilidad.
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
