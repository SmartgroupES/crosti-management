'use client';

import React from 'react';
import Header from '@/components/Header';
import { 
  BarChart3, 
  TrendingUp, 
  Calculator, 
  BookOpen, 
  Calendar, 
  ChefHat, 
  Trash2, 
  ShoppingCart, 
  Package, 
  Settings, 
  Camera, 
  Zap, 
  Layout, 
  CheckCircle2, 
  Users, 
  Clock, 
  ShieldCheck,
  LayoutDashboard,
  Trophy,
  Activity,
  Award
} from 'lucide-react';

export default function HomePage() {

  const sections = [
    {
      title: "Comercial",
      items: [
        { label: "Seguimiento de Ventas", href: "/consulta/ventas", icon: <TrendingUp size={16} /> },
        { label: "Rentabilidad", href: "/analisis/rentabilidad", icon: <Calculator size={16} /> },
        { label: "Simulador de Costos", href: "/admin/simulador", icon: <LayoutDashboard size={16} /> },
        { label: "Gestión de Recetas", href: "/admin/escandallos", icon: <BookOpen size={16} /> }
      ]
    },
    {
      title: "Operaciones",
      items: [
        { label: "Planificación de Producción", href: "/planificacion", icon: <Calendar size={16} /> },
        { label: "Gestión de Catering", href: "/produccion/catering", icon: <ChefHat size={16} /> },
        { label: "Merma", href: "/produccion/merma", icon: <Trash2 size={16} /> },
        { label: "Compras", href: "/inventario/compras", icon: <ShoppingCart size={16} /> },
        { label: "Control de Stock", href: "/inventario/stock", icon: <Package size={16} /> },
        { label: "Mantenimiento", href: "/admin/mantenimiento", icon: <Settings size={16} /> }
      ]
    },
    {
      title: "Merchandising",
      items: [
        { label: "Auditoría Visual IA", href: "/inventario/foto", icon: <Camera size={16} /> },
        { label: "Optimización de Vitrina", href: "/analisis/layout", icon: <Layout size={16} /> },
        { label: "Layout Advisor", href: "/analisis/omnichannel", icon: <Zap size={16} /> }
      ]
    },
    {
      title: "Talento",
      items: [
        { label: "Incentivos", href: "/admin/personal", icon: <Award size={16} /> },
        { label: "Ranking de Tiendas", href: "/admin/saas-command-center", icon: <Trophy size={16} /> },
        { label: "Log de Interacción", href: "/admin/appcc", icon: <Activity size={16} /> }
      ]
    }
  ];

  return (
    <div className="fade-in" style={{ 
      minHeight: '100vh', 
      width: '100%',
      padding: '140px 4% 60px 4%',
      display: 'flex',
      flexDirection: 'column',
      backgroundColor: '#8B151B', // Corporate Red Background for consistency
      backgroundImage: 'radial-gradient(circle at 10% 20%, rgba(255,255,255,0.05) 0%, transparent 40%), radial-gradient(circle at 90% 80%, rgba(0,0,0,0.1) 0%, transparent 40%)',
      position: 'relative',
      overflowX: 'hidden'
    }}>
      <Header />

      <div style={{
        maxWidth: '1600px',
        margin: '0 auto',
        width: '100%',
        position: 'relative',
        zIndex: 1
      }}>
        {/* Main 4-Column Structure */}
        <div style={{ 
          display: 'grid', 
          gridTemplateColumns: 'repeat(4, 1fr)', 
          gap: '24px',
          width: '100%'
        }}>
          {sections.map((section, idx) => (
            <div key={idx} style={{ 
              display: 'flex', 
              flexDirection: 'column', 
              gap: '24px' 
            }}>
              {/* Section Header (Small Caps) */}
              <div style={{ 
                paddingBottom: '12px',
                borderBottom: '1px solid rgba(255, 255, 255, 0.2)',
                marginBottom: '8px'
              }}>
                <h2 style={{ 
                  fontSize: '11px', 
                  fontWeight: '900', 
                  letterSpacing: '3px',
                  textTransform: 'uppercase',
                  color: 'rgba(255, 255, 255, 0.7)',
                  fontVariant: 'small-caps',
                  margin: 0
                }}>
                  {section.title}
                </h2>
              </div>
              
              {/* Chips / Tabs List */}
              <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                {section.items.map((item, i) => (
                  <button 
                    key={i}
                    onClick={() => window.location.href = item.href}
                    style={{
                      backgroundColor: '#FFF5D1', // Cream Chip
                      border: 'none',
                      padding: '14px 20px',
                      borderRadius: '30px', // Chip style
                      color: '#8B151B', // Red text
                      fontSize: '13px',
                      fontWeight: '800',
                      cursor: 'pointer',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      gap: '12px',
                      transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
                      textAlign: 'left',
                      boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
                      position: 'relative',
                      overflow: 'hidden'
                    }}
                    onMouseOver={(e) => {
                      e.currentTarget.style.transform = 'translateY(-3px) scale(1.02)';
                      e.currentTarget.style.boxShadow = '0 12px 24px rgba(0,0,0,0.2)';
                      e.currentTarget.style.backgroundColor = '#FFFFFF';
                    }}
                    onMouseOut={(e) => {
                      e.currentTarget.style.transform = 'translateY(0) scale(1)';
                      e.currentTarget.style.boxShadow = '0 4px 12px rgba(0,0,0,0.1)';
                      e.currentTarget.style.backgroundColor = '#FFF5D1';
                    }}
                  >
                    <span style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                      {item.label}
                    </span>
                    <span style={{ 
                      opacity: 0.3,
                      backgroundColor: 'rgba(139, 21, 27, 0.1)',
                      padding: '6px',
                      borderRadius: '50%',
                      display: 'flex'
                    }}>
                      {item.icon}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Decorative Branding Text */}
      <div style={{
        position: 'fixed',
        bottom: '40px',
        right: '40px',
        opacity: 0.1,
        pointerEvents: 'none',
        zIndex: 0
      }}>
        <h1 style={{ 
          fontSize: '120px', 
          margin: 0, 
          fontWeight: 900, 
          color: 'white',
          lineHeight: 0.8,
          letterSpacing: '-5px'
        }}>
          BakeOS
        </h1>
      </div>

      <style jsx global>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .fade-in {
          animation: fadeIn 0.8s ease-out forwards;
        }
      `}</style>
    </div>
  );
}
