'use client';

import React, { useState, useEffect } from 'react';
import Header from '@/components/Header';
import { 
  Database, 
  HardDrive, 
  Send, 
  FileText, 
  History, 
  AlertOctagon, 
  ArrowLeft, 
  CheckCircle2, 
  Mail, 
  MessageSquare, 
  Terminal as TerminalIcon,
  Clock,
  ExternalLink,
  ChevronRight,
  ShieldCheck,
  Zap,
  Activity,
  Lock,
  Cpu
} from 'lucide-react';
import { useRouter } from 'next/navigation';

export default function VaultAdminPage() {
  const router = useRouter();
  const [activeNode, setActiveNode] = useState<string | null>(null);
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [secondConfirm, setSecondConfirm] = useState(false);

  const d1Tables = [
    { name: 'ventas_hub', records: 12450, health: 'OPTIMAL', type: 'RELATIONAL' },
    { name: 'inventario_real', records: 850, health: 'OPTIMAL', type: 'RELATIONAL' },
    { name: 'personal_logins', records: 42, health: 'STABLE', type: 'AUTH' },
    { name: 'catering_orders', records: 310, health: 'OPTIMAL', type: 'OPS' },
    { name: 'recetas_escandallos', records: 125, health: 'OPTIMAL', type: 'RECIPES' },
  ];

  const versionHistory = [
    { version: 'v68', date: '2026-05-01', desc: 'Hardware-Ready Vision: LiDAR & White Balance normalization.' },
    { version: 'v65', date: '2026-05-01', desc: '4-Pillar Dashboard Redesign: Dark Glass aesthetic.' },
    { version: 'v63', date: '2026-05-01', desc: 'Export API: Edge Worker implementation for Excel/PDF.' },
    { version: 'v60', date: '2026-04-30', desc: 'Initial Security Vault: Restricted Superadmin access.' },
  ];

  const documents = [
    { name: 'Manual Calibración LiDAR IA', icon: <Cpu size={18} /> },
    { name: 'Protocolos de Seguridad R2', icon: <ShieldCheck size={18} /> },
    { name: 'Arquitectura D1 Relacional', icon: <Database size={18} /> },
    { name: 'Guía de Programación API', icon: <FileText size={18} /> },
  ];

  const handleReset = () => {
    alert("SYSTEM_PURGE_EXECUTED. ALL CACHE CLEARED.");
    window.location.reload();
  };

  return (
    <div style={{ 
      backgroundColor: '#121212', // Carbon Black
      minHeight: '100vh', 
      color: '#FFD700', // Gold details
      fontFamily: '"JetBrains Mono", "Courier New", monospace',
      padding: '140px 5% 60px 5%',
      backgroundImage: 'radial-gradient(circle at 50% 50%, rgba(255, 215, 0, 0.03) 0%, transparent 80%)',
      position: 'relative'
    }}>
      <Header />

      <div style={{ maxWidth: '1600px', margin: '0 auto' }}>
        
        {/* Header Terminal */}
        <div style={{ 
          display: 'flex', 
          justifyContent: 'space-between', 
          alignItems: 'flex-end', 
          borderBottom: '2px solid rgba(255, 215, 0, 0.15)', 
          paddingBottom: '40px',
          marginBottom: '60px'
        }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '16px', marginBottom: '16px' }}>
              <Lock color="#FFD700" size={36} />
              <h1 style={{ fontSize: '32px', fontWeight: '900', letterSpacing: '4px', margin: 0 }}>BAKEOS_VAULT_v2.0</h1>
            </div>
            <div style={{ display: 'flex', gap: '24px', fontSize: '10px', opacity: 0.5, fontWeight: '800', letterSpacing: '1px' }}>
              <span>ENCRYPTED_SESSION: ACTIVE</span>
              <span>NODE: CF_MAD_V1</span>
              <span>AUTH_LEVEL: SUPERADMIN</span>
            </div>
          </div>
          <button 
            onClick={() => router.push('/')}
            style={{ 
              backgroundColor: 'rgba(255, 215, 0, 0.05)', border: '1px solid #FFD700', color: '#FFD700', padding: '12px 28px', borderRadius: '8px', cursor: 'pointer', fontSize: '11px', fontWeight: '900', display: 'flex', alignItems: 'center', gap: '12px', letterSpacing: '2px' 
            }}
          >
            <ArrowLeft size={16} /> EXIT_RELIQUARY
          </button>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(12, 1fr)', gap: '40px' }}>
          
          {/* Main Content Area */}
          <div style={{ gridColumn: 'span 8', display: 'flex', flexDirection: 'column', gap: '40px' }}>
            
            {/* 1. D1 Schema Visual */}
            <div style={{ backgroundColor: 'rgba(255, 215, 0, 0.02)', border: '1px solid rgba(255, 215, 0, 0.1)', borderRadius: '24px', padding: '40px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '40px' }}>
                <Database size={20} />
                <h2 style={{ fontSize: '13px', fontWeight: '900', letterSpacing: '2px', textTransform: 'uppercase' }}>Cloudflare D1 Visual Schema</h2>
              </div>
              
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '20px' }}>
                {d1Tables.map(table => (
                  <div 
                    key={table.name}
                    onClick={() => setActiveNode(activeNode === table.name ? null : table.name)}
                    style={{ 
                      padding: '24px',
                      backgroundColor: activeNode === table.name ? 'rgba(255, 215, 0, 0.1)' : 'rgba(0,0,0,0.3)',
                      border: `1px solid ${activeNode === table.name ? '#FFD700' : 'rgba(255, 215, 0, 0.1)'}`,
                      borderRadius: '16px',
                      cursor: 'pointer',
                      transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)'
                    }}
                  >
                    <div style={{ fontSize: '14px', fontWeight: '900', marginBottom: '14px', color: activeNode === table.name ? '#FFD700' : 'rgba(255,255,255,0.7)' }}>{table.name}</div>
                    <div style={{ fontSize: '10px', opacity: 0.5, letterSpacing: '1px' }}>{table.type}</div>
                    {activeNode === table.name && (
                      <div style={{ marginTop: '16px', paddingTop: '16px', borderTop: '1px solid rgba(255,215,0,0.1)', fontSize: '11px', lineHeight: '1.8' }}>
                        <div style={{ color: '#10B981' }}>HEALTH: {table.health}</div>
                        <div>ROWS: {table.records.toLocaleString()}</div>
                        <div>ID: UUID_V4</div>
                      </div>
                    )}
                  </div>
                ))}
              </div>

              {/* R2 Monitor */}
              <div style={{ marginTop: '40px', paddingTop: '32px', borderTop: '1px solid rgba(255, 215, 0, 0.1)', display: 'flex', justifyContent: 'space-between' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '20px' }}>
                  <HardDrive size={28} />
                  <div>
                    <div style={{ fontSize: '10px', opacity: 0.5, letterSpacing: '1px' }}>R2_BUCKET_VOLUME (IMAGES)</div>
                    <div style={{ fontSize: '20px', fontWeight: '900' }}>12.4 GB / 100 GB</div>
                  </div>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <div style={{ fontSize: '10px', opacity: 0.5, letterSpacing: '1px' }}>OP_COST_ESTIMATE</div>
                  <div style={{ fontSize: '20px', fontWeight: '900', color: '#10B981' }}>$2.45 USD</div>
                </div>
              </div>
            </div>

            {/* 2. Automated Reports Panel */}
            <div style={{ backgroundColor: 'rgba(255, 215, 0, 0.02)', border: '1px solid rgba(255, 215, 0, 0.1)', borderRadius: '24px', padding: '40px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '40px' }}>
                <Send size={20} />
                <h2 style={{ fontSize: '13px', fontWeight: '900', letterSpacing: '2px', textTransform: 'uppercase' }}>Automated Report Dispatcher</h2>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '48px' }}>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                  {[
                    { label: 'DAILY_EMAIL_ANALYTICS', icon: <Mail size={16} />, active: true },
                    { label: 'CRITICAL_WA_ALERTS', icon: <MessageSquare size={16} />, active: true },
                    { label: 'MONTHLY_TG_DUMP', icon: <Send size={16} />, active: false },
                  ].map(toggle => (
                    <div key={toggle.label} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '16px', border: '1px solid rgba(255, 215, 0, 0.1)', borderRadius: '12px' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '12px', fontSize: '11px', fontWeight: '700' }}>
                        {toggle.icon} {toggle.label}
                      </div>
                      <div style={{ width: '44px', height: '22px', borderRadius: '11px', backgroundColor: toggle.active ? '#FFD700' : 'rgba(255,255,255,0.05)', position: 'relative', cursor: 'pointer', border: '1px solid rgba(255,215,0,0.2)' }}>
                        <div style={{ position: 'absolute', top: '2px', left: toggle.active ? '24px' : '2px', width: '16px', height: '16px', borderRadius: '50%', backgroundColor: toggle.active ? '#121212' : '#FFD700', transition: 'all 0.3s ease' }} />
                      </div>
                    </div>
                  ))}
                </div>

                <div style={{ backgroundColor: 'rgba(0,0,0,0.3)', padding: '24px', borderRadius: '16px', border: '1px solid rgba(255, 215, 0, 0.1)' }}>
                  <div style={{ fontSize: '10px', opacity: 0.4, marginBottom: '20px', letterSpacing: '2px' }}>LOGS_TRANSMISSION_FEED</div>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
                    {[
                      { dest: 'ncarrillok@gmail.com', time: '09:01', status: 'CONFIRMED' },
                      { dest: 'Crosti_Manager_WA', time: '08:55', status: 'CONFIRMED' },
                      { dest: 'Audit_Secondary_Bot', time: '07:30', status: 'QUEUED' },
                    ].map((msg, i) => (
                      <div key={i} style={{ display: 'flex', justifyContent: 'space-between', fontSize: '11px' }}>
                        <span style={{ fontWeight: '600' }}>{msg.dest}</span>
                        <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
                          <span style={{ opacity: 0.4 }}>{msg.time}</span>
                          <CheckCircle2 size={12} color={msg.status === 'CONFIRMED' ? '#10B981' : '#FFD700'} />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

          </div>

          {/* Sidebar Area */}
          <div style={{ gridColumn: 'span 4', display: 'flex', flexDirection: 'column', gap: '40px' }}>
            
            {/* 3. PDF Manuals Library */}
            <div style={{ backgroundColor: 'rgba(255, 215, 0, 0.02)', border: '1px solid rgba(255, 215, 0, 0.1)', borderRadius: '24px', padding: '40px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '32px' }}>
                <FileText size={20} />
                <h2 style={{ fontSize: '13px', fontWeight: '900', letterSpacing: '2px', textTransform: 'uppercase' }}>Technical Manuals</h2>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                {documents.map(doc => (
                  <div key={doc.name} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '20px', backgroundColor: 'rgba(0,0,0,0.3)', borderRadius: '12px', cursor: 'pointer', border: '1px solid rgba(255,215,0,0.05)', transition: 'all 0.2s' }} className="vault-doc">
                    <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
                      <div style={{ color: '#FFD700' }}>{doc.icon}</div>
                      <span style={{ fontSize: '12px', fontWeight: '700' }}>{doc.name}</span>
                    </div>
                    <ExternalLink size={14} opacity={0.3} />
                  </div>
                ))}
              </div>
            </div>

            {/* 4. System Timeline */}
            <div style={{ backgroundColor: 'rgba(255, 215, 0, 0.02)', border: '1px solid rgba(255, 215, 0, 0.1)', borderRadius: '24px', padding: '40px', flex: 1 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '40px' }}>
                <History size={20} />
                <h2 style={{ fontSize: '13px', fontWeight: '900', letterSpacing: '2px', textTransform: 'uppercase' }}>Update History</h2>
              </div>
              <div style={{ position: 'relative', paddingLeft: '24px', borderLeft: '1px solid rgba(255, 215, 0, 0.2)' }}>
                {versionHistory.map((h, i) => (
                  <div key={h.version} style={{ position: 'relative', marginBottom: '32px' }}>
                    <div style={{ position: 'absolute', left: '-30px', top: '0', width: '10px', height: '10px', borderRadius: '50%', backgroundColor: i === 0 ? '#FFD700' : '#121212', border: '2px solid #FFD700' }} />
                    <div style={{ fontSize: '12px', fontWeight: '900', marginBottom: '6px' }}>{h.version} | {h.date}</div>
                    <div style={{ fontSize: '11px', opacity: 0.5, lineHeight: '1.6' }}>{h.desc}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* 5. Emergency Purge */}
            <div style={{ marginTop: 'auto' }}>
              {!showResetConfirm ? (
                <button 
                  onClick={() => setShowResetConfirm(true)}
                  style={{ width: '100%', backgroundColor: 'transparent', border: '1px solid #EF4444', color: '#EF4444', padding: '24px', borderRadius: '16px', fontSize: '12px', fontWeight: '900', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '12px', letterSpacing: '2px' }}
                >
                  <AlertOctagon size={20} /> SYSTEM_PURGE_RESET
                </button>
              ) : (
                <div style={{ backgroundColor: '#EF4444', color: 'white', padding: '32px', borderRadius: '16px', animation: 'blink 0.5s infinite' }}>
                  <div style={{ fontWeight: '900', fontSize: '14px', marginBottom: '20px', textAlign: 'center' }}>!!! WARNING: DATA LOSS IMMINENT !!!</div>
                  {!secondConfirm ? (
                    <button onClick={() => setSecondConfirm(true)} style={{ width: '100%', backgroundColor: 'white', color: '#EF4444', border: 'none', padding: '16px', fontWeight: '900', cursor: 'pointer', borderRadius: '8px' }}>INITIALIZE_PURGE_SEQUENCE</button>
                  ) : (
                    <div style={{ display: 'flex', gap: '12px' }}>
                      <button onClick={handleReset} style={{ flex: 1, backgroundColor: 'black', color: 'white', border: 'none', padding: '16px', fontWeight: '900', cursor: 'pointer', borderRadius: '8px' }}>EXECUTE</button>
                      <button onClick={() => { setShowResetConfirm(false); setSecondConfirm(false); }} style={{ flex: 1, backgroundColor: 'white', color: '#EF4444', border: 'none', padding: '16px', fontWeight: '900', cursor: 'pointer', borderRadius: '8px' }}>ABORT</button>
                    </div>
                  )}
                </div>
              )}
            </div>

          </div>
        </div>
      </div>

      <style jsx global>{`
        @import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;700;800&display=swap');
        @keyframes blink {
          0% { opacity: 1; }
          50% { opacity: 0.7; }
          100% { opacity: 1; }
        }
        .vault-doc:hover {
          background-color: rgba(255, 215, 0, 0.05) !important;
          border-color: rgba(255, 215, 0, 0.3) !important;
          transform: translateX(4px);
        }
        ::-webkit-scrollbar { width: 4px; }
        ::-webkit-scrollbar-track { background: #121212; }
        ::-webkit-scrollbar-thumb { background: rgba(255, 215, 0, 0.2); border-radius: 10px; }
      `}</style>
    </div>
  );
}
