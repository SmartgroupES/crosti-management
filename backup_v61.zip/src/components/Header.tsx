'use client';

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Globe, LogOut, User, ChevronDown } from 'lucide-react';

export default function Header() {
  const router = useRouter();
  const [lang, setLang] = useState('ES');
  const [showLangMenu, setShowLangMenu] = useState(false);
  const [userName, setUserName] = useState('Usuario');

  useEffect(() => {
    const name = document.cookie
      .split('; ')
      .find(row => row.startsWith('user_name='))
      ?.split('=')[1];
    if (name) setUserName(decodeURIComponent(name));
  }, []);

  const handleLogout = async () => {
    await fetch('/api/auth/login', { method: 'DELETE' });
    router.push('/login');
  };

  return (
    <header style={{
      width: '96%',
      margin: '16px 2%',
      padding: '12px 24px',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      position: 'fixed',
      top: 0,
      left: 0,
      zIndex: 1000,
      borderRadius: '16px',
      backgroundColor: 'rgba(15, 15, 15, 0.75)', // Contenedor oscuro traslúcido
      backdropFilter: 'blur(12px)',
      WebkitBackdropFilter: 'blur(12px)',
      border: '1px solid rgba(255, 255, 255, 0.1)',
      boxShadow: '0 8px 32px rgba(0,0,0,0.3)'
    }}>
      {/* Left: Crosti Logo & Title */}
      <div 
        onClick={() => router.push('/')}
        style={{ 
          display: 'flex', 
          alignItems: 'center', 
          gap: '12px', 
          cursor: 'pointer'
        }}
      >
        <img 
          src="/logo-crosti.jpg" 
          alt="Crosti Logo" 
          style={{ 
            height: '40px', 
            borderRadius: '8px'
          }} 
        />
        <div style={{ display: 'flex', flexDirection: 'column' }}>
          <span style={{ 
            fontSize: '16px', 
            fontWeight: '900', 
            color: 'white',
            letterSpacing: '0.5px'
          }}>
            CROSTI HUB
          </span>
          <span style={{ 
            fontSize: '9px', 
            fontWeight: '600', 
            color: 'rgba(255,255,255,0.5)',
            textTransform: 'uppercase',
            letterSpacing: '1px'
          }}>
            Management Suite
          </span>
        </div>
      </div>

      {/* Center: BakeOS Badge */}
      <div style={{
        backgroundColor: 'rgba(249, 115, 22, 0.15)',
        color: '#F97316',
        padding: '6px 14px',
        borderRadius: '20px',
        fontSize: '10px',
        fontWeight: '900',
        letterSpacing: '1.5px',
        border: '1px solid rgba(249, 115, 22, 0.3)',
        display: 'flex',
        alignItems: 'center',
        gap: '6px'
      }}>
        <div style={{ width: '6px', height: '6px', borderRadius: '50%', backgroundColor: '#F97316' }} />
        BAKEOS POWERED
      </div>

      {/* Right: Actions & Profile */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '20px' }}>
        {/* Language */}
        <div style={{ position: 'relative' }}>
          <button 
            onClick={() => setShowLangMenu(!showLangMenu)}
            style={{
              background: 'none',
              border: 'none',
              color: 'white',
              fontSize: '12px',
              fontWeight: '700',
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              cursor: 'pointer'
            }}
          >
            <Globe size={16} />
            {lang}
            <ChevronDown size={12} />
          </button>
          
          {showLangMenu && (
            <div style={{
              position: 'absolute',
              top: '40px',
              right: 0,
              backgroundColor: '#1A1A1A',
              borderRadius: '8px',
              overflow: 'hidden',
              minWidth: '100px',
              border: '1px solid rgba(255,255,255,0.1)'
            }}>
              {['ES', 'EN'].map((l) => (
                <div 
                  key={l}
                  onClick={() => { setLang(l); setShowLangMenu(false); }}
                  style={{ 
                    padding: '10px 16px', 
                    color: 'white', 
                    fontSize: '12px', 
                    cursor: 'pointer' 
                  }}
                >
                  {l === 'ES' ? 'Español' : 'English'}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Profile */}
        <div 
          onMouseDown={() => {
            const timer = setTimeout(() => {
              router.push('/admin/hidden');
            }, 3000);
            (window as any)._adminTimer = timer;
          }}
          onMouseUp={() => {
            clearTimeout((window as any)._adminTimer);
          }}
          onMouseLeave={() => {
            clearTimeout((window as any)._adminTimer);
          }}
          onTouchStart={() => {
            const timer = setTimeout(() => {
              router.push('/admin/hidden');
            }, 3000);
            (window as any)._adminTimer = timer;
          }}
          onTouchEnd={() => {
            clearTimeout((window as any)._adminTimer);
          }}
          style={{ 
            display: 'flex', 
            alignItems: 'center', 
            gap: '10px',
            paddingLeft: '16px',
            borderLeft: '1px solid rgba(255,255,255,0.1)',
            cursor: 'help'
          }}
        >
          <div style={{ textAlign: 'right' }}>
            <div style={{ fontSize: '12px', fontWeight: '800', color: 'white' }}>{userName}</div>
            <div style={{ fontSize: '9px', fontWeight: '600', color: 'rgba(255,255,255,0.4)' }}>Superadmin</div>
          </div>
          <div style={{
            width: '32px',
            height: '32px',
            borderRadius: '8px',
            backgroundColor: 'rgba(255,255,255,0.1)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center'
          }}>
            <User size={18} color="white" />
          </div>
        </div>

        {/* Logout Button */}
        <button 
          onClick={handleLogout}
          style={{ 
            background: 'rgba(239, 68, 68, 0.15)', 
            border: '1px solid rgba(239, 68, 68, 0.3)', 
            color: '#EF4444', 
            padding: '8px',
            borderRadius: '8px',
            cursor: 'pointer',
            display: 'flex'
          }}
          title="Cerrar Sesión"
        >
          <LogOut size={16} />
        </button>
      </div>
    </header>
  );
}
