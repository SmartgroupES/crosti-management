'use client';

import React, { useState, useEffect } from 'react';
import SubPageLayout from '@/components/SubPageLayout';
import { 
  TrendingUp, 
  Download, 
  FileText, 
  Calendar, 
  Store,
  Loader2,
  BarChart3
} from 'lucide-react';

export default function VentasPage() {
  const [loading, setLoading] = useState(true);
  const [hoveredBar, setHoveredBar] = useState<number | null>(null);

  useEffect(() => {
    // Simulate loading
    setTimeout(() => setLoading(false), 1200);
  }, []);

  const kpis = [
    { label: 'Venta Hoy', value: '1.240,50€' },
    { label: 'Semana Actual', value: '8.450,20€' },
    { label: 'Mes en Curso', value: '32.100,00€' },
    { label: 'Cierre Anual Proyectado', value: '385.000€' },
  ];

  const chartData = [
    { month: 'ENE', sales: 45000 },
    { month: 'FEB', sales: 52000 },
    { month: 'MAR', sales: 48000 },
    { month: 'ABR', sales: 61000 },
    { month: 'MAY', sales: 55000 },
    { month: 'JUN', sales: 67000 },
    { month: 'JUL', sales: 72000 },
    { month: 'AGO', sales: 69000 },
    { month: 'SEP', sales: 58000 },
    { month: 'OCT', sales: 63000 },
    { month: 'NOV', sales: 70000 },
    { month: 'DIC', sales: 85000 },
  ];

  const topProducts = [
    { name: 'Cruasán de Mantequilla', percent: 85, amount: '12.450€' },
    { name: 'Napolitana de Chocolate', percent: 72, amount: '9.820€' },
    { name: 'Pan Gallego Artesano', percent: 65, amount: '8.100€' },
    { name: 'Ensaimada Mallorquina', percent: 48, amount: '5.400€' },
    { name: 'Tarta de Queso Crosti', percent: 35, amount: '4.200€' },
  ];

  if (loading) {
    return (
      <SubPageLayout title="Seguimiento de Ventas">
        <div style={{ height: '50vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: '24px' }}>
          <Loader2 className="animate-spin" size={48} color="#F97316" />
          <p style={{ color: 'rgba(255,255,255,0.6)', fontWeight: '600', fontSize: '18px' }}>Cargando analítica avanzada...</p>
        </div>
      </SubPageLayout>
    );
  }

  return (
    <SubPageLayout title="Seguimiento de Ventas">
      {/* 1. Cabecera de Navegación & Filtros */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '48px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
          <button className="glass-btn" style={{ padding: '12px 20px', display: 'flex', alignItems: 'center', gap: '10px' }}>
            <Calendar size={18} color="#F97316" />
            <span>Mayo 2026</span>
          </button>
          <button className="glass-btn" style={{ padding: '12px 20px', display: 'flex', alignItems: 'center', gap: '10px' }}>
            <Store size={18} color="#F97316" />
            <span>Velázquez</span>
          </button>
        </div>

        <div style={{ display: 'flex', gap: '12px' }}>
          <button className="glass-btn-circle" title="Exportar Excel">
            <Download size={20} color="#10B981" />
          </button>
          <button className="glass-btn-circle" title="Exportar PDF">
            <FileText size={20} color="#EF4444" />
          </button>
        </div>
      </div>

      {/* 2. Panel de KPIs (Globos Flotantes) */}
      <div style={{ display: 'flex', gap: '20px', marginBottom: '48px' }}>
        {kpis.map((kpi, idx) => (
          <div key={idx} style={{ 
            backgroundColor: '#F97316', 
            padding: '16px 32px', 
            borderRadius: '40px', 
            boxShadow: '0 10px 20px rgba(249, 115, 22, 0.2)',
            flex: 1,
            textAlign: 'center'
          }}>
            <div style={{ fontSize: '10px', fontWeight: '800', color: 'rgba(255,255,255,0.7)', textTransform: 'uppercase', letterSpacing: '1px', marginBottom: '4px' }}>
              {kpi.label}
            </div>
            <div style={{ fontSize: '24px', fontWeight: '900', color: 'white' }}>
              {kpi.value}
            </div>
          </div>
        ))}
      </div>

      {/* 3. Gráfico de Barras Principal */}
      <div style={{ 
        backgroundColor: 'rgba(255, 255, 255, 0.03)', 
        backdropFilter: 'blur(20px)',
        padding: '48px', 
        borderRadius: '32px', 
        border: '1px solid rgba(255, 255, 255, 0.1)',
        boxShadow: 'inset 0 0 40px rgba(255,255,255,0.02)',
        marginBottom: '48px',
        position: 'relative'
      }}>
        <div style={{ marginBottom: '40px' }}>
          <h2 style={{ fontSize: '18px', fontWeight: '800', color: 'white' }}>Analítica de Rendimiento Mensual</h2>
          <p style={{ fontSize: '12px', color: 'rgba(255,255,255,0.4)', marginTop: '4px' }}>Suma de Ventas Totales por Periodo</p>
        </div>

        <div style={{ height: '350px', display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', gap: '12px', position: 'relative' }}>
          {chartData.map((data, i) => {
            const max = Math.max(...chartData.map(d => d.sales));
            const height = (data.sales / max) * 300;
            return (
              <div 
                key={i} 
                onMouseEnter={() => setHoveredBar(i)}
                onMouseLeave={() => setHoveredBar(null)}
                style={{ 
                  flex: 1, 
                  display: 'flex', 
                  flexDirection: 'column', 
                  alignItems: 'center', 
                  gap: '16px',
                  position: 'relative',
                  cursor: 'pointer'
                }}
              >
                {/* Tooltip */}
                {hoveredBar === i && (
                  <div style={{
                    position: 'absolute',
                    top: `calc(260px - ${height}px - 50px)`,
                    backgroundColor: 'rgba(0,0,0,0.85)',
                    color: 'white',
                    padding: '8px 12px',
                    borderRadius: '8px',
                    fontSize: '11px',
                    fontWeight: 'bold',
                    zIndex: 10,
                    whiteSpace: 'nowrap',
                    boxShadow: '0 10px 20px rgba(0,0,0,0.3)',
                    border: '1px solid rgba(255,255,255,0.1)'
                  }}>
                    {data.sales.toLocaleString()}€
                  </div>
                )}

                <div style={{ 
                  width: '100%', 
                  height: `${height}px`, 
                  background: 'linear-gradient(180deg, #EF4444 0%, rgba(239, 68, 68, 0) 100%)', 
                  borderRadius: '12px 12px 0 0',
                  transition: 'all 0.3s ease',
                  opacity: hoveredBar === i ? 1 : 0.7,
                  boxShadow: hoveredBar === i ? '0 0 20px rgba(239, 68, 68, 0.4)' : 'none'
                }} />
                <span style={{ fontSize: '11px', fontWeight: '800', color: 'rgba(255,255,255,0.4)' }}>{data.month}</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* 4. Listado Top Five */}
      <div style={{ marginBottom: '40px' }}>
        <h2 style={{ fontSize: '18px', fontWeight: '800', color: 'white', marginBottom: '24px', display: 'flex', alignItems: 'center', gap: '12px' }}>
          <TrendingUp size={20} color="#F97316" /> Top 5 Productos
        </h2>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
          {topProducts.map((p, idx) => (
            <div key={idx} style={{ 
              display: 'flex', 
              alignItems: 'center', 
              gap: '24px', 
              padding: '20px', 
              backgroundColor: 'rgba(255,255,255,0.02)', 
              borderBottom: '1px solid rgba(255,255,255,0.05)',
              transition: 'background 0.2s'
            }}>
              <span style={{ fontSize: '14px', fontWeight: '900', color: '#F97316', width: '30px' }}>0{idx + 1}</span>
              <span style={{ flex: 1, fontSize: '15px', fontWeight: '700' }}>{p.name}</span>
              
              <div style={{ width: '200px', height: '6px', backgroundColor: 'rgba(255,255,255,0.05)', borderRadius: '10px', overflow: 'hidden' }}>
                <div style={{ width: `${p.percent}%`, height: '100%', backgroundColor: '#EF4444', borderRadius: '10px' }} />
              </div>
              
              <span style={{ fontSize: '16px', fontWeight: '900', width: '100px', textAlign: 'right' }}>{p.amount}</span>
            </div>
          ))}
        </div>
      </div>

      <style jsx global>{`
        .glass-btn {
          background: rgba(255, 255, 255, 0.05);
          border: 1px solid rgba(255, 255, 255, 0.1);
          color: white;
          border-radius: 16px;
          cursor: pointer;
          font-weight: 700;
          font-size: 13px;
          transition: all 0.2s;
        }
        .glass-btn:hover {
          background: rgba(255, 255, 255, 0.1);
          border-color: rgba(255, 255, 255, 0.2);
        }
        .glass-btn-circle {
          width: 44px;
          height: 44px;
          border-radius: 50%;
          background: rgba(255, 255, 255, 0.05);
          border: 1px solid rgba(255, 255, 255, 0.1);
          display: flex;
          align-items: center;
          justifyContent: center;
          cursor: pointer;
          transition: all 0.2s;
        }
        .glass-btn-circle:hover {
          background: rgba(255, 255, 255, 0.1);
          transform: scale(1.05);
        }
      `}</style>
    </SubPageLayout>
  );
}
