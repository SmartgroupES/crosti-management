'use client';

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Loader2, Lock, User, Shield } from 'lucide-react';

export default function LoginPage() {
  const router = useRouter();
  const [login, setLogin] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify({ login, password }),
        headers: { 'Content-Type': 'application/json' }
      });

      const data = await res.json();
      if (data.success) {
        setIsVisible(false);
        setTimeout(() => {
          router.push('/');
        }, 600);
      } else {
        setError(data.error || 'Acceso denegado');
      }
    } catch (err) {
      setError('Error de conexión con el servidor de seguridad');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{
      backgroundColor: '#601010', // Fondo Rojo Borgoña profundo
      backgroundImage: 'radial-gradient(circle at center, #601010 0%, #000000 100%)',
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontFamily: 'var(--font-outfit), "Outfit", system-ui, sans-serif',
      padding: '24px',
      overflow: 'hidden',
      transition: 'all 0.8s ease-in-out',
      opacity: isVisible ? 1 : 0
    }}>
      {/* Dark Glass Container */}
      <div style={{
        backgroundColor: 'rgba(0, 0, 0, 0.45)', // Cristal oscuro
        backdropFilter: 'blur(16px)',
        WebkitBackdropFilter: 'blur(16px)',
        width: '100%',
        maxWidth: '420px',
        padding: '60px 48px',
        borderRadius: '32px',
        border: '1px solid rgba(255, 255, 255, 0.2)', // Borde fino blanco 20% opacidad
        boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.5)',
        textAlign: 'center',
        position: 'relative',
        zIndex: 1,
        transform: isVisible ? 'scale(1)' : 'scale(0.95)',
        transition: 'all 0.6s cubic-bezier(0.4, 0, 0.2, 1)'
      }}>
        {/* Logo with Shadow */}
        <div style={{ marginBottom: '40px', position: 'relative' }}>
          <div style={{
            position: 'absolute',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            width: '120px',
            height: '120px',
            backgroundColor: 'rgba(0,0,0,0.4)',
            filter: 'blur(30px)',
            borderRadius: '50%',
            zIndex: -1
          }} />
          <img 
            src="/logo-crosti.jpg" 
            alt="Crosti Logo" 
            style={{ 
              height: '80px', 
              borderRadius: '16px', 
              boxShadow: '0 10px 20px rgba(0,0,0,0.5)',
              display: 'inline-block'
            }} 
          />
        </div>

        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px', marginBottom: '32px' }}>
          <Shield size={18} color="#EF4444" />
          <h1 style={{ 
            fontSize: '14px', 
            fontWeight: '800', 
            color: 'rgba(255,255,255,0.9)', 
            letterSpacing: '4px',
            textTransform: 'uppercase',
            margin: 0
          }}>
            Alta Seguridad
          </h1>
        </div>

        <form onSubmit={handleLogin} style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
          <div style={{ position: 'relative' }}>
            <User size={18} style={{ position: 'absolute', left: '20px', top: '50%', transform: 'translateY(-50%)', color: 'rgba(255,255,255,0.4)' }} />
            <input
              type="text"
              placeholder="USUARIO"
              value={login}
              onChange={(e) => setLogin(e.target.value)}
              required
              style={{
                width: '100%',
                padding: '18px 20px 18px 54px',
                fontSize: '13px',
                borderRadius: '14px',
                border: '1px solid rgba(255,255,255,0.1)',
                backgroundColor: 'rgba(0,0,0,0.3)',
                color: 'white',
                outline: 'none',
                transition: 'all 0.3s',
                letterSpacing: '1px',
                fontWeight: '600'
              }}
              onFocus={(e) => {
                e.currentTarget.style.borderColor = 'rgba(255,255,255,0.4)';
                e.currentTarget.style.backgroundColor = 'rgba(0,0,0,0.5)';
              }}
              onBlur={(e) => {
                e.currentTarget.style.borderColor = 'rgba(255,255,255,0.1)';
                e.currentTarget.style.backgroundColor = 'rgba(0,0,0,0.3)';
              }}
            />
          </div>

          <div style={{ position: 'relative' }}>
            <Lock size={18} style={{ position: 'absolute', left: '20px', top: '50%', transform: 'translateY(-50%)', color: 'rgba(255,255,255,0.4)' }} />
            <input
              type="password"
              placeholder="CONTRASEÑA"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              style={{
                width: '100%',
                padding: '18px 20px 18px 54px',
                fontSize: '13px',
                borderRadius: '14px',
                border: '1px solid rgba(255,255,255,0.1)',
                backgroundColor: 'rgba(0,0,0,0.3)',
                color: 'white',
                outline: 'none',
                transition: 'all 0.3s',
                letterSpacing: '1px',
                fontWeight: '600'
              }}
              onFocus={(e) => {
                e.currentTarget.style.borderColor = 'rgba(255,255,255,0.4)';
                e.currentTarget.style.backgroundColor = 'rgba(0,0,0,0.5)';
              }}
              onBlur={(e) => {
                e.currentTarget.style.borderColor = 'rgba(255,255,255,0.1)';
                e.currentTarget.style.backgroundColor = 'rgba(0,0,0,0.3)';
              }}
            />
          </div>

          {error && (
            <div style={{ 
              color: '#FCA5A5', 
              fontSize: '12px', 
              fontWeight: '700', 
              backgroundColor: 'rgba(153, 27, 27, 0.4)', 
              padding: '12px', 
              borderRadius: '12px',
              border: '1px solid rgba(248, 113, 113, 0.2)'
            }}>
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            style={{
              width: '100%',
              padding: '20px',
              fontSize: '14px',
              fontWeight: '900',
              borderRadius: '16px',
              border: 'none',
              backgroundColor: '#EF4444', // Rojo intenso brillante
              color: 'white',
              cursor: loading ? 'not-allowed' : 'pointer',
              transition: 'all 0.3s ease',
              boxShadow: '0 0 20px rgba(239, 68, 68, 0.3)', // Glow suave
              marginTop: '12px',
              letterSpacing: '2px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '12px'
            }}
            onMouseOver={(e) => {
              if (!loading) {
                e.currentTarget.style.backgroundColor = '#F87171';
                e.currentTarget.style.boxShadow = '0 0 30px rgba(239, 68, 68, 0.5)';
                e.currentTarget.style.transform = 'translateY(-2px)';
              }
            }}
            onMouseOut={(e) => {
              if (!loading) {
                e.currentTarget.style.backgroundColor = '#EF4444';
                e.currentTarget.style.boxShadow = '0 0 20px rgba(239, 68, 68, 0.3)';
                e.currentTarget.style.transform = 'translateY(0)';
              }
            }}
          >
            {loading ? <Loader2 className="animate-spin" size={18} /> : 'ENTRAR AL SISTEMA'}
          </button>
        </form>

        <div style={{ 
          marginTop: '48px', 
          fontSize: '11px', 
          color: 'rgba(255,255,255,0.3)', 
          fontWeight: '600',
          letterSpacing: '2px'
        }}>
          &copy; 2026 CROSTI MANAGEMENT
        </div>
      </div>

      <style jsx global>{`
        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        .animate-spin {
          animation: spin 1s linear infinite;
        }
      `}</style>
    </div>
  );
}
