'use client';

import React from 'react';
import Header from '@/components/Header';
import { 
  BarChart3, 
  TrendingUp, 
  Calculator, 
  BookOpen, 
  Calendar, 
  ChefHat, 
  Trash2, 
  ShoppingCart, 
  Package, 
  Settings, 
  Camera, 
  Zap, 
  Users, 
  Clock, 
  Activity
} from 'lucide-react';

export default function HomePage() {

  const sections = [
    {
      title: "ANÁLISIS",
      icon: <BarChart3 size={16} />,
      items: [
        { label: "Seguimiento de Ventas", href: "/consulta/ventas", icon: <TrendingUp size={16} /> },
        { label: "Rentabilidad", href: "/analisis/rentabilidad", icon: <Calculator size={16} /> },
        { label: "Simulador de Costos", href: "/admin/simulador", icon: <Activity size={16} /> },
        { label: "Gestión de Recetas", href: "/admin/escandallos", icon: <BookOpen size={16} /> }
      ]
    },
    {
      title: "OPERACIONES",
      icon: <Settings size={16} />,
      items: [
        { label: "Planificación", href: "/planificacion", icon: <Calendar size={16} /> },
        { label: "Gestión Catering", href: "/produccion/catering", icon: <ChefHat size={16} /> },
        { label: "Gestión de Merma", href: "/produccion/merma", icon: <Trash2 size={16} /> },
        { label: "Compras", href: "/inventario/compras", icon: <ShoppingCart size={16} /> },
        { label: "Control de Stock", href: "/inventario/stock", icon: <Package size={16} /> },
        { label: "Mantenimiento", href: "/admin/mantenimiento", icon: <Settings size={16} /> }
      ]
    },
    {
      title: "BAKEOS IA",
      icon: <Zap size={16} />,
      items: [
        { label: "Control Calidad (Foto)", href: "/inventario/foto", icon: <Camera size={16} /> },
        { label: "Sincro Omnicanal", href: "/analisis/omnichannel", icon: <Zap size={16} /> }
      ]
    },
    {
      title: "EQUIPO & SISTEMA",
      icon: <Users size={16} />,
      items: [
        { label: "Personal y Equipo", href: "/admin/personal", icon: <Users size={16} /> },
        { label: "Horarios y Turnos", href: "/admin/personal/horarios", icon: <Clock size={16} /> }
      ]
    }
  ];

  return (
    <div className="fade-in" style={{ 
      minHeight: '100vh', 
      width: '100%',
      padding: '140px 4% 60px 4%',
      display: 'flex',
      flexDirection: 'column',
      backgroundColor: '#801515', // Fondo rojo borgoña
      backgroundImage: 'linear-gradient(180deg, #801515 0%, #4D0D0D 100%)',
      position: 'relative'
    }}>
      <Header />

      <div style={{
        maxWidth: '1500px',
        margin: '0 auto',
        width: '100%'
      }}>
        {/* Welcome Header */}
        <div style={{ marginBottom: '48px', textAlign: 'left' }}>
          <h1 style={{ fontSize: '36px', fontWeight: '900', color: 'white', marginBottom: '8px', letterSpacing: '-0.5px' }}>
            Panel de Gestión
          </h1>
          <p style={{ color: 'rgba(255,255,255,0.7)', fontSize: '18px', fontWeight: '500' }}>
            Bienvenido de nuevo a Crosti Hub.
          </p>
        </div>

        {/* 4-Column Grid */}
        <div style={{ 
          display: 'grid', 
          gridTemplateColumns: 'repeat(4, 1fr)', 
          gap: '24px',
          width: '100%'
        }}>
          {sections.map((section, idx) => (
            <div key={idx} style={{ 
              backgroundColor: 'rgba(0, 0, 0, 0.4)', // Fondo oscuro semi-traslúcido
              padding: '24px', 
              borderRadius: '24px',
              border: '1px solid rgba(255, 255, 255, 0.08)',
              display: 'flex', 
              flexDirection: 'column', 
              gap: '20px',
              backdropFilter: 'blur(10px)'
            }}>
              {/* Section Header */}
              <div style={{ 
                display: 'flex', 
                alignItems: 'center', 
                gap: '10px',
                color: '#FFD700', // Títulos en mayúsculas amarillas/doradas
                marginBottom: '4px'
              }}>
                {section.icon}
                <span style={{ 
                  fontSize: '11px', 
                  fontWeight: '900', 
                  letterSpacing: '2.5px',
                  textTransform: 'uppercase'
                }}>
                  {section.title}
                </span>
              </div>
              
              {/* Buttons List */}
              <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                {section.items.map((item, i) => (
                  <button 
                    key={i}
                    onClick={() => window.location.href = item.href}
                    style={{
                      backgroundColor: 'rgba(128, 21, 21, 0.5)', // Fondo rojo oscuro traslúcido
                      border: '1px solid rgba(255, 255, 255, 0.05)',
                      padding: '14px 16px',
                      borderRadius: '12px',
                      color: 'white',
                      fontSize: '13px',
                      fontWeight: '700',
                      cursor: 'pointer',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '12px',
                      transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
                      textAlign: 'left',
                      position: 'relative',
                      overflow: 'hidden'
                    }}
                    onMouseOver={(e) => {
                      e.currentTarget.style.backgroundColor = 'rgba(128, 21, 21, 0.8)';
                      e.currentTarget.style.transform = 'translateY(-2px)';
                      e.currentTarget.style.borderColor = '#F97316'; // Ilumina bordes en naranja Bakeos
                      e.currentTarget.style.boxShadow = '0 0 15px rgba(249, 115, 22, 0.3)';
                    }}
                    onMouseOut={(e) => {
                      e.currentTarget.style.backgroundColor = 'rgba(128, 21, 21, 0.5)';
                      e.currentTarget.style.transform = 'translateY(0)';
                      e.currentTarget.style.borderColor = 'rgba(255,255,255,0.05)';
                      e.currentTarget.style.boxShadow = 'none';
                    }}
                  >
                    <span style={{ color: 'rgba(255,255,255,0.6)' }}>{item.icon}</span>
                    {item.label}
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      <style jsx global>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .fade-in {
          animation: fadeIn 0.6s ease-out forwards;
        }
      `}</style>
    </div>
  );
}
