'use client';

import React, { useState, useEffect, useRef } from 'react';
import { 
  Camera, 
  ChevronUp, 
  X, 
  RotateCcw, 
  CheckCircle2, 
  History, 
  Package, 
  Apple, 
  Wind,
  LayoutGrid,
  Zap,
  ArrowLeft,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';
import { useRouter } from 'next/navigation';

export default function QualityAIModule() {
  const router = useRouter();
  const [step, setStep] = useState<'searching' | 'detecting' | 'analyzing' | 'result'>('searching');
  const [selectedProduct, setSelectedProduct] = useState('Cookies');
  const [showHistory, setShowHistory] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<null | {
    presence: number;
    aesthetics: number;
    freshness: number;
    score: number;
    failures: string[];
  }>(null);

  const products = [
    { name: 'Cookies', icon: <Package size={18} /> },
    { name: 'Ensaladas', icon: <Apple size={18} /> },
    { name: 'Focaccias', icon: <Wind size={18} /> },
    { name: 'Catering Completo', icon: <LayoutGrid size={18} /> },
  ];

  // Simulación de flujo de IA
  useEffect(() => {
    if (step === 'searching') {
      const timer = setTimeout(() => setStep('detecting'), 2000);
      return () => clearTimeout(timer);
    }
  }, [step]);

  const handleCapture = () => {
    setStep('analyzing');
    setTimeout(() => {
      setAnalysisResult({
        presence: 95,
        aesthetics: 60,
        freshness: 88,
        score: 2,
        failures: ['Diámetro insuficiente', 'Color irregular'],
      });
      setStep('result');
    }, 2500);
  };

  const reset = () => {
    setStep('searching');
    setAnalysisResult(null);
  };

  const getGridColor = () => {
    if (step === 'searching') return 'rgba(255, 255, 255, 0.4)';
    if (step === 'detecting') return '#F97316';
    if (step === 'analyzing' || step === 'result') return '#10B981';
    return 'white';
  };

  const CircularIndicator = ({ value, label, color }: { value: number; label: string; color: string }) => {
    const radius = 35;
    const circumference = 2 * Math.PI * radius;
    const offset = circumference - (value / 100) * circumference;

    return (
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '8px' }}>
        <div style={{ position: 'relative', width: '80px', height: '80px' }}>
          <svg width="80" height="80">
            <circle cx="40" cy="40" r={radius} fill="none" stroke="rgba(255,255,255,0.05)" strokeWidth="6" />
            <circle 
              cx="40" 
              cy="40" 
              r={radius} 
              fill="none" 
              stroke={color} 
              strokeWidth="6" 
              strokeDasharray={circumference} 
              strokeDashoffset={offset} 
              strokeLinecap="round" 
              style={{ transition: 'stroke-dashoffset 1.5s ease-out', transform: 'rotate(-90deg)', transformOrigin: '50% 50%' }}
            />
          </svg>
          <div style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '14px', fontWeight: '900' }}>
            {value}%
          </div>
        </div>
        <span style={{ fontSize: '10px', fontWeight: '800', opacity: 0.5, textTransform: 'uppercase', letterSpacing: '1px' }}>{label}</span>
      </div>
    );
  };

  return (
    <div style={{ 
      position: 'relative', 
      width: '100vw', 
      height: '100vh', 
      backgroundColor: '#000', 
      overflow: 'hidden',
      color: 'white'
    }}>
      {/* 1. Visor de Cámara (Fondo) */}
      <div style={{ 
        position: 'absolute', 
        top: 0, 
        left: 0, 
        width: '100%', 
        height: '100%',
        backgroundImage: 'url("https://images.unsplash.com/photo-1558961363-fa8fdf82db35?q=80&w=2000&auto=format&fit=crop")',
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        filter: step === 'analyzing' || step === 'result' ? 'blur(10px) brightness(0.5)' : 'none',
        transition: 'filter 0.8s ease'
      }}>
        {/* Overlay Gradiente para mejorar visibilidad */}
        <div style={{ 
          position: 'absolute', 
          top: 0, 
          left: 0, 
          width: '100%', 
          height: '100%', 
          background: 'radial-gradient(circle, transparent 40%, rgba(0,0,0,0.6) 100%)' 
        }} />
      </div>

      {/* Marco de Cristal Sutil */}
      <div style={{ 
        position: 'absolute', 
        top: '20px', 
        left: '20px', 
        right: '20px', 
        bottom: '20px', 
        border: '1px solid rgba(255,255,255,0.1)', 
        borderRadius: '32px', 
        pointerEvents: 'none',
        zIndex: 5
      }} />

      {/* 2. Guías de AR (Overlay Rejilla) */}
      <div style={{ 
        position: 'absolute', 
        top: '50%', 
        left: '50%', 
        transform: 'translate(-50%, -50%)', 
        width: '300px', 
        height: '300px', 
        display: 'flex', 
        flexWrap: 'wrap', 
        gap: '4px',
        opacity: step === 'analyzing' || step === 'result' ? 0 : 1,
        transition: 'opacity 0.5s ease'
      }}>
        <div style={{ position: 'absolute', top: '-10px', left: '-10px', width: '30px', height: '30px', borderTop: `4px solid ${getGridColor()}`, borderLeft: `4px solid ${getGridColor()}`, borderRadius: '4px' }} />
        <div style={{ position: 'absolute', top: '-10px', right: '-10px', width: '30px', height: '30px', borderTop: `4px solid ${getGridColor()}`, borderRight: `4px solid ${getGridColor()}`, borderRadius: '4px' }} />
        <div style={{ position: 'absolute', bottom: '-10px', left: '-10px', width: '30px', height: '30px', borderBottom: `4px solid ${getGridColor()}`, borderLeft: `4px solid ${getGridColor()}`, borderRadius: '4px' }} />
        <div style={{ position: 'absolute', bottom: '-10px', right: '-10px', width: '30px', height: '30px', borderBottom: `4px solid ${getGridColor()}`, borderRight: `4px solid ${getGridColor()}`, borderRadius: '4px' }} />
        
        {step === 'detecting' && (
          <div style={{ 
            position: 'absolute', 
            top: '50%', 
            left: '50%', 
            transform: 'translate(-50%, -50%)', 
            backgroundColor: 'rgba(249, 115, 22, 0.2)', 
            padding: '4px 12px', 
            borderRadius: '4px', 
            fontSize: '10px', 
            fontWeight: '900', 
            color: '#F97316',
            whiteSpace: 'nowrap',
            animation: 'pulse 1s infinite'
          }}>
            DETECTANDO {selectedProduct.toUpperCase()}...
          </div>
        )}
      </div>

      {/* Botón Volver & Histórico */}
      <div style={{ position: 'absolute', top: '40px', left: '40px', display: 'flex', gap: '16px', zIndex: 20 }}>
        <button 
          onClick={() => router.push('/')}
          style={{ 
            width: '44px', height: '44px', borderRadius: '50%', backgroundColor: 'rgba(255,255,255,0.1)', backdropFilter: 'blur(10px)', border: '1px solid rgba(255,255,255,0.2)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer'
          }}>
          <ArrowLeft size={20} />
        </button>
      </div>

      <div style={{ position: 'absolute', top: '40px', right: '40px', zIndex: 20 }}>
        <button 
          onClick={() => setShowHistory(true)}
          style={{ 
            backgroundColor: 'rgba(255,255,255,0.1)', backdropFilter: 'blur(10px)', border: '1px solid rgba(255,255,255,0.2)', padding: '10px 20px', borderRadius: '20px', display: 'flex', alignItems: 'center', gap: '10px', fontSize: '12px', fontWeight: '800', cursor: 'pointer'
          }}>
          <History size={16} /> AUDITORÍA
        </button>
      </div>

      {/* 3. Selector de Producto (Bottom Carousel) */}
      {step !== 'analyzing' && step !== 'result' && (
        <div style={{ 
          position: 'absolute', 
          bottom: '120px', 
          left: '50%', 
          transform: 'translateX(-50%)', 
          width: '100%', 
          maxWidth: '600px', 
          zIndex: 15 
        }}>
          <div style={{ 
            display: 'flex', 
            gap: '12px', 
            padding: '20px', 
            overflowX: 'auto', 
            justifyContent: 'center',
            scrollbarWidth: 'none'
          }}>
            {products.map(p => (
              <div 
                key={p.name}
                onClick={() => setSelectedProduct(p.name)}
                style={{ 
                  flex: '0 0 auto',
                  padding: '16px 24px',
                  backgroundColor: selectedProduct === p.name ? 'rgba(249, 115, 22, 0.2)' : 'rgba(255,255,255,0.05)',
                  backdropFilter: 'blur(12px)',
                  border: `1px solid ${selectedProduct === p.name ? '#F97316' : 'rgba(255,255,255,0.1)'}`,
                  borderRadius: '20px',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '12px',
                  cursor: 'pointer',
                  transition: 'all 0.3s ease'
                }}
              >
                <div style={{ color: selectedProduct === p.name ? '#F97316' : 'white' }}>{p.icon}</div>
                <span style={{ fontSize: '13px', fontWeight: '800', whiteSpace: 'nowrap' }}>{p.name}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Botón de Captura */}
      {step !== 'analyzing' && step !== 'result' && (
        <div style={{ position: 'absolute', bottom: '40px', left: '50%', transform: 'translateX(-50%)', zIndex: 15 }}>
          <button 
            onClick={handleCapture}
            style={{ 
              width: '80px', 
              height: '80px', 
              borderRadius: '50%', 
              backgroundColor: '#F97316', 
              border: '8px solid rgba(255,255,255,0.2)', 
              display: 'flex', 
              alignItems: 'center', 
              justifyContent: 'center', 
              boxShadow: '0 0 30px rgba(249, 115, 22, 0.5)',
              cursor: 'pointer'
            }}
          >
            <Camera size={32} />
          </button>
        </div>
      )}

      {/* 4. Panel de Análisis en Tiempo Real (Slide-up) */}
      <div style={{ 
        position: 'absolute', 
        bottom: 0, 
        left: 0, 
        width: '100%', 
        height: '85%', 
        backgroundColor: 'rgba(80, 10, 10, 0.85)', 
        backdropFilter: 'blur(40px)',
        borderTop: '1px solid rgba(255,255,255,0.1)',
        borderRadius: '40px 40px 0 0',
        transform: step === 'result' ? 'translateY(0)' : 'translateY(100%)',
        transition: 'transform 0.6s cubic-bezier(0.16, 1, 0.3, 1)',
        zIndex: 100,
        padding: '40px'
      }}>
        {/* Pull Handle */}
        <div style={{ width: '40px', height: '4px', backgroundColor: 'rgba(255,255,255,0.2)', borderRadius: '2px', margin: '0 auto 40px auto' }} />

        {analysisResult && (
          <div style={{ maxWidth: '1000px', margin: '0 auto' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '60px' }}>
              <div>
                <h2 style={{ fontSize: '32px', fontWeight: '900', margin: 0 }}>Análisis de {selectedProduct}</h2>
                <p style={{ fontSize: '14px', color: 'rgba(255,255,255,0.5)', margin: '8px 0 0 0' }}>BakeOS Vision AI Engine v4.2</p>
              </div>
              
              {/* Score Global */}
              <div style={{ textAlign: 'center' }}>
                <div style={{ fontSize: '64px', fontWeight: '900', color: analysisResult.score >= 3 ? '#10B981' : '#EF4444', lineHeight: 1 }}>
                  {analysisResult.score}
                </div>
                <div style={{ fontSize: '10px', fontWeight: '900', opacity: 0.5, marginTop: '4px' }}>SCORE GLOBAL</div>
              </div>
            </div>

            {/* Indicadores Circulares */}
            <div style={{ display: 'flex', justifyContent: 'space-around', marginBottom: '60px' }}>
              <CircularIndicator value={analysisResult.presence} label="Presencia" color="#10B981" />
              <CircularIndicator value={analysisResult.aesthetics} label="Estética" color={analysisResult.aesthetics < 70 ? '#EF4444' : '#FFD700'} />
              <CircularIndicator value={analysisResult.freshness} label="Frescura" color="#F97316" />
            </div>

            {/* Atributos Fallidos */}
            {analysisResult.score < 3 && (
              <div style={{ backgroundColor: 'rgba(239, 68, 68, 0.1)', border: '1px solid rgba(239, 68, 68, 0.3)', padding: '24px', borderRadius: '20px', marginBottom: '60px' }}>
                <h4 style={{ color: '#EF4444', fontSize: '14px', margin: '0 0 12px 0', display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <Zap size={16} /> DEFECTOS DETECTADOS:
                </h4>
                <div style={{ display: 'flex', gap: '10px' }}>
                  {analysisResult.failures.map(f => (
                    <span key={f} style={{ backgroundColor: 'rgba(239, 68, 68, 0.2)', color: '#EF4444', padding: '6px 16px', borderRadius: '12px', fontSize: '12px', fontWeight: '800' }}>{f}</span>
                  ))}
                </div>
              </div>
            )}

            {/* Botones de Acción */}
            <div style={{ display: 'flex', gap: '20px' }}>
              <button 
                onClick={reset}
                style={{ flex: 1, backgroundColor: 'rgba(255,255,255,0.1)', border: '1px solid rgba(255,255,255,0.2)', color: 'white', padding: '20px', borderRadius: '20px', fontSize: '14px', fontWeight: '900', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '12px' }}
              >
                <RotateCcw size={18} /> REINTENTAR
              </button>
              <button 
                onClick={() => router.push('/')}
                style={{ flex: 2, backgroundColor: '#10B981', color: 'white', padding: '20px', borderRadius: '20px', fontSize: '14px', fontWeight: '900', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '12px', boxShadow: '0 10px 25px rgba(16, 185, 129, 0.3)' }}
              >
                <CheckCircle2 size={18} /> VALIDAR Y SUBIR A D1
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Overlay de Análisis (Cargando) */}
      {step === 'analyzing' && (
        <div style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', backgroundColor: 'rgba(0,0,0,0.6)', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', zIndex: 150 }}>
          <div className="spinner" />
          <h3 style={{ marginTop: '24px', fontSize: '18px', fontWeight: '900', letterSpacing: '2px' }}>ANALIZANDO...</h3>
        </div>
      )}

      {/* Galería de Auditoría (Popup) */}
      {showHistory && (
        <div style={{ 
          position: 'absolute', 
          top: 0, 
          left: 0, 
          width: '100%', 
          height: '100%', 
          backgroundColor: 'rgba(0,0,0,0.9)', 
          zIndex: 200, 
          padding: '60px' 
        }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '40px' }}>
            <h2 style={{ fontSize: '24px', fontWeight: '900' }}>Registro de Auditoría Visual</h2>
            <button onClick={() => setShowHistory(false)} style={{ background: 'none', border: 'none', color: 'white', cursor: 'pointer' }}><X size={32} /></button>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: '20px' }}>
            {[1,2,3,4,5,6,7,8].map(i => (
              <div key={i} style={{ borderRadius: '20px', overflow: 'hidden', position: 'relative' }}>
                <img src={`https://picsum.photos/seed/${i+100}/300/400`} style={{ width: '100%', height: '250px', objectFit: 'cover', opacity: 0.7 }} />
                <div style={{ position: 'absolute', bottom: '10px', right: '10px', backgroundColor: '#F97316', padding: '4px 8px', borderRadius: '6px', fontSize: '12px', fontWeight: '900' }}>Score: 4.8</div>
              </div>
            ))}
          </div>
        </div>
      )}

      <style jsx global>{`
        @keyframes pulse {
          0% { opacity: 0.6; }
          50% { opacity: 1; }
          100% { opacity: 0.6; }
        }
        .spinner {
          width: 60px;
          height: 60px;
          border: 6px solid rgba(249, 115, 22, 0.1);
          border-top: 6px solid #F97316;
          border-radius: 50%;
          animation: spin 1s linear infinite;
        }
        @keyframes spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
        ::-webkit-scrollbar { display: none; }
      `}</style>
    </div>
  );
}
