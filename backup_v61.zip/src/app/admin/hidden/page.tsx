'use client';

import React, { useState, useEffect } from 'react';
import Header from '@/components/Header';
import { Database, Terminal, Mail, MessageSquare, ShieldAlert, Cpu, ArrowLeft, CheckCircle2 } from 'lucide-react';
import { useRouter } from 'next/navigation';

export default function HiddenAdminPage() {
  const router = useRouter();
  const [activeTab, setActiveTab] = useState('schema');
  const [logs, setLogs] = useState([
    { time: '2026-05-01 09:15:02', msg: 'System integrity check: PASSED', level: 'info' },
    { time: '2026-05-01 09:12:45', msg: 'BakeOS AI core synchronization complete', level: 'success' },
    { time: '2026-05-01 08:45:10', msg: 'Backup v56 generated successfully', level: 'info' },
    { time: '2026-05-01 07:30:22', msg: 'Security alert: Unauthorized access attempt blocked (IP: 192.168.1.45)', level: 'warn' },
  ]);

  const schema = `
CREATE TABLE users (
  id INTEGER PRIMARY KEY,
  login TEXT UNIQUE,
  password_hash TEXT,
  role TEXT DEFAULT 'admin'
);

CREATE TABLE sales (
  id INTEGER PRIMARY KEY,
  sale_date TEXT,
  amount REAL,
  location TEXT
);

CREATE TABLE inventory (
  product_id TEXT PRIMARY KEY,
  current_stock REAL,
  min_stock REAL
);
  `.trim();

  return (
    <div style={{ 
      backgroundColor: '#000000', 
      minHeight: '100vh', 
      color: '#FFD700', // Gold Text
      fontFamily: '"Courier New", Courier, monospace',
      padding: '140px 4% 60px 4%',
      position: 'relative',
      overflowX: 'hidden'
    }}>
      <Header />

      <div style={{ maxWidth: '1400px', margin: '0 auto', width: '100%' }}>
        {/* Title Section */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '20px', marginBottom: '60px', borderBottom: '1px solid #FFD700', paddingBottom: '20px' }}>
          <ShieldAlert size={48} />
          <div>
            <h1 style={{ fontSize: '32px', fontWeight: '900', margin: 0, textTransform: 'uppercase', letterSpacing: '4px' }}>
              Terminal de Administración Crítica
            </h1>
            <p style={{ fontSize: '14px', margin: '4px 0 0 0', opacity: 0.7 }}>Acceso de Nivel 5 - Solo para Superadministradores</p>
          </div>
          <button 
            onClick={() => router.push('/')}
            style={{ 
              marginLeft: 'auto',
              background: 'none',
              border: '1px solid #FFD700',
              color: '#FFD700',
              padding: '10px 20px',
              borderRadius: '4px',
              cursor: 'pointer',
              fontSize: '12px',
              fontWeight: 'bold',
              display: 'flex',
              alignItems: 'center',
              gap: '10px'
            }}>
            <ArrowLeft size={16} /> SALIR DE LA TERMINAL
          </button>
        </div>

        {/* Matrix Grid */}
        <div style={{ display: 'grid', gridTemplateColumns: '280px 1fr', gap: '40px' }}>
          {/* Sidebar */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
            {[
              { id: 'schema', label: 'D1 ESQUEMAS', icon: <Database size={18} /> },
              { id: 'logs', label: 'SISTEMA LOGS', icon: <Terminal size={18} /> },
              { id: 'reports', label: 'CONTROL REPORTES', icon: <Cpu size={18} /> }
            ].map(tab => (
              <button 
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                style={{
                  backgroundColor: activeTab === tab.id ? '#FFD700' : 'transparent',
                  color: activeTab === tab.id ? '#000000' : '#FFD700',
                  border: '1px solid #FFD700',
                  padding: '16px 20px',
                  textAlign: 'left',
                  fontSize: '13px',
                  fontWeight: '900',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '12px',
                  transition: 'all 0.2s'
                }}
              >
                {tab.icon}
                {tab.label}
              </button>
            ))}
          </div>

          {/* Main Content */}
          <div style={{ 
            border: '1px solid #FFD700', 
            padding: '40px', 
            backgroundColor: 'rgba(255, 215, 0, 0.05)',
            position: 'relative'
          }}>
            {activeTab === 'schema' && (
              <div style={{ animation: 'blink 2s infinite' }}>
                <h3 style={{ marginBottom: '20px', fontSize: '18px' }}>ESTRUCTURA DE BASE DE DATOS (D1)</h3>
                <pre style={{ 
                  backgroundColor: '#0a0a0a', 
                  padding: '24px', 
                  borderRadius: '4px', 
                  fontSize: '14px', 
                  lineHeight: '1.6', 
                  color: '#FFD700',
                  border: '1px solid rgba(255, 215, 0, 0.3)',
                  overflowX: 'auto'
                }}>
                  {schema}
                </pre>
              </div>
            )}

            {activeTab === 'logs' && (
              <div>
                <h3 style={{ marginBottom: '20px', fontSize: '18px' }}>HISTORIAL DE ACTUALIZACIONES</h3>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                  {logs.map((log, i) => (
                    <div key={i} style={{ 
                      fontSize: '13px', 
                      display: 'flex', 
                      gap: '20px', 
                      padding: '12px', 
                      borderBottom: '1px solid rgba(255, 215, 0, 0.1)' 
                    }}>
                      <span style={{ opacity: 0.5 }}>[{log.time}]</span>
                      <span style={{ 
                        color: log.level === 'warn' ? '#FF4444' : (log.level === 'success' ? '#44FF44' : '#FFD700'),
                        fontWeight: 'bold'
                      }}>
                        {log.msg}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'reports' && (
              <div>
                <h3 style={{ marginBottom: '40px', fontSize: '18px' }}>CONTROL DE REPORTES PROGRAMADOS</h3>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '32px' }}>
                  <div style={{ border: '1px solid #FFD700', padding: '24px', borderRadius: '4px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '20px' }}>
                      <Mail size={24} />
                      <span style={{ fontWeight: 'bold' }}>SISTEMA EMAIL</span>
                    </div>
                    <div style={{ fontSize: '12px', opacity: 0.7, marginBottom: '20px' }}>
                      Reportes diarios de ventas y merma enviados a ncarrillok@gmail.com
                    </div>
                    <button style={{ 
                      width: '100%', 
                      backgroundColor: '#FFD700', 
                      color: '#000000', 
                      border: 'none', 
                      padding: '12px', 
                      fontWeight: 'bold',
                      cursor: 'pointer'
                    }}>
                      CONFIGURAR ENVÍO
                    </button>
                  </div>

                  <div style={{ border: '1px solid #FFD700', padding: '24px', borderRadius: '4px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '20px' }}>
                      <MessageSquare size={24} />
                      <span style={{ fontWeight: 'bold' }}>WHATSAPP BOT</span>
                    </div>
                    <div style={{ fontSize: '12px', opacity: 0.7, marginBottom: '20px' }}>
                      Alertas críticas de stock y mantenimiento enviadas al administrador.
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '10px', color: '#44FF44', fontSize: '12px' }}>
                      <CheckCircle2 size={16} /> ACTIVO
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      <style jsx global>{`
        @keyframes blink {
          0% { opacity: 1; }
          50% { opacity: 0.8; }
          100% { opacity: 1; }
        }
        ::selection {
          background-color: #FFD700;
          color: #000000;
        }
      `}</style>
    </div>
  );
}
