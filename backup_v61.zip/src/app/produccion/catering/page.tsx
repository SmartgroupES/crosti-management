'use client';

import React, { useState, useEffect } from 'react';
import SubPageLayout from '@/components/SubPageLayout';
import { 
  Users, 
  Package, 
  Clock, 
  Camera, 
  Plus, 
  History,
  Download,
  FileText,
  ChevronDown,
  ChevronUp,
  CheckCircle2,
  Flame,
  Truck,
  Loader2
} from 'lucide-react';

export default function CateringPage() {
  const [loading, setLoading] = useState(true);
  const [isIngredientsOpen, setIsIngredientsOpen] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 800);
    return () => clearTimeout(timer);
  }, []);

  const t1Orders = [
    { id: 1, customer: 'Deloitte Spain', time: '09:00', people: 45, status: 'Listo para Reparto', items: '50 Mini Croissants, 20 Napolitanas' },
    { id: 2, customer: 'Google Madrid', time: '11:30', people: 120, status: 'Validado por IA', items: '150 Cookies, 60 Ensaimadas' },
    { id: 3, customer: 'Boda Particular', time: '14:00', people: 80, status: 'En Horno', items: '80 Tostas de Masa Madre' },
  ];

  const t2Orders = [
    { id: 4, customer: 'Santander Hub', time: '08:30', people: 60, status: 'Pendiente', items: '70 Pulgas Jamón, 40 Cruasanes' },
    { id: 5, customer: 'Evento BMW', time: '10:00', people: 200, status: 'Pendiente', items: '250 Mini Muffins, 100 Cafés' },
  ];

  const ingredients = [
    { name: 'Mantequilla Pura', qty: '15kg' },
    { name: 'Harina Gran Fuerza', qty: '45kg' },
    { name: 'Chocolate 70%', qty: '8kg' },
    { name: 'Leche Entera', qty: '30L' },
    { name: 'Huevos Camperos', qty: '120 uds.' },
  ];

  const getStatusBadge = (status: string) => {
    const colors: Record<string, string> = {
      'Pendiente': 'rgba(255,255,255,0.2)',
      'En Horno': 'rgba(239, 68, 68, 0.4)',
      'Validado por IA': 'rgba(16, 185, 129, 0.4)',
      'Listo para Reparto': '#10B981'
    };
    const icons: Record<string, React.ReactNode> = {
      'Pendiente': <Clock size={12} />,
      'En Horno': <Flame size={12} />,
      'Validado por IA': <CheckCircle2 size={12} />,
      'Listo para Reparto': <Truck size={12} />
    };
    return (
      <div style={{ 
        display: 'flex', 
        alignItems: 'center', 
        gap: '6px', 
        fontSize: '10px', 
        fontWeight: '800', 
        padding: '6px 12px', 
        borderRadius: '20px', 
        backgroundColor: colors[status] || 'rgba(255,255,255,0.1)', 
        color: 'white',
        textTransform: 'uppercase'
      }}>
        {icons[status] || <Clock size={12} />} {status}
      </div>
    );
  };

  if (loading) {
    return (
      <SubPageLayout title="Gestión de Catering">
        <div style={{ height: '50vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: '24px' }}>
          <Loader2 className="animate-spin" size={48} color="#F97316" />
          <p style={{ color: 'rgba(255,255,255,0.6)', fontWeight: '600', fontSize: '18px' }}>Organizando logística de eventos...</p>
        </div>
      </SubPageLayout>
    );
  }

  return (
    <SubPageLayout title="Gestión de Catering">
      {/* 1. Encabezado de Estado & Exportación */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '48px' }}>
        <div style={{ display: 'flex', gap: '40px', alignItems: 'center' }}>
          {/* Capacidad Circular */}
          <div style={{ position: 'relative', width: '100px', height: '100px' }}>
            <svg width="100" height="100" viewBox="0 0 100 100">
              <circle cx="50" cy="50" r="45" fill="none" stroke="rgba(255,255,255,0.05)" strokeWidth="8" />
              <circle cx="50" cy="50" r="45" fill="none" stroke="#F97316" strokeWidth="8" strokeDasharray="212" strokeDashoffset="70" strokeLinecap="round" style={{ transition: 'stroke-dashoffset 1s ease' }} />
            </svg>
            <div style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
              <span style={{ fontSize: '20px', fontWeight: '900', color: '#F97316' }}>75%</span>
              <span style={{ fontSize: '8px', fontWeight: '800', opacity: 0.5 }}>CARGA</span>
            </div>
          </div>

          <div style={{ display: 'flex', gap: '16px' }}>
            <button className="glass-btn" style={{ padding: '14px 24px', display: 'flex', alignItems: 'center', gap: '10px' }}>
              <Plus size={18} color="#F97316" />
              <span>Nuevo Pedido</span>
            </button>
            <button className="glass-btn" style={{ padding: '14px 24px', display: 'flex', alignItems: 'center', gap: '10px' }}>
              <History size={18} color="#F97316" />
              <span>Ver Histórico</span>
            </button>
          </div>
        </div>

        <div style={{ display: 'flex', gap: '12px' }}>
          <button className="glass-btn-circle" title="Exportar Hoja de Producción">
            <Download size={20} color="#10B981" />
          </button>
          <button className="glass-btn-circle" title="Exportar Albaranes">
            <FileText size={20} color="#EF4444" />
          </button>
        </div>
      </div>

      {/* 2. Visualización Dinámica de Pedidos (Timeline) */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '32px', marginBottom: '60px' }}>
        {/* Bloque T+1 */}
        <div>
          <h2 style={{ fontSize: '14px', fontWeight: '900', color: 'rgba(255,255,255,0.4)', textTransform: 'uppercase', letterSpacing: '2px', marginBottom: '24px', display: 'flex', alignItems: 'center', gap: '10px' }}>
            <Calendar size={16} /> Entregas Mañana (T+1)
          </h2>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
            {t1Orders.map(order => (
              <div key={order.id} className="event-card">
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '16px' }}>
                  <div style={{ fontSize: '24px', fontWeight: '900', color: '#FFD700' }}>{order.time}</div>
                  {getStatusBadge(order.status)}
                </div>
                <div style={{ marginBottom: '16px' }}>
                  <div style={{ fontSize: '18px', fontWeight: '800', marginBottom: '4px' }}>{order.customer}</div>
                  <div style={{ fontSize: '12px', color: 'rgba(255,255,255,0.5)', display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <Users size={14} /> {order.people} personas
                  </div>
                </div>
                <div style={{ backgroundColor: 'rgba(0,0,0,0.2)', padding: '12px', borderRadius: '12px', marginBottom: '20px', fontSize: '12px', color: 'rgba(255,255,255,0.7)' }}>
                  {order.items}
                </div>
                <button className="camera-btn">
                  <Camera size={18} />
                  <span>VALIDACIÓN VISUAL IA</span>
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Bloque T+2 */}
        <div>
          <h2 style={{ fontSize: '14px', fontWeight: '900', color: 'rgba(255,255,255,0.4)', textTransform: 'uppercase', letterSpacing: '2px', marginBottom: '24px', display: 'flex', alignItems: 'center', gap: '10px' }}>
            <Clock size={16} /> Próximas 48h (T+2)
          </h2>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
            {t2Orders.map(order => (
              <div key={order.id} className="event-card" style={{ opacity: 0.8 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '16px' }}>
                  <div style={{ fontSize: '24px', fontWeight: '900', color: 'rgba(255,215,0,0.6)' }}>{order.time}</div>
                  {getStatusBadge(order.status)}
                </div>
                <div style={{ marginBottom: '16px' }}>
                  <div style={{ fontSize: '18px', fontWeight: '800', marginBottom: '4px' }}>{order.customer}</div>
                  <div style={{ fontSize: '12px', color: 'rgba(255,255,255,0.5)', display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <Users size={14} /> {order.people} personas
                  </div>
                </div>
                <div style={{ backgroundColor: 'rgba(0,0,0,0.2)', padding: '12px', borderRadius: '12px', fontSize: '12px', color: 'rgba(255,255,255,0.7)' }}>
                  {order.items}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* 4. Resumen de Materia Prima (Panel Desplegable) */}
      <div style={{ 
        position: 'fixed', 
        bottom: 0, 
        left: 0, 
        width: '100%', 
        backgroundColor: 'rgba(0,0,0,0.6)', 
        backdropFilter: 'blur(30px)',
        borderTop: '1px solid rgba(255,255,255,0.1)',
        zIndex: 100,
        transition: 'all 0.5s cubic-bezier(0.4, 0, 0.2, 1)',
        maxHeight: isIngredientsOpen ? '400px' : '70px',
        padding: '0 4%'
      }}>
        <div 
          onClick={() => setIsIngredientsOpen(!isIngredientsOpen)}
          style={{ 
            height: '70px', 
            display: 'flex', 
            alignItems: 'center', 
            justifyContent: 'space-between', 
            cursor: 'pointer' 
          }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
            <Package color="#F97316" />
            <span style={{ fontWeight: '800', fontSize: '15px', textTransform: 'uppercase', letterSpacing: '1px' }}>Necesidades de Preparación (Próximas 48h)</span>
          </div>
          {isIngredientsOpen ? <ChevronDown /> : <ChevronUp />}
        </div>
        
        <div style={{ padding: '20px 0 40px 0', display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: '20px' }}>
          {ingredients.map((ing, i) => (
            <div key={i} style={{ backgroundColor: 'rgba(255,255,255,0.05)', padding: '16px', borderRadius: '12px', border: '1px solid rgba(255,255,255,0.1)' }}>
              <div style={{ fontSize: '11px', color: 'rgba(255,255,255,0.4)', fontWeight: '800', marginBottom: '4px' }}>{ing.name}</div>
              <div style={{ fontSize: '18px', fontWeight: '900', color: '#F97316' }}>{ing.qty}</div>
            </div>
          ))}
        </div>
      </div>
    </SubPageLayout>
  );
}
