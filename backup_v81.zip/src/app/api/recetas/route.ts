import { NextResponse } from 'next/server';
import recetasData from '@/lib/recetas.json';

export const dynamic = 'force-dynamic';
export const runtime = 'edge';

export async function GET() {
  try {
    return NextResponse.json(recetasData);
  } catch (error: any) {
    console.error('Error cargando recetas:', error);
    return NextResponse.json({ error: 'Error al cargar las recetas' }, { status: 500 });
  }
}
