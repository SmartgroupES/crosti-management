import { NextRequest, NextResponse } from 'next/server';
import { getRequestContext } from '@cloudflare/next-on-pages';

export const runtime = 'edge';
export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
  try {
    const context = getRequestContext() as any;
    const DB = context.env.DB;

    // 1. Hourly Sales (Last 24h)
    const hourlySales = await DB.prepare(`
      SELECT 
        strftime('%H:00', sale_date) as hour,
        SUM(total_amount) as total
      FROM sales
      WHERE sale_date >= date('now', '-1 day')
      GROUP BY hour
      ORDER BY hour ASC
    `).all();

    // 2. KPIs (Simplified & Robust)
    const todayResult = await DB.prepare(`SELECT SUM(total_amount) as total FROM sales WHERE date(sale_date) = date('now')`).first();
    const weekResult = await DB.prepare(`SELECT SUM(total_amount) as total FROM sales WHERE sale_date >= date('now', '-7 days')`).first();
    const monthResult = await DB.prepare(`SELECT SUM(total_amount) as total FROM sales WHERE sale_date >= date('now', 'start of month')`).first();
    const latestResult = await DB.prepare(`SELECT SUM(total_amount) as total FROM sales WHERE date(sale_date) = (SELECT MAX(date(sale_date)) FROM sales)`).first();

    // 3. Monthly Trend (Last 3 months)
    const monthlyStats = await DB.prepare(`
      SELECT 
        strftime('%Y-%m', sale_date) as month,
        SUM(total_amount) as sales
      FROM sales
      GROUP BY month
      ORDER BY month DESC
      LIMIT 3
    `).all();

    return NextResponse.json({
      hourlySales: hourlySales.results || [],
      todaySales: { total: (todayResult?.total || latestResult?.total || 0) },
      weekSales: { total: (weekResult?.total || 0) },
      monthSales: { total: (monthResult?.total || 0) },
      monthlyStats: (monthlyStats.results || []).reverse()
    });
  } catch (error: any) {
    console.error('Sales API Error:', error);
    return NextResponse.json({ error: error.message, todaySales: { total: 0 } }, { status: 500 });
  }
}
