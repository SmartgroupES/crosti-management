'use client';

import React, { useState, useEffect } from 'react';
import { 
  TrendingUp, 
  Download, 
  AlertCircle,
  RefreshCw
} from 'lucide-react';

export default function VentasView() {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchData = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/sales/hourly', { cache: 'no-store' });
      if (!res.ok) throw new Error(`Server Error: ${res.status}`);
      const json = await res.json();
      setData(json);
    } catch (e: any) {
      console.error(e);
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  if (loading) return (
    <div style={{ padding: '100px', textAlign: 'center' }}>
      <RefreshCw size={48} color="#F97316" className="animate-spin" style={{ marginBottom: '20px' }} />
      <div style={{ fontWeight: '800', color: '#9CA3AF', letterSpacing: '1px' }}>SINCRONIZANDO CON LA BASE DE DATOS...</div>
    </div>
  );

  if (error) return (
    <div style={{ padding: '60px', textAlign: 'center', backgroundColor: '#FEF2F2', borderRadius: '32px', border: '1px solid #FEE2E2' }}>
      <AlertCircle size={48} color="#EF4444" style={{ marginBottom: '20px' }} />
      <div style={{ fontWeight: '900', color: '#B91C1C', fontSize: '18px' }}>ERROR DE CONEXIÓN</div>
      <p style={{ color: '#EF4444', marginTop: '8px', fontSize: '14px' }}>{error}</p>
      <button 
        onClick={fetchData}
        style={{ marginTop: '24px', padding: '12px 24px', backgroundColor: '#B91C1C', color: 'white', border: 'none', borderRadius: '12px', fontWeight: '900', cursor: 'pointer' }}
      >
        REINTENTAR AHORA
      </button>
    </div>
  );

  const kpis = [
    { label: 'VENTA HOY', val: data?.todaySales?.total || 0 },
    { label: 'SEMANA ACTUAL', val: data?.weekSales?.total || 0 },
    { label: 'MES EN CURSO', val: data?.monthSales?.total || 0 },
    { label: 'CIERRE ANUAL PROY.', val: (data?.monthSales?.total || 0) * 12 },
  ];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '30px' }}>
      {/* 1. KPI Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '16px' }}>
        {kpis.map((kpi, idx) => (
          <div key={idx} style={{ 
            backgroundColor: '#F97316', color: 'white', padding: '24px', borderRadius: '24px',
            boxShadow: '0 8px 15px rgba(249, 115, 22, 0.1)', position: 'relative'
          }}>
            <div style={{ fontSize: '10px', fontWeight: '900', opacity: 0.8, letterSpacing: '1px' }}>{kpi.label}</div>
            <div style={{ fontSize: '24px', fontWeight: '900', marginTop: '8px' }}>{kpi.val.toLocaleString('es-ES')}€</div>
            <TrendingUp size={48} style={{ position: 'absolute', bottom: '-10px', right: '-10px', opacity: 0.1 }} />
          </div>
        ))}
      </div>

      {/* 2. Main Stats Table */}
      <div style={{ backgroundColor: 'white', borderRadius: '24px', border: '1px solid #E5E7EB', overflow: 'hidden' }}>
         <div style={{ padding: '16px 24px', borderBottom: '1px solid #F3F4F6', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <h3 style={{ fontSize: '14px', fontWeight: '900' }}>DESGLOSE DE VENTAS MENSUALES</h3>
            <span style={{ fontSize: '9px', fontWeight: '900', color: '#10B981', backgroundColor: '#DCFCE7', padding: '3px 8px', borderRadius: '8px' }}>DATA_LIVE</span>
         </div>
         <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
               <tr style={{ backgroundColor: '#F9FAFB', textAlign: 'left' }}>
                  <th style={{ padding: '16px 24px', fontSize: '10px', color: '#9CA3AF', fontWeight: '900' }}>PERIODO</th>
                  <th style={{ padding: '16px 24px', fontSize: '10px', color: '#9CA3AF', fontWeight: '900', textAlign: 'right' }}>VENTA TOTAL</th>
               </tr>
            </thead>
            <tbody>
               {data?.monthlyStats?.length > 0 ? data.monthlyStats.map((stat: any, idx: number) => (
                  <tr key={idx} style={{ borderBottom: '1px solid #F3F4F6' }}>
                     <td style={{ padding: '24px 32px', fontSize: '14px', fontWeight: '900' }}>{stat.month}</td>
                     <td style={{ padding: '24px 32px', textAlign: 'right', fontSize: '14px', fontWeight: '900', color: '#F97316' }}>{stat.sales.toLocaleString('es-ES')}€</td>
                  </tr>
               )) : (
                  <tr>
                    <td colSpan={2} style={{ padding: '40px', textAlign: 'center', color: '#9CA3AF', fontWeight: '700' }}>No hay datos históricos suficientes para mostrar el desglose.</td>
                  </tr>
               )}
            </tbody>
         </table>
      </div>
    </div>
  );
}
