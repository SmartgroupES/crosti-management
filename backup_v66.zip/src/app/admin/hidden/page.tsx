'use client';

import React, { useState, useEffect } from 'react';
import Header from '@/components/Header';
import { 
  Database, 
  HardDrive, 
  Send, 
  FileText, 
  History, 
  AlertOctagon, 
  ArrowLeft, 
  CheckCircle2, 
  Mail, 
  MessageSquare, 
  Terminal as TerminalIcon,
  Clock,
  ExternalLink,
  ChevronRight,
  ShieldCheck,
  Zap
} from 'lucide-react';
import { useRouter } from 'next/navigation';

export default function VaultAdminPage() {
  const router = useRouter();
  const [activeNode, setActiveNode] = useState<string | null>(null);
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [secondConfirm, setSecondConfirm] = useState(false);

  const d1Tables = [
    { name: 'ventas_hub', records: 12450, health: 'OPTIMAL' },
    { name: 'inventario_real', records: 850, health: 'OPTIMAL' },
    { name: 'personal_logins', records: 42, health: 'STABLE' },
    { name: 'catering_orders', records: 310, health: 'OPTIMAL' },
    { name: 'recetas_escandallos', records: 125, health: 'OPTIMAL' },
  ];

  const versionHistory = [
    { version: 'v61', date: '2026-05-01', desc: 'Rediseño Control de Calidad IA: Interfaz AR y análisis 24h.' },
    { version: 'v59', date: '2026-04-30', desc: 'Módulo de Catering: Timeline T+1/T+2 y Pre-Batch.' },
    { version: 'v58', date: '2026-04-29', desc: 'Analítica de Ventas: KPIs dinámicos y ranking de productos.' },
    { version: 'v55', date: '2026-04-25', desc: 'Seguridad: Implementación de Bóveda de Superadmin.' },
  ];

  const documents = [
    { name: 'Manual Calibración IA v4.2', icon: <Zap size={18} /> },
    { name: 'Protocolos Higiene Vitrina', icon: <CheckCircle2 size={18} /> },
    { name: 'Guía Usuario BakeOS', icon: <FileText size={18} /> },
  ];

  const handleReset = () => {
    alert("PURGA DE CACHE INICIADA. REINICIANDO SISTEMA...");
    window.location.reload();
  };

  return (
    <div style={{ 
      backgroundColor: '#121212', 
      minHeight: '100vh', 
      color: '#FFD700', // Gold Text
      fontFamily: '"Courier New", Courier, monospace',
      padding: '140px 4% 60px 4%',
      backgroundImage: 'radial-gradient(circle at 50% 50%, rgba(255, 215, 0, 0.05) 0%, transparent 80%)'
    }}>
      <Header />

      <div style={{ maxWidth: '1400px', margin: '0 auto' }}>
        {/* Header Terminal */}
        <div style={{ 
          display: 'flex', 
          justifyContent: 'space-between', 
          alignItems: 'flex-start', 
          borderBottom: '1px solid rgba(255, 215, 0, 0.2)', 
          paddingBottom: '32px',
          marginBottom: '48px'
        }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '8px' }}>
              <ShieldCheck color="#FFD700" size={32} />
              <h1 style={{ fontSize: '28px', fontWeight: '900', letterSpacing: '2px' }}>VAULT_ADMIN_CONSOLE</h1>
            </div>
            <div style={{ display: 'flex', gap: '20px', fontSize: '11px', opacity: 0.6 }}>
              <span>SYSTEM_STATUS: ONLINE</span>
              <span>Uptime: 142h 12m</span>
              <span>Node: Cloudflare_Worker_Madrid</span>
            </div>
          </div>
          <button 
            onClick={() => router.push('/')}
            style={{ 
              backgroundColor: 'transparent', border: '1px solid rgba(255, 215, 0, 0.3)', color: '#FFD700', padding: '10px 24px', borderRadius: '4px', cursor: 'pointer', fontSize: '12px', fontWeight: 'bold', display: 'flex', alignItems: 'center', gap: '10px' 
            }}>
            <ArrowLeft size={16} /> EXIT_VAULT
          </button>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(12, 1fr)', gap: '32px' }}>
          
          {/* Col 1-8: Arquitectura de Datos & Mensajería */}
          <div style={{ gridColumn: 'span 8', display: 'flex', flexDirection: 'column', gap: '32px' }}>
            
            {/* 1. Arquitectura de Datos (D1 & R2) */}
            <div style={{ backgroundColor: 'rgba(0,0,0,0.3)', border: '1px solid rgba(255, 215, 0, 0.1)', borderRadius: '16px', padding: '32px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '32px' }}>
                <Database size={20} />
                <h2 style={{ fontSize: '14px', fontWeight: '900', textTransform: 'uppercase' }}>D1_DATABASE_SCHEMA_GRAPH</h2>
              </div>
              
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '20px', marginBottom: '40px' }}>
                {d1Tables.map(table => (
                  <div 
                    key={table.name}
                    onClick={() => setActiveNode(activeNode === table.name ? null : table.name)}
                    style={{ 
                      flex: '1 1 200px',
                      padding: '20px',
                      backgroundColor: activeNode === table.name ? 'rgba(255, 215, 0, 0.15)' : 'rgba(255,255,255,0.03)',
                      border: `1px solid ${activeNode === table.name ? '#FFD700' : 'rgba(255, 215, 0, 0.1)'}`,
                      borderRadius: '8px',
                      cursor: 'pointer',
                      transition: 'all 0.3s ease'
                    }}
                  >
                    <div style={{ fontSize: '13px', fontWeight: '900', marginBottom: '12px', color: activeNode === table.name ? '#FFD700' : 'rgba(255,255,255,0.8)' }}>{table.name}</div>
                    {activeNode === table.name && (
                      <div style={{ fontSize: '11px', lineHeight: '1.6' }}>
                        <div style={{ color: '#44FF44' }}>Status: {table.health}</div>
                        <div>Records: {table.records.toLocaleString()}</div>
                      </div>
                    )}
                  </div>
                ))}
              </div>

              {/* R2 Monitor */}
              <div style={{ borderTop: '1px solid rgba(255, 215, 0, 0.1)', paddingTop: '24px', display: 'flex', justifyContent: 'space-between' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
                  <HardDrive size={24} />
                  <div>
                    <div style={{ fontSize: '10px', opacity: 0.5 }}>R2_BUCKET_USAGE</div>
                    <div style={{ fontSize: '18px', fontWeight: '900' }}>12.4 GB</div>
                  </div>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <div style={{ fontSize: '10px', opacity: 0.5 }}>OP_COST_PROJECTION_MONTH</div>
                  <div style={{ fontSize: '18px', fontWeight: '900', color: '#44FF44' }}>$2.45 USD</div>
                </div>
              </div>
            </div>

            {/* 2. Centro de Mensajería */}
            <div style={{ backgroundColor: 'rgba(0,0,0,0.3)', border: '1px solid rgba(255, 215, 0, 0.1)', borderRadius: '16px', padding: '32px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '32px' }}>
                <Send size={20} />
                <h2 style={{ fontSize: '14px', fontWeight: '900', textTransform: 'uppercase' }}>MESSAGE_SCHEDULER_V1</h2>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '40px' }}>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
                  {[
                    { label: 'REPORTES_EMAIL_DIARIOS', icon: <Mail size={16} />, active: true },
                    { label: 'ALERTA_WHATSAPP_CRITICA', icon: <MessageSquare size={16} />, active: true },
                    { label: 'LOG_TELEGRAM_MENSUAL', icon: <Send size={16} />, active: false },
                  ].map(toggle => (
                    <div key={toggle.label} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px', border: '1px solid rgba(255, 215, 0, 0.1)', borderRadius: '8px' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '12px', fontSize: '11px' }}>
                        {toggle.icon} {toggle.label}
                      </div>
                      <div style={{ 
                        width: '40px', height: '20px', borderRadius: '10px', backgroundColor: toggle.active ? '#FFD700' : 'rgba(255,255,255,0.1)', position: 'relative', cursor: 'pointer' 
                      }}>
                        <div style={{ position: 'absolute', top: '2px', left: toggle.active ? '22px' : '2px', width: '16px', height: '16px', borderRadius: '50%', backgroundColor: toggle.active ? '#000' : '#FFF', transition: 'all 0.2s' }} />
                      </div>
                    </div>
                  ))}
                </div>

                <div style={{ backgroundColor: 'rgba(0,0,0,0.2)', padding: '20px', borderRadius: '12px', border: '1px solid rgba(255, 215, 0, 0.1)' }}>
                  <div style={{ fontSize: '10px', opacity: 0.5, marginBottom: '16px' }}>RECENT_TRANSMISSIONS</div>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                    {[
                      { dest: 'Admin (Email)', time: '09:00', status: 'READ' },
                      { dest: 'Crosti_Bot (WA)', time: '08:45', status: 'READ' },
                      { dest: 'Log_Manager (Email)', time: '07:30', status: 'SENT' },
                    ].map((msg, i) => (
                      <div key={i} style={{ display: 'flex', justifyContent: 'space-between', fontSize: '11px' }}>
                        <span>{msg.dest}</span>
                        <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
                          <span style={{ opacity: 0.5 }}>{msg.time}</span>
                          <CheckCircle2 size={12} color={msg.status === 'READ' ? '#44FF44' : '#FFD700'} />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

          </div>

          {/* Col 9-12: Manuales, Timeline & Reset */}
          <div style={{ gridColumn: 'span 4', display: 'flex', flexDirection: 'column', gap: '32px' }}>
            
            {/* 3. Repositorio de Manuales */}
            <div style={{ backgroundColor: 'rgba(0,0,0,0.3)', border: '1px solid rgba(255, 215, 0, 0.1)', borderRadius: '16px', padding: '32px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '24px' }}>
                <FileText size={20} />
                <h2 style={{ fontSize: '14px', fontWeight: '900', textTransform: 'uppercase' }}>DOC_VAULT_PDF</h2>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                {documents.map(doc => (
                  <div key={doc.name} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '16px', backgroundColor: 'rgba(255,255,255,0.02)', borderRadius: '8px', cursor: 'pointer', border: '1px solid transparent' }} className="doc-item">
                    <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                      <div style={{ color: '#FFD700' }}>{doc.icon}</div>
                      <span style={{ fontSize: '11px' }}>{doc.name}</span>
                    </div>
                    <ExternalLink size={14} opacity={0.4} />
                  </div>
                ))}
              </div>
            </div>

            {/* 4. Log de Versiones */}
            <div style={{ backgroundColor: 'rgba(0,0,0,0.3)', border: '1px solid rgba(255, 215, 0, 0.1)', borderRadius: '16px', padding: '32px', flex: 1 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '32px' }}>
                <Clock size={20} />
                <h2 style={{ fontSize: '14px', fontWeight: '900', textTransform: 'uppercase' }}>VERSION_TIMELINE</h2>
              </div>
              <div style={{ position: 'relative', paddingLeft: '20px', borderLeft: '2px solid rgba(255, 215, 0, 0.2)' }}>
                {versionHistory.map((h, i) => (
                  <div key={h.version} style={{ position: 'relative', marginBottom: '32px' }}>
                    <div style={{ position: 'absolute', left: '-27px', top: '0', width: '12px', height: '12px', borderRadius: '50%', backgroundColor: i === 0 ? '#FFD700' : '#121212', border: '2px solid #FFD700' }} />
                    <div style={{ fontSize: '12px', fontWeight: '900', marginBottom: '4px' }}>{h.version} | {h.date}</div>
                    <div style={{ fontSize: '11px', opacity: 0.6, lineHeight: '1.4' }}>{h.desc}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* 5. Reset de Emergencia */}
            <div style={{ marginTop: 'auto' }}>
              {!showResetConfirm ? (
                <button 
                  onClick={() => setShowResetConfirm(true)}
                  style={{ 
                    width: '100%', 
                    backgroundColor: 'transparent', 
                    border: '1px solid #EF4444', 
                    color: '#EF4444', 
                    padding: '20px', 
                    borderRadius: '12px', 
                    fontSize: '12px', 
                    fontWeight: '900', 
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: '12px'
                  }}
                >
                  <AlertOctagon size={18} /> SYSTEM_PURGE_RESET
                </button>
              ) : (
                <div style={{ backgroundColor: '#EF4444', color: 'white', padding: '24px', borderRadius: '12px', animation: 'blink 0.5s infinite' }}>
                  <div style={{ fontWeight: '900', fontSize: '14px', marginBottom: '16px' }}>!!! CONFIRM_PURGE_SEQUENCE !!!</div>
                  {!secondConfirm ? (
                    <button 
                      onClick={() => setSecondConfirm(true)}
                      style={{ width: '100%', backgroundColor: 'white', color: '#EF4444', border: 'none', padding: '12px', fontWeight: '900', cursor: 'pointer', borderRadius: '4px' }}
                    >
                      INITIALIZE_STEP_1
                    </button>
                  ) : (
                    <div style={{ display: 'flex', gap: '10px' }}>
                      <button 
                        onClick={handleReset}
                        style={{ flex: 1, backgroundColor: 'black', color: 'white', border: 'none', padding: '12px', fontWeight: '900', cursor: 'pointer', borderRadius: '4px' }}
                      >
                        EXECUTE
                      </button>
                      <button 
                        onClick={() => { setShowResetConfirm(false); setSecondConfirm(false); }}
                        style={{ flex: 1, backgroundColor: 'white', color: '#EF4444', border: 'none', padding: '12px', fontWeight: '900', cursor: 'pointer', borderRadius: '4px' }}
                      >
                        ABORT
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>

          </div>
        </div>
      </div>

      <style jsx global>{`
        @keyframes blink {
          0% { opacity: 1; }
          50% { opacity: 0.6; }
          100% { opacity: 1; }
        }
        .doc-item:hover {
          background-color: rgba(255, 215, 0, 0.05) !important;
          border-color: rgba(255, 215, 0, 0.2) !important;
        }
        ::-webkit-scrollbar {
          width: 6px;
        }
        ::-webkit-scrollbar-track {
          background: #121212;
        }
        ::-webkit-scrollbar-thumb {
          background: rgba(255, 215, 0, 0.2);
          border-radius: 10px;
        }
      `}</style>
    </div>
  );
}
