'use client';

import React, { useState, useEffect } from 'react';
import SubPageLayout from '@/components/SubPageLayout';
import { 
  TrendingUp, 
  Download, 
  FileText, 
  Calendar, 
  Store,
  Loader2,
  BarChart3,
  ChevronLeft
} from 'lucide-react';
import { useRouter } from 'next/navigation';

export default function VentasPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [hoveredBar, setHoveredBar] = useState<number | null>(null);

  useEffect(() => {
    setTimeout(() => setLoading(false), 1000);
  }, []);

  const kpis = [
    { label: 'Venta Hoy', value: '1.240€' },
    { label: 'Semana Actual', value: '8.450€' },
    { label: 'Mes en Curso', value: '32.100€' },
    { label: 'Cierre Anual', value: '385.000€' },
  ];

  const chartData = [
    { month: 'ENE', sales: 45000 },
    { month: 'FEB', sales: 52000 },
    { month: 'MAR', sales: 48000 },
    { month: 'ABR', sales: 61000 },
    { month: 'MAY', sales: 55000 },
    { month: 'JUN', sales: 67000 },
    { month: 'JUL', sales: 72000 },
    { month: 'AGO', sales: 69000 },
    { month: 'SEP', sales: 58000 },
    { month: 'OCT', sales: 63000 },
    { month: 'NOV', sales: 70000 },
    { month: 'DIC', sales: 85000 },
  ];

  const topProducts = [
    { name: 'Cookies de Mantequilla', percent: 85, amount: '12.450€' },
    { name: 'Focaccia de Romero', percent: 72, amount: '9.820€' },
    { name: 'Ensalada César BakeOS', percent: 65, amount: '8.100€' },
    { name: 'Napolitana Choco', percent: 48, amount: '5.400€' },
    { name: 'Tarta de Queso', percent: 35, amount: '4.200€' },
  ];

  const handleExport = async (format: 'xlsx' | 'pdf') => {
    try {
      const response = await fetch('/api/export', {
        method: 'POST',
        body: JSON.stringify({
          format,
          data: chartData,
          type: 'Ventas',
          location: 'Velazquez'
        }),
        headers: { 'Content-Type': 'application/json' }
      });
      
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `Ventas_Crosti_Velazquez_${new Date().toISOString().split('T')[0]}.${format}`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Error exporting:', error);
    }
  };

  if (loading) {
    return (
      <SubPageLayout title="Seguimiento de Ventas">
        <div style={{ height: '50vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: '20px' }}>
          <Loader2 className="animate-spin" size={40} color="#F97316" />
          <p style={{ color: 'rgba(255,255,255,0.4)', fontWeight: '600' }}>Cargando analítica de ventas...</p>
        </div>
      </SubPageLayout>
    );
  }

  return (
    <SubPageLayout title="Seguimiento de Ventas">
      {/* 1. Cabecera con Botones de Exportación */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '40px' }}>
        <button 
          onClick={() => router.push('/')}
          style={{ display: 'flex', alignItems: 'center', gap: '8px', background: 'none', border: 'none', color: 'rgba(255,255,255,0.4)', cursor: 'pointer', fontSize: '12px', fontWeight: '800' }}
        >
          <ChevronLeft size={16} /> VOLVER AL PANEL
        </button>

        <div style={{ display: 'flex', gap: '12px' }}>
          <button 
            onClick={() => handleExport('xlsx')}
            style={{ width: '44px', height: '44px', borderRadius: '50%', backgroundColor: 'rgba(16, 185, 129, 0.1)', border: '1px solid rgba(16, 185, 129, 0.2)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}
          >
            <Download size={20} color="#10B981" />
          </button>
          <button 
            onClick={() => handleExport('pdf')}
            style={{ width: '44px', height: '44px', borderRadius: '50%', backgroundColor: 'rgba(239, 68, 68, 0.1)', border: '1px solid rgba(239, 68, 68, 0.2)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}
          >
            <FileText size={20} color="#EF4444" />
          </button>
        </div>
      </div>

      {/* 2. KPIs (Globos Naranja) */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '20px', marginBottom: '60px' }}>
        {kpis.map((kpi, idx) => (
          <div key={idx} style={{ 
            backgroundColor: '#F97316', 
            padding: '24px', 
            borderRadius: '24px', 
            boxShadow: '0 15px 30px rgba(249, 115, 22, 0.3)',
            textAlign: 'center',
            transition: 'transform 0.3s ease'
          }} onMouseOver={(e) => e.currentTarget.style.transform = 'translateY(-5px)'} onMouseOut={(e) => e.currentTarget.style.transform = 'translateY(0)'}>
            <div style={{ fontSize: '10px', fontWeight: '900', color: 'rgba(255,255,255,0.7)', textTransform: 'uppercase', letterSpacing: '2px', marginBottom: '8px' }}>
              {kpi.label}
            </div>
            <div style={{ fontSize: '28px', fontWeight: '900', color: 'white' }}>
              {kpi.value}
            </div>
          </div>
        ))}
      </div>

      {/* 3. Gráfico Principal (Contenedor de Cristal) */}
      <div style={{ 
        backgroundColor: 'rgba(0, 0, 0, 0.3)', 
        backdropFilter: 'blur(30px)',
        padding: '60px', 
        borderRadius: '32px', 
        border: '1px solid rgba(255, 255, 255, 0.1)',
        marginBottom: '60px',
        boxShadow: '0 25px 50px rgba(0,0,0,0.3)'
      }}>
        <div style={{ marginBottom: '40px', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
          <div>
            <h2 style={{ fontSize: '20px', fontWeight: '900', color: 'white', margin: 0 }}>Rendimiento Anual por Mes</h2>
            <p style={{ fontSize: '12px', color: 'rgba(255,255,255,0.4)', marginTop: '6px' }}>Suma de Ventas Totales Proyectadas</p>
          </div>
          <div style={{ fontSize: '10px', fontWeight: '900', color: '#F97316', letterSpacing: '1px' }}>DATOS REALES D1</div>
        </div>

        <div style={{ height: '300px', display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', gap: '14px' }}>
          {chartData.map((data, i) => {
            const max = Math.max(...chartData.map(d => d.sales));
            const height = (data.sales / max) * 260;
            return (
              <div 
                key={i} 
                onMouseEnter={() => setHoveredBar(i)}
                onMouseLeave={() => setHoveredBar(null)}
                style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '16px', cursor: 'pointer' }}
              >
                <div style={{ 
                  width: '100%', 
                  height: `${height}px`, 
                  background: hoveredBar === i 
                    ? 'linear-gradient(180deg, #F97316 0%, #EF4444 100%)' 
                    : 'linear-gradient(180deg, #EF4444 0%, rgba(239, 68, 68, 0.1) 100%)', 
                  borderRadius: '10px 10px 4px 4px',
                  transition: 'all 0.4s cubic-bezier(0.16, 1, 0.3, 1)',
                  boxShadow: hoveredBar === i ? '0 0 25px rgba(239, 68, 68, 0.5)' : 'none'
                }} />
                <span style={{ fontSize: '10px', fontWeight: '900', color: hoveredBar === i ? 'white' : 'rgba(255,255,255,0.3)' }}>{data.month}</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* 4. Top Five List */}
      <div style={{ maxWidth: '800px' }}>
        <h2 style={{ fontSize: '14px', fontWeight: '900', color: '#F97316', marginBottom: '32px', letterSpacing: '3px', textTransform: 'uppercase' }}>
          Top 5 Best Sellers
        </h2>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          {topProducts.map((p, idx) => (
            <div key={idx} style={{ 
              display: 'flex', 
              alignItems: 'center', 
              gap: '32px', 
              padding: '24px', 
              backgroundColor: 'rgba(0,0,0,0.2)', 
              borderRadius: '20px',
              border: '1px solid rgba(255,255,255,0.05)',
              transition: 'transform 0.2s'
            }} className="top-item">
              <span style={{ fontSize: '16px', fontWeight: '900', color: '#F97316', width: '20px' }}>{idx + 1}</span>
              <span style={{ flex: 1, fontSize: '14px', fontWeight: '800' }}>{p.name}</span>
              
              <div style={{ width: '150px', height: '4px', backgroundColor: 'rgba(255,255,255,0.05)', borderRadius: '10px', overflow: 'hidden' }}>
                <div style={{ width: `${p.percent}%`, height: '100%', backgroundColor: '#EF4444', borderRadius: '10px', opacity: 0.8 }} />
              </div>
              
              <span style={{ fontSize: '16px', fontWeight: '900', width: '80px', textAlign: 'right', letterSpacing: '-0.5px' }}>{p.amount}</span>
            </div>
          ))}
        </div>
      </div>

      <style jsx global>{`
        .animate-spin {
          animation: spin 1s linear infinite;
        }
        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        .top-item:hover {
          transform: translateX(10px);
          background-color: rgba(0,0,0,0.3);
          border-color: rgba(249, 115, 22, 0.2);
        }
      `}</style>
    </SubPageLayout>
  );
}
