'use client';

import React from 'react';
import Header from '@/components/Header';
import { 
  BarChart3, 
  TrendingUp, 
  Calculator, 
  BookOpen, 
  Calendar, 
  ChefHat, 
  Trash2, 
  ShoppingCart, 
  Package, 
  Settings, 
  Camera, 
  Zap, 
  Users, 
  Clock, 
  Activity,
  ArrowRight
} from 'lucide-react';
import { useRouter } from 'next/navigation';

export default function HomePage() {
  const router = useRouter();

  const sections = [
    {
      title: "ANÁLISIS",
      items: [
        { label: "Seguimiento de Ventas", href: "/consulta/ventas", icon: <TrendingUp size={18} /> },
        { label: "Rentabilidad", href: "/analisis/rentabilidad", icon: <Calculator size={18} /> },
        { label: "Simulador de Costos", href: "/admin/simulador", icon: <Activity size={18} /> },
        { label: "Gestión de Recetas", href: "/admin/escandallos", icon: <BookOpen size={18} /> }
      ]
    },
    {
      title: "OPERACIONES",
      items: [
        { label: "Planificación", href: "/planificacion", icon: <Calendar size={18} /> },
        { label: "Gestión Catering", href: "/produccion/catering", icon: <ChefHat size={18} /> },
        { label: "Gestión de Merma", href: "/produccion/merma", icon: <Trash2 size={18} /> },
        { label: "Compras", href: "/inventario/compras", icon: <ShoppingCart size={18} /> },
        { label: "Control de Stock", href: "/inventario/stock", icon: <Package size={18} /> },
        { label: "Mantenimiento", href: "/admin/mantenimiento", icon: <Settings size={18} /> }
      ]
    },
    {
      title: "BAKEOS IA",
      items: [
        { label: "Control Calidad (Foto)", href: "/analisis/calidad", icon: <Camera size={18} /> },
        { label: "Sincro Omnicanal", href: "/analisis/omnichannel", icon: <Zap size={18} /> }
      ]
    },
    {
      title: "EQUIPO & SISTEMA",
      items: [
        { label: "Personal y Equipo", href: "/admin/personal", icon: <Users size={18} /> },
        { label: "Horarios y Turnos", href: "/admin/personal/horarios", icon: <Clock size={18} /> }
      ]
    }
  ];

  return (
    <div className="fade-in" style={{ 
      minHeight: '100vh', 
      width: '100%',
      padding: '140px 5% 60px 5%',
      display: 'flex',
      flexDirection: 'column',
      backgroundColor: '#601010', 
      backgroundImage: 'radial-gradient(circle at top, #601010 0%, #200505 100%)',
      position: 'relative',
      overflowX: 'hidden'
    }}>
      <Header />

      <div style={{
        maxWidth: '1600px',
        margin: '0 auto',
        width: '100%'
      }}>
        {/* Cuerpo del Panel: Título */}
        <div style={{ marginBottom: '60px' }}>
          <h1 style={{ 
            fontSize: '42px', 
            fontWeight: '900', 
            color: 'white', 
            marginBottom: '12px', 
            letterSpacing: '-1px',
            fontFamily: '"Outfit", sans-serif'
          }}>
            Panel de Gestión
          </h1>
          <p style={{ color: 'rgba(255,255,255,0.5)', fontSize: '16px', fontWeight: '500', letterSpacing: '0.5px' }}>
            BakeOS Intelligence Suite | Crosti Hub Pilot v1.0
          </p>
        </div>

        {/* 4 Bloques Principales */}
        <div style={{ 
          display: 'grid', 
          gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', 
          gap: '32px',
          width: '100%'
        }}>
          {sections.map((section, idx) => (
            <div key={idx} style={{ 
              backgroundColor: 'rgba(0, 0, 0, 0.45)', 
              padding: '40px', 
              borderRadius: '32px',
              border: '1px solid rgba(255, 255, 255, 0.1)',
              display: 'flex', 
              flexDirection: 'column', 
              gap: '24px',
              backdropFilter: 'blur(16px)',
              boxShadow: '0 20px 40px rgba(0,0,0,0.4)',
              transition: 'transform 0.4s ease'
            }} className="section-card">
              {/* Títulos en mayúsculas amarillas/doradas */}
              <h2 style={{ 
                fontSize: '11px', 
                fontWeight: '900', 
                color: '#FFD700', 
                letterSpacing: '4px',
                textTransform: 'uppercase',
                margin: 0,
                opacity: 0.8
              }}>
                {section.title}
              </h2>
              
              {/* Estilo de Botones: Rectángulos con bordes redondeados */}
              <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                {section.items.map((item, i) => (
                  <button 
                    key={i}
                    onClick={() => router.push(item.href)}
                    style={{
                      backgroundColor: 'rgba(128, 21, 21, 0.2)', 
                      border: '1px solid rgba(255, 255, 255, 0.05)',
                      padding: '18px 24px',
                      borderRadius: '16px',
                      color: 'white',
                      fontSize: '14px',
                      fontWeight: '700',
                      cursor: 'pointer',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
                      textAlign: 'left'
                    }}
                    onMouseOver={(e) => {
                      e.currentTarget.style.backgroundColor = 'rgba(128, 21, 21, 0.6)';
                      e.currentTarget.style.borderColor = 'rgba(249, 115, 22, 0.4)';
                      e.currentTarget.style.transform = 'translateX(4px)';
                      e.currentTarget.style.boxShadow = '0 5px 15px rgba(0,0,0,0.3)';
                    }}
                    onMouseOut={(e) => {
                      e.currentTarget.style.backgroundColor = 'rgba(128, 21, 21, 0.2)';
                      e.currentTarget.style.borderColor = 'rgba(255, 255, 255, 0.05)';
                      e.currentTarget.style.transform = 'translateX(0)';
                      e.currentTarget.style.boxShadow = 'none';
                    }}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
                      <span style={{ color: '#F97316', display: 'flex' }}>{item.icon}</span>
                      {item.label}
                    </div>
                    <ArrowRight size={14} style={{ opacity: 0.3 }} />
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      <style jsx global>{`
        @import url('https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;800;900&display=swap');
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .fade-in {
          animation: fadeIn 0.8s cubic-bezier(0.16, 1, 0.3, 1) forwards;
        }
        .section-card:hover {
          transform: translateY(-5px);
          border-color: rgba(255, 215, 0, 0.2);
        }
      `}</style>
    </div>
  );
}
