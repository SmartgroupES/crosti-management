'use client';

import React from 'react';
import Header from '@/components/Header';

export default function HomePage() {

  const columns = [
    {
      title: "ANÁLISIS",
      items: [
        { label: "SEGUIMIENTO DE VENTAS", href: "/consulta/ventas" },
        { label: "RENTABILIDAD", href: "/analisis/rentabilidad" },
        { label: "SIMULADOR DE COSTOS", href: "/admin/simulador" },
        { label: "GESTIÓN DE RECETAS", href: "/admin/escandallos" }
      ]
    },
    {
      title: "OPERACIONES",
      items: [
        { label: "PLANIFICACIÓN DE PRODUCCIÓN", href: "/planificacion" },
        { label: "GESTIÓN DE CATERING", href: "/produccion/catering" },
        { label: "MERMA", href: "/produccion/merma" },
        { label: "COMPRAS", href: "/inventario/compras" },
        { label: "CONTROL DE STOCK", href: "/inventario/stock" },
        { label: "MANTENIMIENTO", href: "/admin/mantenimiento" }
      ]
    },
    {
      title: "BAKEOS IA",
      items: [
        { label: "CONTROL DE CALIDAD (FOTO)", href: "/inventario/foto" },
        { label: "SINCRONIZACIÓN OMNICANAL", href: "/analisis/omnichannel" },
        { label: "LAYOUT Y MERCHANDISING", href: "/analisis/layout" },
        { label: "SCORE DE CALIDAD VISUAL", href: "/analisis/calidad" }
      ]
    },
    {
      title: "EQUIPO",
      items: [
        { label: "PERSONAL Y EQUIPO", href: "/admin/personal" },
        { label: "HORARIOS Y TURNOS", href: "/admin/personal/horarios" },
        { label: "CONTROL SANITARIO", href: "/admin/appcc" }
      ]
    },
    {
      title: "SISTEMA",
      items: [
        { label: "ADMINISTRACIÓN", href: "/admin/configuracion" }
      ]
    }
  ];

  return (
    <div style={{ 
      backgroundColor: '#FFFFFF', // White Background
      minHeight: '100vh', 
      width: '100%',
      padding: '40px 5% 5% 5%',
      fontFamily: 'system-ui, -apple-system, sans-serif',
      color: '#1A1A1A',
      boxSizing: 'border-box',
      display: 'flex',
      flexDirection: 'column',
      position: 'relative'
    }}>
      <Header />

      {/* 4-Column Grid */}
      <div style={{ 
        display: 'grid', 
        gridTemplateColumns: 'repeat(4, 1fr)', 
        gap: '30px',
        width: '100%',
        flex: 1
      }}>
        {columns.map((col, idx) => (
          <div key={idx} style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
            {/* Column Label */}
            <div style={{ fontSize: '10px', fontWeight: '900', letterSpacing: '2px', opacity: 0.5, marginBottom: '6px' }}>
              {col.title}
            </div>
            
            {col.items.map((item, i) => (
              <button 
                key={i}
                onClick={() => window.location.href = item.href}
                style={{
                  backgroundColor: '#F8E39D', // Crosti Yellow Tag
                  border: '1px solid rgba(155, 27, 34, 0.1)',
                  padding: '24px 20px',
                  borderRadius: '16px',
                  color: '#9B1B22', // Crosti Red text
                  fontSize: '13px',
                  fontWeight: '900',
                  letterSpacing: '1px',
                  cursor: 'pointer',
                  textAlign: 'center',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
                  textTransform: 'uppercase',
                  lineHeight: '1.4',
                  boxShadow: '6px 6px 20px rgba(0,0,0,0.08)',
                  minHeight: '80px'
                }}
                onMouseOver={(e) => {
                  e.currentTarget.style.backgroundColor = '#FFFFFF';
                  e.currentTarget.style.border = '1px solid #9B1B22';
                  e.currentTarget.style.transform = 'translateY(-3px) translateX(-2px)';
                  e.currentTarget.style.boxShadow = '10px 10px 30px rgba(155, 27, 34, 0.15)';
                }}
                onMouseOut={(e) => {
                  e.currentTarget.style.backgroundColor = '#F8E39D';
                  e.currentTarget.style.border = '1px solid rgba(155, 27, 34, 0.1)';
                  e.currentTarget.style.transform = 'translateY(0) translateX(0)';
                  e.currentTarget.style.boxShadow = '6px 6px 20px rgba(0,0,0,0.08)';
                }}
              >
                {item.label}
              </button>
            ))}
          </div>
        ))}
      </div>



      <style jsx global>{`
        body { margin: 0; padding: 0; overflow-x: hidden; }
        * { box-sizing: border-box; }
      `}</style>
    </div>
  );
}
