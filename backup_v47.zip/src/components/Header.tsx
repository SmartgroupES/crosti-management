'use client';

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Globe, LogOut, Key, User, ChevronDown } from 'lucide-react';

export default function Header() {
  const router = useRouter();
  const [lang, setLang] = useState('ES');
  const [showLangMenu, setShowLangMenu] = useState(false);
  const [userName, setUserName] = useState('Usuario');

  useEffect(() => {
    // Try to get user name from cookie or state
    const name = document.cookie
      .split('; ')
      .find(row => row.startsWith('user_name='))
      ?.split('=')[1];
    if (name) setUserName(decodeURIComponent(name));
  }, []);

  const handleLogout = async () => {
    await fetch('/api/auth/login', { method: 'DELETE' });
    router.push('/login');
  };

  return (
    <header style={{
      width: '100%',
      padding: '20px 5%',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      position: 'absolute',
      top: 0,
      left: 0,
      zIndex: 100,
      boxSizing: 'border-box'
    }}>
      {/* Left: Crosti Logo */}
      <div 
        onClick={() => router.push('/')}
        style={{ 
          display: 'flex', 
          alignItems: 'center', 
          gap: '12px', 
          cursor: 'pointer',
          transition: 'transform 0.2s'
        }}
        onMouseOver={(e) => (e.currentTarget.style.transform = 'scale(1.02)')}
        onMouseOut={(e) => (e.currentTarget.style.transform = 'scale(1)')}
      >
        <img 
          src="/logo-crosti.jpg" 
          alt="Crosti Logo" 
          style={{ 
            height: '45px', 
            borderRadius: '10px', 
            boxShadow: '0 4px 10px rgba(0,0,0,0.1)' 
          }} 
        />
        <span style={{ 
          fontSize: '18px', 
          fontWeight: '900', 
          color: '#9B1B22', 
          letterSpacing: '-0.5px' 
        }}>
          CROSTI HUB
        </span>
      </div>

      {/* Right: Actions & Info */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '20px' }}>
        {/* BakeOS Badge */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '8px',
          padding: '6px 12px',
          borderRadius: '20px',
          backgroundColor: '#F97316',
          color: 'white',
          fontSize: '10px',
          fontWeight: '900',
          letterSpacing: '1px',
          boxShadow: '0 4px 10px rgba(249, 115, 22, 0.2)'
        }}>
          <div style={{ width: '6px', height: '6px', borderRadius: '50%', backgroundColor: 'white', animation: 'pulse 2s infinite' }} />
          BAKEOS POWERED
        </div>

        <style jsx>{`
          @keyframes pulse {
            0% { transform: scale(0.95); opacity: 1; }
            70% { transform: scale(1.5); opacity: 0; }
            100% { transform: scale(0.95); opacity: 0; }
          }
        `}</style>

        {/* Language Selector */}
        <div style={{ position: 'relative' }}>
          <button 
            onClick={() => setShowLangMenu(!showLangMenu)}
            style={{
              backgroundColor: 'rgba(0, 0, 0, 0.05)',
              border: '1px solid rgba(0, 0, 0, 0.1)',
              color: '#1A1A1A',
              padding: '8px 12px',
              borderRadius: '10px',
              fontSize: '12px',
              fontWeight: '700',
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              cursor: 'pointer'
            }}
          >
            <Globe size={14} />
            {lang}
            <ChevronDown size={12} />
          </button>
          {showLangMenu && (
            <div style={{
              position: 'absolute',
              top: '45px',
              right: 0,
              backgroundColor: 'white',
              borderRadius: '12px',
              boxShadow: '0 10px 25px rgba(0,0,0,0.2)',
              overflow: 'hidden',
              minWidth: '100px'
            }}>
              <div 
                onClick={() => { setLang('ES'); setShowLangMenu(false); }}
                style={{ padding: '12px 16px', color: '#1A1A1A', fontSize: '13px', fontWeight: '600', cursor: 'pointer', backgroundColor: lang === 'ES' ? '#F3F4F6' : 'transparent' }}
              >
                Español
              </div>
              <div 
                onClick={() => { setLang('EN'); setShowLangMenu(false); }}
                style={{ padding: '12px 16px', color: '#1A1A1A', fontSize: '13px', fontWeight: '600', cursor: 'pointer', backgroundColor: lang === 'EN' ? '#F3F4F6' : 'transparent' }}
              >
                English
              </div>
            </div>
          )}
        </div>

        {/* User Info & Actions */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '20px', color: '#1A1A1A' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <div style={{ width: '32px', height: '32px', borderRadius: '50%', backgroundColor: 'rgba(0, 0, 0, 0.05)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <User size={16} />
            </div>
            <span style={{ fontSize: '14px', fontWeight: '700' }}>{userName}</span>
          </div>

          <div style={{ width: '1px', height: '20px', backgroundColor: 'rgba(0, 0, 0, 0.1)' }} />

          <div style={{ display: 'flex', gap: '12px' }}>
            <button 
              title="Cambiar Contraseña"
              style={{ backgroundColor: 'transparent', border: 'none', color: '#1A1A1A', opacity: 0.7, cursor: 'pointer', transition: 'opacity 0.2s' }}
              onMouseOver={(e) => (e.currentTarget.style.opacity = '1')}
              onMouseOut={(e) => (e.currentTarget.style.opacity = '0.7')}
            >
              <Key size={18} />
            </button>
            <button 
              onClick={handleLogout}
              title="Cerrar Sesión"
              style={{ backgroundColor: 'transparent', border: 'none', color: '#9B1B22', cursor: 'pointer', transition: 'transform 0.2s' }}
              onMouseOver={(e) => (e.currentTarget.style.transform = 'scale(1.1)')}
              onMouseOut={(e) => (e.currentTarget.style.transform = 'scale(1)')}
            >
              <LogOut size={18} />
            </button>
          </div>
        </div>
      </div>
    </header>
  );

}
