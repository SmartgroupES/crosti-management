'use client';

import React, { useState, useEffect } from 'react';
import SubPageLayout from '@/components/SubPageLayout';
import { 
  Users, 
  Package, 
  Clock, 
  Camera, 
  Plus, 
  History,
  Download,
  FileText,
  ChevronDown,
  ChevronUp,
  Calendar,
  Flame,
  CheckCircle2,
  Loader2,
  ArrowLeft
} from 'lucide-react';
import { useRouter } from 'next/navigation';

export default function CateringPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [isIngredientsOpen, setIsIngredientsOpen] = useState(false);

  useEffect(() => {
    setTimeout(() => setLoading(false), 800);
  }, []);

  const t1Orders = [
    { id: 1, customer: 'Empresa Alpha', time: '08:30', items: ['50 Cookies XL', '30 Focaccias'], status: 'Listo' },
    { id: 2, customer: 'Eventos Madrid', time: '10:00', items: ['100 Mini Croissants', '50 Jugos'], status: 'En Horno' },
    { id: 3, customer: 'Hotel Ritz', time: '11:45', items: ['200 Baguettes', '40 Tartas'], status: 'Pendiente' },
  ];

  const t2Orders = [
    { id: 4, customer: 'Google Office', time: '09:00', items: ['150 Salados Variados'], status: 'Pendiente' },
    { id: 5, customer: 'BBVA Hub', time: '13:00', items: ['300 Cookies Especiales'], status: 'Pendiente' },
  ];

  const consolidatedIngredients = [
    { name: 'Mantequilla Premium', total: '24kg' },
    { name: 'Harina Tradición', total: '65kg' },
    { name: 'Chocolate Bélga', total: '12kg' },
    { name: 'Huevos Camperos', total: '180 uds' },
    { name: 'Azúcar Moreno', total: '18kg' },
  ];

  const getStatusBadge = (status: string) => {
    const styles: Record<string, any> = {
      'Listo': { bg: 'rgba(16, 185, 129, 0.2)', color: '#10B981', icon: <CheckCircle2 size={12} /> },
      'En Horno': { bg: 'rgba(249, 115, 22, 0.2)', color: '#F97316', icon: <Flame size={12} /> },
      'Pendiente': { bg: 'rgba(255, 255, 255, 0.1)', color: 'rgba(255, 255, 255, 0.5)', icon: <Clock size={12} /> },
    };
    const s = styles[status] || styles['Pendiente'];
    return (
      <div style={{ display: 'flex', alignItems: 'center', gap: '6px', padding: '6px 14px', borderRadius: '20px', backgroundColor: s.bg, color: s.color, fontSize: '10px', fontWeight: '900', textTransform: 'uppercase', letterSpacing: '1px' }}>
        {s.icon} {status}
      </div>
    );
  };

  if (loading) {
    return (
      <SubPageLayout title="Gestión de Catering">
        <div style={{ height: '50vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: '20px' }}>
          <Loader2 className="animate-spin" size={40} color="#F97316" />
          <p style={{ color: 'rgba(255,255,255,0.4)', fontWeight: '600' }}>Cargando logística de catering...</p>
        </div>
      </SubPageLayout>
    );
  }

  return (
    <SubPageLayout title="Gestión de Catering">
      {/* 1. Cabecera */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '48px' }}>
        <button 
          onClick={() => router.push('/')}
          style={{ display: 'flex', alignItems: 'center', gap: '8px', background: 'none', border: 'none', color: 'rgba(255,255,255,0.4)', cursor: 'pointer', fontSize: '12px', fontWeight: '800' }}
        >
          <ArrowLeft size={16} /> VOLVER
        </button>

        <div style={{ display: 'flex', gap: '16px' }}>
          <button className="glass-btn" style={{ padding: '12px 24px', borderRadius: '14px', border: '1px solid rgba(255,255,255,0.1)', backgroundColor: 'rgba(255,255,255,0.05)', color: 'white', fontWeight: '800', fontSize: '12px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '10px' }}>
            <Plus size={16} color="#F97316" /> NUEVO PEDIDO
          </button>
        </div>
      </div>

      {/* 2. Timeline Dinámico */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '40px', marginBottom: '100px' }}>
        
        {/* Bloque T+1 */}
        <div>
          <h2 style={{ fontSize: '13px', fontWeight: '900', color: 'rgba(255,255,255,0.3)', letterSpacing: '3px', textTransform: 'uppercase', marginBottom: '32px', display: 'flex', alignItems: 'center', gap: '12px' }}>
            <Calendar size={16} /> Entregas Mañana (T+1)
          </h2>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
            {t1Orders.map(order => (
              <div key={order.id} style={{ backgroundColor: 'rgba(255,255,255,0.03)', backdropFilter: 'blur(20px)', padding: '32px', borderRadius: '24px', border: '1px solid rgba(255,255,255,0.08)', position: 'relative' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
                  <div style={{ fontSize: '28px', fontWeight: '900', color: '#FFD700' }}>{order.time}</div>
                  {getStatusBadge(order.status)}
                </div>
                <div style={{ fontSize: '18px', fontWeight: '800', marginBottom: '12px' }}>{order.customer}</div>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', marginBottom: '24px' }}>
                  {order.items.map(item => (
                    <span key={item} style={{ fontSize: '11px', backgroundColor: 'rgba(0,0,0,0.2)', padding: '6px 12px', borderRadius: '8px', color: 'rgba(255,255,255,0.6)' }}>{item}</span>
                  ))}
                </div>
                <button 
                  onClick={() => router.push('/analisis/calidad')}
                  style={{ width: '100%', padding: '16px', borderRadius: '16px', backgroundColor: 'rgba(249, 115, 22, 0.1)', border: '1px solid rgba(249, 115, 22, 0.2)', color: '#F97316', fontSize: '12px', fontWeight: '900', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '12px', cursor: 'pointer' }}
                  onMouseOver={(e) => e.currentTarget.style.backgroundColor = 'rgba(249, 115, 22, 0.2)'}
                  onMouseOut={(e) => e.currentTarget.style.backgroundColor = 'rgba(249, 115, 22, 0.1)'}
                >
                  <Camera size={18} /> VALIDACIÓN IA
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Bloque T+2 */}
        <div>
          <h2 style={{ fontSize: '13px', fontWeight: '900', color: 'rgba(255,255,255,0.3)', letterSpacing: '3px', textTransform: 'uppercase', marginBottom: '32px', display: 'flex', alignItems: 'center', gap: '12px' }}>
            <Clock size={16} /> Próximas 48h (T+2)
          </h2>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
            {t2Orders.map(order => (
              <div key={order.id} style={{ backgroundColor: 'rgba(255,255,255,0.01)', padding: '32px', borderRadius: '24px', border: '1px solid rgba(255,255,255,0.05)', opacity: 0.7 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
                  <div style={{ fontSize: '28px', fontWeight: '900', color: 'rgba(255,215,0,0.4)' }}>{order.time}</div>
                  {getStatusBadge(order.status)}
                </div>
                <div style={{ fontSize: '18px', fontWeight: '800', marginBottom: '12px' }}>{order.customer}</div>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                  {order.items.map(item => (
                    <span key={item} style={{ fontSize: '11px', backgroundColor: 'rgba(0,0,0,0.2)', padding: '6px 12px', borderRadius: '8px', color: 'rgba(255,255,255,0.4)' }}>{item}</span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* 3. Resumen de Preparación (Panel Inferior) */}
      <div style={{ 
        position: 'fixed', 
        bottom: 0, 
        left: 0, 
        width: '100%', 
        backgroundColor: 'rgba(20, 5, 5, 0.8)', 
        backdropFilter: 'blur(40px)',
        borderTop: '1px solid rgba(255,255,255,0.1)',
        zIndex: 100,
        transition: 'height 0.6s cubic-bezier(0.16, 1, 0.3, 1)',
        height: isIngredientsOpen ? '450px' : '80px',
        padding: '0 5%'
      }}>
        <div 
          onClick={() => setIsIngredientsOpen(!isIngredientsOpen)}
          style={{ height: '80px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', cursor: 'pointer' }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
            <Package color="#F97316" size={24} />
            <h3 style={{ fontSize: '16px', fontWeight: '900', letterSpacing: '2px', textTransform: 'uppercase', margin: 0 }}>Necesidades de Preparación (48h)</h3>
          </div>
          <div style={{ backgroundColor: 'rgba(255,255,255,0.1)', width: '32px', height: '32px', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            {isIngredientsOpen ? <ChevronDown size={20} /> : <ChevronUp size={20} />}
          </div>
        </div>

        <div style={{ padding: '20px 0 60px 0', display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: '20px' }}>
          {consolidatedIngredients.map(ing => (
            <div key={ing.name} style={{ backgroundColor: 'rgba(255,255,255,0.03)', padding: '24px', borderRadius: '20px', border: '1px solid rgba(255,255,255,0.1)' }}>
              <div style={{ fontSize: '10px', color: 'rgba(255,255,255,0.4)', fontWeight: '900', letterSpacing: '1px', marginBottom: '8px', textTransform: 'uppercase' }}>{ing.name}</div>
              <div style={{ fontSize: '24px', fontWeight: '900', color: '#F97316' }}>{ing.total}</div>
            </div>
          ))}
        </div>
      </div>

      <style jsx global>{`
        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        .animate-spin {
          animation: spin 1s linear infinite;
        }
      `}</style>
    </SubPageLayout>
  );
}
