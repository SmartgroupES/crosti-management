'use client';

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Loader2, Lock, User, ShieldCheck } from 'lucide-react';

export default function LoginPage() {
  const router = useRouter();
  const [login, setLogin] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [isExiting, setIsExiting] = useState(false);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    // Initial mount animation
    setIsVisible(true);
  }, []);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      // Simulate API call for auth
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify({ login, password }),
        headers: { 'Content-Type': 'application/json' }
      });

      const data = await res.json();
      if (data.success) {
        setIsExiting(true);
        setTimeout(() => {
          router.push('/');
        }, 800); // Smooth transition duration
      } else {
        setError(data.error || 'Credenciales incorrectas');
      }
    } catch (err) {
      setError('Error de conexión con el sistema');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{
      backgroundColor: '#801515', // Rojo Borgoña corporativo
      backgroundImage: 'radial-gradient(circle at center, #961a1a 0%, #801515 100%)',
      minHeight: '100vh',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      fontFamily: 'var(--font-outfit), "Outfit", system-ui, sans-serif',
      padding: '24px',
      transition: 'all 0.8s cubic-bezier(0.4, 0, 0.2, 1)',
      opacity: isExiting ? 0 : (isVisible ? 1 : 0),
      transform: isExiting ? 'scale(1.05)' : 'scale(1)',
      overflow: 'hidden'
    }}>
      {/* Background Decorative Elements */}
      <div style={{
        position: 'absolute',
        width: '100%',
        height: '100%',
        overflow: 'hidden',
        pointerEvents: 'none',
        opacity: 0.1
      }}>
        <div style={{
          position: 'absolute',
          top: '-10%',
          right: '-10%',
          width: '40%',
          height: '40%',
          borderRadius: '50%',
          background: 'white',
          filter: 'blur(100px)'
        }} />
        <div style={{
          position: 'absolute',
          bottom: '-10%',
          left: '-10%',
          width: '30%',
          height: '30%',
          borderRadius: '50%',
          background: 'black',
          filter: 'blur(80px)'
        }} />
      </div>

      <div style={{
        backgroundColor: '#FFFFFF',
        width: '100%',
        maxWidth: '440px',
        padding: '64px 48px',
        borderRadius: '56px', // Bordes muy redondeados
        boxShadow: '0 40px 80px rgba(0,0,0,0.35)',
        textAlign: 'center',
        position: 'relative',
        zIndex: 1,
        transition: 'all 0.6s cubic-bezier(0.34, 1.56, 0.64, 1)',
        transform: isVisible ? 'translateY(0)' : 'translateY(40px)',
        opacity: isVisible ? 1 : 0
      }}>
        <div style={{ marginBottom: '48px' }}>
          <div style={{ 
            display: 'inline-block',
            padding: '4px',
            borderRadius: '24px',
            background: 'linear-gradient(135deg, #f3f4f6 0%, #ffffff 100%)',
            boxShadow: '0 8px 16px rgba(0,0,0,0.05)',
            marginBottom: '32px'
          }}>
            <img 
              src="/logo-crosti.jpg" 
              alt="Crosti Logo" 
              style={{ 
                height: '88px', 
                borderRadius: '20px', 
                display: 'block'
              }} 
            />
          </div>
          
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '10px', marginBottom: '8px' }}>
            <ShieldCheck size={20} color="#801515" />
            <h1 style={{ 
              fontSize: '28px', 
              fontWeight: '900', 
              margin: '0', 
              color: '#111827', 
              letterSpacing: '-0.03em' 
            }}>
              Acceso Superadmin
            </h1>
          </div>
          <p style={{ color: '#6B7280', fontSize: '15px', fontWeight: '500' }}>
            Gestiona tu sistema Crosti Management
          </p>
        </div>

        <form onSubmit={handleLogin} style={{ display: 'flex', flexDirection: 'column', gap: '18px' }}>
          <div style={{ textAlign: 'left' }}>
            <label style={{ display: 'block', fontSize: '13px', fontWeight: '700', color: '#374151', marginBottom: '8px', marginLeft: '4px' }}>
              Usuario
            </label>
            <div style={{ position: 'relative' }}>
              <User size={18} strokeWidth={2.5} style={{ position: 'absolute', left: '20px', top: '50%', transform: 'translateY(-50%)', color: '#9CA3AF' }} />
              <input
                type="text"
                placeholder="Ingresa tu usuario"
                value={login}
                onChange={(e) => setLogin(e.target.value)}
                required
                style={{
                  width: '100%',
                  padding: '18px 18px 18px 52px',
                  fontSize: '15px',
                  borderRadius: '20px',
                  border: '2px solid #F3F4F6',
                  backgroundColor: '#F9FAFB',
                  boxSizing: 'border-box',
                  outline: 'none',
                  transition: 'all 0.3s ease',
                  fontWeight: '600',
                  color: '#111827'
                }}
                onFocus={(e) => {
                  e.currentTarget.style.borderColor = '#801515';
                  e.currentTarget.style.backgroundColor = '#FFFFFF';
                  e.currentTarget.style.boxShadow = '0 0 0 4px rgba(128, 21, 21, 0.08)';
                }}
                onBlur={(e) => {
                  e.currentTarget.style.borderColor = '#F3F4F6';
                  e.currentTarget.style.backgroundColor = '#F9FAFB';
                  e.currentTarget.style.boxShadow = 'none';
                }}
              />
            </div>
          </div>

          <div style={{ textAlign: 'left' }}>
            <label style={{ display: 'block', fontSize: '13px', fontWeight: '700', color: '#374151', marginBottom: '8px', marginLeft: '4px' }}>
              Contraseña
            </label>
            <div style={{ position: 'relative' }}>
              <Lock size={18} strokeWidth={2.5} style={{ position: 'absolute', left: '20px', top: '50%', transform: 'translateY(-50%)', color: '#9CA3AF' }} />
              <input
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                style={{
                  width: '100%',
                  padding: '18px 18px 18px 52px',
                  fontSize: '15px',
                  borderRadius: '20px',
                  border: '2px solid #F3F4F6',
                  backgroundColor: '#F9FAFB',
                  boxSizing: 'border-box',
                  outline: 'none',
                  transition: 'all 0.3s ease',
                  fontWeight: '600',
                  color: '#111827'
                }}
                onFocus={(e) => {
                  e.currentTarget.style.borderColor = '#801515';
                  e.currentTarget.style.backgroundColor = '#FFFFFF';
                  e.currentTarget.style.boxShadow = '0 0 0 4px rgba(128, 21, 21, 0.08)';
                }}
                onBlur={(e) => {
                  e.currentTarget.style.borderColor = '#F3F4F6';
                  e.currentTarget.style.backgroundColor = '#F9FAFB';
                  e.currentTarget.style.boxShadow = 'none';
                }}
              />
            </div>
          </div>

          {error && (
            <div style={{ 
              color: '#B91C1C', 
              fontSize: '13px', 
              fontWeight: '700', 
              backgroundColor: '#FEF2F2', 
              padding: '16px', 
              borderRadius: '16px',
              border: '1px solid #FEE2E2',
              marginTop: '8px'
            }}>
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading || isExiting}
            style={{
              width: '100%',
              padding: '20px',
              fontSize: '17px',
              fontWeight: '800',
              borderRadius: '22px',
              border: 'none',
              backgroundColor: '#801515', // Rojo Borgoña
              color: 'white',
              cursor: (loading || isExiting) ? 'not-allowed' : 'pointer',
              transition: 'all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275)',
              boxShadow: '0 12px 30px rgba(128, 21, 21, 0.3)',
              marginTop: '16px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '12px'
            }}
            onMouseOver={(e) => {
              if (!loading && !isExiting) {
                e.currentTarget.style.transform = 'translateY(-4px) scale(1.02)';
                e.currentTarget.style.boxShadow = '0 20px 40px rgba(128, 21, 21, 0.4)';
                e.currentTarget.style.backgroundColor = '#991B1B';
              }
            }}
            onMouseOut={(e) => {
              if (!loading && !isExiting) {
                e.currentTarget.style.transform = 'translateY(0) scale(1)';
                e.currentTarget.style.boxShadow = '0 12px 30px rgba(128, 21, 21, 0.3)';
                e.currentTarget.style.backgroundColor = '#801515';
              }
            }}
          >
            {loading ? <Loader2 className="animate-spin" size={22} /> : 'Entrar al Sistema'}
          </button>
        </form>

        <div style={{ 
          marginTop: '64px', 
          fontSize: '13px', 
          color: '#9CA3AF', 
          fontWeight: '600',
          letterSpacing: '0.01em'
        }}>
          &copy; 2026 Crosti Management
        </div>
      </div>

      {/* Decorative Footer Info */}
      <div style={{ 
        marginTop: '32px', 
        color: 'rgba(255,255,255,0.6)', 
        fontSize: '12px', 
        fontWeight: '500',
        display: 'flex',
        gap: '24px'
      }}>
        <span>Versión 2.0.4</span>
        <span>Soporte Técnico</span>
        <span>Privacidad</span>
      </div>

      <style jsx global>{`
        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        .animate-spin {
          animation: spin 1s linear infinite;
        }
        ::placeholder {
          color: #D1D5DB;
          font-weight: 500;
        }
      `}</style>
    </div>
  );
}
