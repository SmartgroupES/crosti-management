import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';

export const runtime = 'edge';


export async function POST(request: Request) {
  try {
    const { login, password } = await request.json();

    // SUPERADMIN CREDENTIALS
    if (login === 'NELSONCARRILLO' && password === '10334346') {
      const response = NextResponse.json({ success: true, user: 'Nelson Carrillo' });
      
      // Set auth cookie
      response.cookies.set('auth_token', 'session_active_superadmin', {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'lax',
        maxAge: 60 * 60 * 24 * 7, // 1 week
        path: '/',
      });

      // Set user cookie for the UI (not for security, just for display)
      response.cookies.set('user_name', 'Nelson Carrillo', {
        httpOnly: false,
        maxAge: 60 * 60 * 24 * 7,
        path: '/',
      });

      return response;
    }

    return NextResponse.json({ success: false, error: 'Credenciales inválidas' }, { status: 401 });
  } catch (error) {
    return NextResponse.json({ success: false, error: 'Error en el servidor' }, { status: 500 });
  }
}

export async function DELETE() {
  const response = NextResponse.json({ success: true });
  response.cookies.delete('auth_token');
  response.cookies.delete('user_name');
  return response;
}
