'use client';

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Loader2, Lock, User } from 'lucide-react';

export default function LoginPage() {
  const router = useRouter();
  const [login, setLogin] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify({ login, password }),
        headers: { 'Content-Type': 'application/json' }
      });

      const data = await res.json();
      if (data.success) {
        router.push('/');
      } else {
        setError(data.error || 'Acceso denegado');
      }
    } catch (err) {
      setError('Error al conectar con el servidor');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{
      backgroundColor: '#9B1B22', // Crosti Maroon
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontFamily: 'system-ui, -apple-system, sans-serif',
      padding: '20px'
    }}>
      <div style={{
        backgroundColor: 'white',
        width: '100%',
        maxWidth: '440px',
        padding: '60px 40px',
        borderRadius: '32px',
        boxShadow: '0 25px 50px -12px rgba(0,0,0,0.5)',
        textAlign: 'center'
      }}>
        <div style={{ marginBottom: '40px' }}>
          <img src="/logo-crosti.jpg" alt="Crosti Logo" style={{ height: '80px', borderRadius: '18px', marginBottom: '24px', boxShadow: '0 10px 20px rgba(0,0,0,0.1)' }} />
          <h1 style={{ fontSize: '28px', fontWeight: '900', margin: '0', color: '#1A1A1A', letterSpacing: '-0.5px' }}>Acceso Superadministrador</h1>
          <p style={{ fontSize: '15px', color: '#6B7280', marginTop: '8px', fontWeight: '500' }}>Introduce tus credenciales para continuar</p>
        </div>

        <form onSubmit={handleLogin} style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
          <div style={{ position: 'relative' }}>
            <User size={18} style={{ position: 'absolute', left: '16px', top: '50%', transform: 'translateY(-50%)', color: '#9CA3AF' }} />
            <input
              type="text"
              placeholder="Usuario"
              value={login}
              onChange={(e) => setLogin(e.target.value)}
              required
              style={{
                width: '100%',
                padding: '16px 16px 16px 48px',
                fontSize: '15px',
                borderRadius: '16px',
                border: '1px solid #E5E7EB',
                backgroundColor: '#F9FAFB',
                boxSizing: 'border-box',
                outline: 'none',
                transition: 'border-color 0.2s',
                fontWeight: '600'
              }}
            />
          </div>

          <div style={{ position: 'relative' }}>
            <Lock size={18} style={{ position: 'absolute', left: '16px', top: '50%', transform: 'translateY(-50%)', color: '#9CA3AF' }} />
            <input
              type="password"
              placeholder="Contraseña"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              style={{
                width: '100%',
                padding: '16px 16px 16px 48px',
                fontSize: '15px',
                borderRadius: '16px',
                border: '1px solid #E5E7EB',
                backgroundColor: '#F9FAFB',
                boxSizing: 'border-box',
                outline: 'none',
                transition: 'border-color 0.2s',
                fontWeight: '600'
              }}
            />
          </div>

          {error && (
            <div style={{ color: '#DC2626', fontSize: '13px', fontWeight: '700', backgroundColor: '#FEE2E2', padding: '12px', borderRadius: '12px' }}>
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            style={{
              width: '100%',
              padding: '18px',
              fontSize: '16px',
              fontWeight: '800',
              borderRadius: '16px',
              border: 'none',
              backgroundColor: '#9B1B22',
              color: 'white',
              cursor: loading ? 'not-allowed' : 'pointer',
              transition: 'all 0.2s',
              boxShadow: '0 10px 15px -3px rgba(155, 27, 34, 0.3)',
              marginTop: '10px'
            }}
          >
            {loading ? <Loader2 className="animate-spin" style={{ margin: '0 auto' }} /> : 'Entrar al Sistema'}
          </button>
        </form>

        <div style={{ marginTop: '40px', fontSize: '12px', color: '#9CA3AF', fontWeight: '600' }}>
          &copy; {new Date().getFullYear()} Crosti Management. Todos los derechos reservados.
        </div>
      </div>
    </div>
  );
}
