# Backup Log - Crosti Management

| Version | Date | Changes Summary | Archive Path |
| :--- | :--- | :--- | :--- |
| v1 | 2026-04-25 | Initial migration, Cloudflare Pages deployment fixed, Importer implemented, Logo added. | N/A (Initial state) |
| v2 | 2026-04-26 | Complete ERP transformation based on 13 reference images. Historical recipes integrated. Branding updated to Crosti Hub. Deployment successful. | ../crosti-management-v2-backup.tar.gz |
| v3 | 2026-04-29 | Intelligent Planning System (IPS) wizard, AI Vision UI, Profitability Engine (BCG Matrix, Marginal Contribution), and Schema expansion. Deployment successful. | ./backup_v3.zip |
