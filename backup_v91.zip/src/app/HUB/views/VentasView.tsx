'use client';

import React, { useState, useEffect } from 'react';
import { 
  TrendingUp, 
  Download, 
  AlertCircle,
  RefreshCw
} from 'lucide-react';

export default function VentasView() {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedWeek, setSelectedWeek] = useState<string>('');
  const [metric, setMetric] = useState<'quantity' | 'total'>('quantity');

  const fetchData = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/sales/hourly', { cache: 'no-store' });
      if (!res.ok) throw new Error(`Server Error: ${res.status}`);
      const json = await res.json();
      setData(json);
      
      if (json.heatmapData?.length > 0) {
        setSelectedWeek(json.heatmapData[0].week);
      }
    } catch (e: any) {
      console.error(e);
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  if (loading) return (
    <div style={{ padding: '100px', textAlign: 'center' }}>
      <RefreshCw size={48} color="#F97316" className="animate-spin" style={{ marginBottom: '20px' }} />
      <div style={{ fontWeight: '800', color: '#9CA3AF', letterSpacing: '1px' }}>SINCRONIZANDO CON LA BASE DE DATOS...</div>
    </div>
  );

  if (error) return (
    <div style={{ padding: '60px', textAlign: 'center', backgroundColor: '#FEF2F2', borderRadius: '32px', border: '1px solid #FEE2E2' }}>
      <AlertCircle size={48} color="#EF4444" style={{ marginBottom: '20px' }} />
      <div style={{ fontWeight: '900', color: '#B91C1C', fontSize: '18px' }}>ERROR DE CONEXIÓN</div>
      <p style={{ color: '#EF4444', marginTop: '8px', fontSize: '14px' }}>{error}</p>
      <button 
        onClick={fetchData}
        style={{ marginTop: '24px', padding: '12px 24px', backgroundColor: '#B91C1C', color: 'white', border: 'none', borderRadius: '12px', fontWeight: '900', cursor: 'pointer' }}
      >
        REINTENTAR AHORA
      </button>
    </div>
  );

  const kpis = [
    { label: 'VENTA HOY', val: data?.todaySales?.total || 0 },
    { label: 'SEMANA ACTUAL', val: data?.weekSales?.total || 0 },
    { label: 'MES EN CURSO', val: data?.monthSales?.total || 0 },
    { label: 'CIERRE ANUAL PROY.', val: (data?.monthSales?.total || 0) * 12 },
  ];

  // Logic for Heat Map
  const weeks = Array.from(new Set(data?.heatmapData?.map((d: any) => d.week) || [])) as string[];
  const days = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo'];
  const hours = ['09', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20'];

  const getHeatMapColor = (val: number, max: number) => {
    if (val === 0) return '#FFFFFF';
    const ratio = val / max;
    // High = Green (#86EFAC), Mid = Yellow (#FEF08A), Low = Red (#FCA5A5)
    if (ratio > 0.6) return '#86EFAC';
    if (ratio > 0.3) return '#FEF08A';
    return '#FCA5A5';
  };

  const weekData = data?.heatmapData?.filter((d: any) => d.week === selectedWeek) || [];
  const maxValue = Math.max(...weekData.map((d: any) => d[metric]), 1);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
      {/* 1. KPI Grid (Smaller Globos) */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '12px' }}>
        {kpis.map((kpi, idx) => (
          <div key={idx} style={{ 
            backgroundColor: '#F97316', color: 'white', padding: '16px 20px', borderRadius: '20px',
            boxShadow: '0 4px 10px rgba(249, 115, 22, 0.15)', position: 'relative', overflow: 'hidden'
          }}>
            <div style={{ fontSize: '9px', fontWeight: '900', opacity: 0.9, letterSpacing: '0.5px' }}>{kpi.label}</div>
            <div style={{ fontSize: '18px', fontWeight: '900', marginTop: '4px' }}>{Math.round(kpi.val).toLocaleString('es-ES')}€</div>
            <TrendingUp size={32} style={{ position: 'absolute', bottom: '-5px', right: '-5px', opacity: 0.15 }} />
          </div>
        ))}
      </div>

      {/* 2. Heat Map Section */}
      <div style={{ backgroundColor: 'white', borderRadius: '24px', border: '1px solid #E5E7EB', overflow: 'hidden' }}>
        <div style={{ padding: '16px 24px', borderBottom: '1px solid #F3F4F6', display: 'flex', justifyContent: 'space-between', alignItems: 'center', backgroundColor: '#FAF9F6' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '15px' }}>
            <h3 style={{ fontSize: '12px', fontWeight: '900', color: '#1A1A1A' }}>MAPA DE CALOR OPERATIVO</h3>
            <select 
              value={selectedWeek} 
              onChange={(e) => setSelectedWeek(e.target.value)}
              style={{ padding: '4px 12px', borderRadius: '8px', border: '1px solid #E5E7EB', fontSize: '11px', fontWeight: '800', outline: 'none' }}
            >
              {weeks.map(w => <option key={w} value={w}>SEMANA {w}</option>)}
            </select>
          </div>
          <div style={{ display: 'flex', backgroundColor: '#F3F4F6', padding: '3px', borderRadius: '10px' }}>
            <button 
              onClick={() => setMetric('quantity')}
              style={{ 
                padding: '4px 12px', borderRadius: '8px', fontSize: '10px', fontWeight: '900', border: 'none',
                backgroundColor: metric === 'quantity' ? 'white' : 'transparent',
                color: metric === 'quantity' ? '#801515' : '#9CA3AF',
                cursor: 'pointer', transition: 'all 0.2s'
              }}
            >
              CANTIDAD
            </button>
            <button 
              onClick={() => setMetric('total')}
              style={{ 
                padding: '4px 12px', borderRadius: '8px', fontSize: '10px', fontWeight: '900', border: 'none',
                backgroundColor: metric === 'total' ? 'white' : 'transparent',
                color: metric === 'total' ? '#801515' : '#9CA3AF',
                cursor: 'pointer', transition: 'all 0.2s'
              }}
            >
              VENTA TOTAL
            </button>
          </div>
        </div>

        <div style={{ overflowX: 'auto', padding: '10px' }}>
          <table style={{ width: '100%', borderCollapse: 'separate', borderSpacing: '2px' }}>
            <thead>
              <tr>
                <th style={{ width: '100px' }}></th>
                {hours.map(h => (
                  <th key={h} style={{ padding: '8px', fontSize: '10px', color: '#9CA3AF', fontWeight: '900', textAlign: 'center' }}>{h}:00</th>
                ))}
                <th style={{ padding: '8px', fontSize: '10px', color: '#1A1A1A', fontWeight: '900', textAlign: 'center' }}>TOTAL</th>
              </tr>
            </thead>
            <tbody>
              {days.map((dayName, dayIdx) => {
                const sqliteDay = dayIdx === 6 ? 0 : dayIdx + 1;
                const rowTotal = weekData.filter((d: any) => parseInt(d.day) === sqliteDay).reduce((acc: number, curr: any) => acc + curr[metric], 0);

                return (
                  <tr key={dayName}>
                    <td style={{ padding: '8px', fontSize: '11px', fontWeight: '900', color: '#4B5563' }}>{dayName}</td>
                    {hours.map(h => {
                      const cell = weekData.find((d: any) => parseInt(d.day) === sqliteDay && d.hour === h);
                      const val = cell ? cell[metric] : 0;
                      return (
                        <td key={h} style={{ 
                          padding: '10px', textAlign: 'center', fontSize: '11px', fontWeight: '900',
                          backgroundColor: getHeatMapColor(val, maxValue),
                          borderRadius: '4px', color: '#1A1A1A'
                        }}>
                          {Math.round(val)}
                        </td>
                      );
                    })}
                    <td style={{ padding: '10px', textAlign: 'center', fontSize: '11px', fontWeight: '900', color: '#1A1A1A', backgroundColor: '#F9FAFB' }}>
                      {Math.round(rowTotal)}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* 3. Main Stats Table */}
      <div style={{ backgroundColor: 'white', borderRadius: '24px', border: '1px solid #E5E7EB', overflow: 'hidden' }}>
        <div style={{ padding: '16px 24px', borderBottom: '1px solid #F3F4F6', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <h3 style={{ fontSize: '12px', fontWeight: '900' }}>DESGLOSE DE VENTAS MENSUALES</h3>
          <span style={{ fontSize: '8px', fontWeight: '900', color: '#10B981', backgroundColor: '#DCFCE7', padding: '2px 6px', borderRadius: '6px' }}>DATA_LIVE</span>
        </div>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ backgroundColor: '#F9FAFB', textAlign: 'left' }}>
              <th style={{ padding: '12px 24px', fontSize: '10px', color: '#9CA3AF', fontWeight: '900' }}>PERIODO</th>
              <th style={{ padding: '12px 24px', fontSize: '10px', color: '#9CA3AF', fontWeight: '900', textAlign: 'right' }}>VENTA TOTAL</th>
            </tr>
          </thead>
          <tbody>
            {data?.monthlyStats?.length > 0 ? data.monthlyStats.map((stat: any, idx: number) => (
              <tr key={idx} style={{ borderBottom: '1px solid #F3F4F6' }}>
                <td style={{ padding: '16px 24px', fontSize: '13px', fontWeight: '900' }}>{stat.month}</td>
                <td style={{ padding: '16px 24px', textAlign: 'right', fontSize: '13px', fontWeight: '900', color: '#F97316' }}>{Math.round(stat.sales).toLocaleString('es-ES')}€</td>
              </tr>
            )) : (
              <tr>
                <td colSpan={2} style={{ padding: '40px', textAlign: 'center', color: '#9CA3AF', fontWeight: '700' }}>No hay datos históricos.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
