import { NextRequest, NextResponse } from 'next/server';
import { getRequestContext } from '@cloudflare/next-on-pages';

export const runtime = 'edge';

export async function GET(req: NextRequest) {
  const { env } = getRequestContext();
  const DB = env.DB;
  if (!DB) return NextResponse.json({ error: "DB not found" }, { status: 500 });

  try {
    // 1. Get all sales aggregated by product (using sales_data)
    const salesPromise = DB.prepare(`
      SELECT 
        product_name, 
        SUM(quantity) as total_units, 
        SUM(total_sales) as total_revenue,
        AVG(total_sales / quantity) as avg_price
      FROM sales_data 
      GROUP BY product_name
    `).all();

    // 2. Calculate current costs per product from recipes
    const costsPromise = DB.prepare(`
      SELECT 
        p.name as product_name,
        SUM(r.quantity_needed * rm.average_cost_per_unit * (r.waste_factor || 1.0)) as total_cost
      FROM products p
      JOIN recipes r ON p.id = r.product_id
      JOIN raw_materials rm ON r.material_id = rm.id
      GROUP BY p.id
    `).all();

    // 3. Get fixed costs (Using a default if table is empty for demo)
    const fixedCostsPromise = DB.prepare(`
      SELECT SUM(amount) as total_fixed 
      FROM fixed_costs 
      WHERE recurrence = 'monthly'
    `).first();

    const [salesData, costsData, fixedCosts] = await Promise.all([
      salesPromise,
      costsPromise,
      fixedCostsPromise
    ]);

    const sales = salesData.results;
    const costs = costsData.results;
    const totalFixed = fixedCosts?.total_fixed || 3500; // Default demo fixed cost

    // 4. Calculate profitability per product
    const analysis = sales.map((sale: any) => {
      const costItem = costs.find((c: any) => c.product_name === sale.product_name);
      const unitCost = costItem?.total_cost || (sale.avg_price * 0.3); // Fallback to 30% cost
      const margin = sale.avg_price - unitCost;
      const totalMargin = margin * sale.total_units;

      return {
        name: sale.product_name,
        units: sale.total_units,
        revenue: sale.total_revenue,
        unitCost,
        unitMargin: margin,
        marginPercent: sale.avg_price > 0 ? (margin / sale.avg_price) * 100 : 0,
        totalContribution: totalMargin
      };
    });

    // 5. Global Metrics
    const totalRevenue = analysis.reduce((acc, curr) => acc + curr.revenue, 0);
    const totalContribution = analysis.reduce((acc, curr) => acc + curr.totalContribution, 0);
    
    // Recovery Impact Simulation (BakeOS Phase 4)
    const recoveredUnits = 120; // Mock units recovered in the last 30 days
    const avgMarginSaved = 1.45; // Margin saved per unit (Discounted price - COGS)
    const recoveryProfit = recoveredUnits * avgMarginSaved;

    const netProfit = totalContribution - totalFixed + recoveryProfit;
    const breakEven = totalRevenue > 0 ? (totalFixed / (totalContribution / totalRevenue)) : 0;

    return NextResponse.json({
      products: analysis,
      summary: {
        totalRevenue,
        totalContribution,
        totalFixed,
        recoveryProfit, // Revenue saved from waste
        netProfit,
        breakEven
      }
    });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
