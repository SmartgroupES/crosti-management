import { NextRequest, NextResponse } from 'next/server';
import { getRequestContext } from '@cloudflare/next-on-pages';

export const runtime = 'edge';

export async function GET(req: NextRequest) {
  const { env } = getRequestContext();
  const DB = env.DB;
  
  if (!DB) return NextResponse.json({ error: "DB not found" }, { status: 500 });

  try {
    // 1. Advanced Monthly Stats (Last 4 months for growth calc)
    const monthlyStats = await DB.prepare(`
      SELECT 
        strftime('%m', sale_date) as month_num,
        SUM(total_amount) as sales,
        AVG(total_amount) as avg_ticket,
        COUNT(*) as transactions
      FROM sales
      WHERE sale_date >= date('now', '-4 months')
      GROUP BY month_num
      ORDER BY month_num ASC
    `).all();

    const monthNames = ['ENE', 'FEB', 'MAR', 'ABR', 'MAY', 'JUN', 'JUL', 'AGO', 'SEP', 'OCT', 'NOV', 'DIC'];
    const formattedMonthly = monthlyStats.results.map((r: any, idx: number, arr: any[]) => {
      const prevSales = idx > 0 ? arr[idx - 1].sales : 0;
      const growth = prevSales > 0 ? ((r.sales - prevSales) / prevSales) * 100 : 0;
      return {
        month: monthNames[parseInt(r.month_num) - 1],
        sales: r.sales,
        avgTicket: r.avg_ticket,
        growth: growth.toFixed(1)
      };
    }).slice(-3); // Only last 3 months as requested

    // 2. Global KPIs
    const todaySales = await DB.prepare(`SELECT SUM(total_amount) as total FROM sales WHERE date(sale_date) = date('now')`).first();
    const weekSales = await DB.prepare(`SELECT SUM(total_amount) as total FROM sales WHERE date(sale_date) >= date('now', '-7 days')`).first();
    const monthSales = await DB.prepare(`SELECT SUM(total_amount) as total FROM sales WHERE strftime('%Y-%m', sale_date) = strftime('%Y-%m', 'now')`).first();
    const projectionData = await DB.prepare(`
      SELECT AVG(daily_total) as avg_daily FROM (
        SELECT date(sale_date) as d, SUM(total_amount) as daily_total 
        FROM sales 
        WHERE date(sale_date) >= date('now', '-30 days')
        GROUP BY d
      )
    `).first();
    const projectedAnnual = (projectionData?.avg_daily || 0) * 365;

    // 3. Top 5 Products
    const topProducts = await DB.prepare(`
      SELECT product_name as name, SUM(total_amount) as amount
      FROM sales
      GROUP BY product_name
      ORDER BY amount DESC
      LIMIT 5
    `).all();

    const maxProductSales = topProducts.results.length > 0 ? (topProducts.results[0] as any).amount : 1;
    const formattedTopProducts = topProducts.results.map((p: any) => ({
      ...p,
      percent: Math.round((p.amount / maxProductSales) * 100),
      amount: `${Math.round(p.amount).toLocaleString()}€`
    }));

    // 4. Daily Sales for Export (Last 90 days)
    const daily90 = await DB.prepare(`
      SELECT 
        date(sale_date) as date,
        SUM(total_amount) as sales,
        COUNT(*) as transactions
      FROM sales
      WHERE sale_date >= date('now', '-90 days')
      GROUP BY date
      ORDER BY date DESC
    `).all();

    return NextResponse.json({
      monthly: formattedMonthly,
      kpis: {
        today: todaySales?.total || 0,
        week: weekSales?.total || 0,
        month: monthSales?.total || 0,
        projectedAnnual: projectedAnnual
      },
      topProducts: formattedTopProducts,
      exportData: daily90.results
    });

  } catch (e: any) {
    console.error("Sales Stats Error:", e);
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
