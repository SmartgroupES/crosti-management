'use client';

import React, { useState, useEffect, useRef } from 'react';
import SubPageLayout from '@/components/SubPageLayout';
import { TrendingUp, Zap, Clock, DollarSign, ShoppingCart, Loader2, Upload, BarChart3 } from 'lucide-react';

interface SalesStats {
  hourly: { hour: number; total_amount: number; total_items: number }[];
  kpis: {
    totalRevenue: number;
    totalUnits: number;
    totalTransactions: number;
    avgTicket: number;
  };
  weekly: { week: string; revenue: number }[];
  topProducts: { product_name: string; units: number; revenue: number }[];
  recentTransactions: { id: number; sale_date: string; product_name: string; quantity: number; total_amount: number; location: string }[];
  heatmap: { day_of_week: number; hour: number; total_sales: number }[];
  error?: string;
}

export default function VentasPage() {
  const [data, setData] = useState<SalesStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const fetchData = () => {
    setLoading(true);
    setError(null);
    fetch('/api/sales/hourly')
      .then(res => res.json())
      .then(d => {
        if (d.error) setError(d.error);
        else setData(d);
        setLoading(false);
      })
      .catch(err => {
        console.error("Error loading sales stats:", err);
        setError("Fallo al conectar con el servidor");
        setLoading(false);
      });
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    const formData = new FormData();
    formData.append('file', file);

    try {
      const res = await fetch('/api/sales/upload', {
        method: 'POST',
        body: formData,
      });
      const result = await res.json();
      if (result.success) {
        fetchData();
      } else {
        alert(result.error);
      }
    } catch (err) {
      alert("Error al subir el archivo");
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  if (loading) {
    return (
      <SubPageLayout title="Seguimiento de Ventas">
        <div style={{ height: '50vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: '24px' }}>
          <Loader2 className="animate-spin" size={48} color="#F97316" />
          <p style={{ color: 'rgba(255,255,255,0.6)', fontWeight: '600', fontSize: '18px' }}>Sincronizando datos de Crosti...</p>
        </div>
      </SubPageLayout>
    );
  }

  const kpis = [
    { label: 'Ingresos Totales', value: `${(data?.kpis?.totalRevenue || 0).toLocaleString('de-DE', { minimumFractionDigits: 2 })}€`, icon: <TrendingUp size={20} />, color: '#10B981' },
    { label: 'Ticket Medio', value: `${(data?.kpis?.avgTicket || 0).toFixed(2)}€`, icon: <DollarSign size={20} />, color: '#F97316' },
    { label: 'Unidades', value: (data?.kpis?.totalUnits || 0).toLocaleString(), icon: <ShoppingCart size={20} />, color: '#3B82F6' },
    { label: 'Hora Punta', value: data?.hourly?.length ? `${data.hourly.reduce((max, curr) => curr.total_amount > max.total_amount ? curr : max).hour}:00` : '--', icon: <Clock size={20} />, color: '#8B5CF6' },
  ];

  return (
    <SubPageLayout title="Seguimiento de Ventas">
      {/* Top Actions */}
      <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '12px', marginBottom: '32px' }}>
        <input type="file" ref={fileInputRef} onChange={handleFileUpload} accept=".xlsx,.xls" style={{ display: 'none' }} />
        <button 
          onClick={() => fileInputRef.current?.click()}
          disabled={uploading}
          style={{ 
            backgroundColor: 'rgba(255,255,255,0.1)', 
            color: 'white', 
            border: '1px solid rgba(255,255,255,0.1)', 
            padding: '12px 20px', 
            borderRadius: '12px', 
            fontSize: '13px', 
            fontWeight: '700', 
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            gap: '8px',
            transition: 'all 0.2s'
          }}>
          {uploading ? <Loader2 className="animate-spin" size={16} /> : <Upload size={16} />}
          Importar Excel
        </button>
      </div>

      {/* KPI Section */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '24px', marginBottom: '40px' }}>
        {kpis.map((kpi, i) => (
          <div key={i} style={{ 
            backgroundColor: 'rgba(0, 0, 0, 0.3)', 
            padding: '32px', 
            borderRadius: '24px', 
            border: '1px solid rgba(255, 255, 255, 0.05)',
            backdropFilter: 'blur(10px)'
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '16px' }}>
              <div style={{ padding: '10px', borderRadius: '12px', backgroundColor: `${kpi.color}20`, color: kpi.color }}>{kpi.icon}</div>
              <span style={{ fontSize: '11px', fontWeight: '800', color: 'rgba(255,255,255,0.4)', textTransform: 'uppercase', letterSpacing: '1px' }}>{kpi.label}</span>
            </div>
            <div style={{ fontSize: '32px', fontWeight: '900', color: 'white' }}>{kpi.value}</div>
          </div>
        ))}
      </div>

      {/* Charts Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 340px', gap: '32px', marginBottom: '40px' }}>
        {/* Main Chart */}
        <div style={{ 
          backgroundColor: 'rgba(0, 0, 0, 0.3)', 
          padding: '40px', 
          borderRadius: '32px', 
          border: '1px solid rgba(255, 255, 255, 0.05)',
          backdropFilter: 'blur(10px)'
        }}>
          <h2 style={{ fontSize: '20px', fontWeight: '800', marginBottom: '40px' }}>Rendimiento Horario</h2>
          <div style={{ height: '300px', display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', gap: '8px' }}>
            {data?.hourly?.map((bar, i) => {
              const max = Math.max(...data.hourly.map(h => h.total_amount));
              return (
                <div key={i} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '12px' }}>
                  <div style={{ 
                    width: '100%', 
                    height: `${(bar.total_amount / max) * 240}px`, 
                    backgroundColor: bar.total_amount === max ? '#F97316' : 'rgba(249, 115, 22, 0.4)', 
                    borderRadius: '8px 8px 4px 4px',
                    transition: 'all 0.5s'
                  }} />
                  <span style={{ fontSize: '11px', color: 'rgba(255,255,255,0.4)', fontWeight: '700' }}>{bar.hour}h</span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Top Ranking */}
        <div style={{ 
          backgroundColor: 'rgba(0, 0, 0, 0.3)', 
          padding: '40px', 
          borderRadius: '32px', 
          border: '1px solid rgba(255, 255, 255, 0.05)',
          backdropFilter: 'blur(10px)'
        }}>
          <h2 style={{ fontSize: '18px', fontWeight: '800', marginBottom: '32px', display: 'flex', alignItems: 'center', gap: '10px' }}>
            <BarChart3 size={20} color="#F97316" /> Top Productos
          </h2>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
            {data?.topProducts?.map((p, i) => (
              <div key={i} style={{ 
                display: 'flex', 
                alignItems: 'center', 
                gap: '12px', 
                padding: '16px', 
                backgroundColor: 'rgba(255,255,255,0.03)', 
                borderRadius: '16px',
                border: '1px solid rgba(255,255,255,0.05)'
              }}>
                <div style={{ fontSize: '14px', fontWeight: '900', color: '#F97316' }}>#{i + 1}</div>
                <div style={{ flex: 1, overflow: 'hidden' }}>
                  <div style={{ fontSize: '13px', fontWeight: '700', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{p.product_name}</div>
                  <div style={{ fontSize: '11px', color: 'rgba(255,255,255,0.4)' }}>{p.units} uds.</div>
                </div>
                <div style={{ fontSize: '14px', fontWeight: '800' }}>{Math.round(p.revenue)}€</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </SubPageLayout>
  );
}
