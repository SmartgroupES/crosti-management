'use client';

import { useState } from 'react';

export const runtime = 'edge';

export default function ImportPage() {
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');

  const handleUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!file) return;

    setLoading(true);
    setMessage('');

    const formData = new FormData();
    formData.append('file', file);

    try {
      const res = await fetch('/api/sales/upload', {
        method: 'POST',
        body: formData,
      });

      const data = await res.json();
      if (data.success) {
        setMessage(`✅ Éxito: Se han importado ${data.count} registros.`);
      } else {
        setMessage(`❌ Error: ${data.error}`);
      }
    } catch (err) {
      setMessage('❌ Error de conexión con el servidor.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ padding: '50px', textAlign: 'center', fontFamily: 'sans-serif' }}>
      <h1 style={{ color: '#3E2723' }}>🍪 IMPORTADOR DE VENTAS</h1>
      <p>Sube tu archivo Excel (.xlsx) para actualizar la base de datos.</p>
      
      <form onSubmit={handleUpload} style={{ marginTop: '30px', border: '1px solid #ccc', padding: '20px', borderRadius: '10px', display: 'inline-block' }}>
        <input 
          type="file" 
          accept=".xlsx" 
          onChange={(e) => setFile(e.target.files?.[0] || null)}
          style={{ marginBottom: '20px' }}
        />
        <br />
        <button 
          type="submit" 
          disabled={!file || loading}
          style={{ 
            backgroundColor: loading ? '#ccc' : '#3E2723', 
            color: 'white', 
            padding: '10px 20px', 
            border: 'none', 
            borderRadius: '5px',
            cursor: loading ? 'default' : 'pointer'
          }}
        >
          {loading ? 'Subiendo...' : 'Importar Excel'}
        </button>
      </form>

      {message && <p style={{ marginTop: '20px', fontWeight: 'bold' }}>{message}</p>}

      <div style={{ marginTop: '40px' }}>
        <a href="/" style={{ color: '#3E2723', textDecoration: 'underline' }}>Volver al Inicio</a>
      </div>
    </div>
  );
}
