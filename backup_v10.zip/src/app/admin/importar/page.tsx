'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { Upload, Database, LayoutDashboard, Settings, FileSpreadsheet, Clock, Cloud, ChevronRight, Trash2, AlertCircle, DollarSign, Layers } from 'lucide-react';

export default function AdminPage() {
  const [activeTab, setActiveTab] = useState('Cargar Datos');
  const [isDeleting, setIsDeleting] = useState(false);
  const [isCleaningRecipes, setIsCleaningRecipes] = useState(false);

  const kpis = [
    { label: '40', sublabel: 'SEMANAS CARGADAS', color: '#EF4444' },
    { label: '718', sublabel: 'PRODUCTOS', color: '#F97316' },
    { label: '20/4/2026', sublabel: 'ÚLTIMA ACTUALIZACIÓN', color: '#F97316' },
    { label: 'NUBE', sublabel: 'MODO DATOS', color: '#10B981' },
  ];

  const tabs = [
    { name: 'Cargar Datos', icon: <Upload size={14} /> },
    { name: 'Inventarios', icon: <Database size={14} /> },
    { name: 'Migración Inicial', icon: <Clock size={14} /> },
    { name: 'Gestionar', icon: <Settings size={14} /> },
  ];

  const handleClearSales = async () => {
    if (!confirm('¿Estás seguro de que deseas eliminar TODOS los datos de ventas por hora? Esta acción no se puede deshacer.')) {
      return;
    }

    setIsDeleting(true);
    try {
      const response = await fetch('/api/sales/clear', { method: 'POST' });
      const result = await response.json();
      if (result.success) {
        alert('Datos eliminados correctamente');
      } else {
        alert('Error: ' + result.error);
      }
    } catch (error) {
      console.error('Error clearing sales:', error);
      alert('Error al conectar con el servidor');
    } finally {
      setIsDeleting(false);
    }
  };

  const handleCleanupRecipes = async () => {
    if (!confirm('¿Estás seguro de que deseas eliminar todas las recetas que NO sean galletas o cookies? Esta acción es irreversible.')) {
      return;
    }

    setIsCleaningRecipes(true);
    try {
      const response = await fetch('/api/recetas/cleanup', { method: 'POST' });
      const result = await response.json();
      if (result.success) {
        alert(result.message + ' (Eliminadas: ' + result.deletedCount + ')');
      } else {
        alert('Error: ' + result.error);
      }
    } catch (error) {
      console.error('Error cleaning recipes:', error);
      alert('Error al conectar con el servidor');
    } finally {
      setIsCleaningRecipes(false);
    }
  };

  return (
    <div style={{ backgroundColor: '#1A1A1A', minHeight: '100vh', fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif' }}>
      {/* Header */}
      <header style={{ padding: '20px 40px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid #333' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '20px' }}>
          <a href="https://www.instagram.com/crosticookies?igsh=dHd0dWQ5aWVrdWM5" target="_blank" rel="noopener noreferrer">
            <img src="/logo-crosti.jpg" alt="Crosti Logo" style={{ height: '40px', borderRadius: '8px', cursor: 'pointer' }} />
          </a>
          <span style={{ color: 'white', fontWeight: 'bold', fontSize: '18px', letterSpacing: '1px' }}>ADMIN</span>
        </div>
        <Link href="/" style={{ color: '#9CA3AF', fontSize: '12px', fontWeight: 'bold', display: 'flex', alignItems: 'center', gap: '6px', textDecoration: 'none' }}>
           ← Volver al Dashboard
        </Link>
      </header>

      <main style={{ padding: '40px' }}>
        {/* KPI Row */}
        <div style={{ display: 'flex', justifyContent: 'center', gap: '60px', marginBottom: '40px' }}>
          {kpis.map((kpi, idx) => (
            <div key={idx} style={{ textAlign: 'center' }}>
              <div style={{ fontSize: '28px', fontWeight: 'bold', color: kpi.color, marginBottom: '4px' }}>{kpi.label}</div>
              <div style={{ fontSize: '10px', fontWeight: 'bold', color: '#6B7280', letterSpacing: '0.5px' }}>{kpi.sublabel}</div>
            </div>
          ))}
        </div>

        {/* Tabs */}
        <div style={{ display: 'flex', justifyContent: 'center', gap: '10px', marginBottom: '40px' }}>
          <div style={{ backgroundColor: 'white', padding: '6px', borderRadius: '14px', display: 'flex', gap: '4px' }}>
            {tabs.map(tab => (
              <button
                key={tab.name}
                onClick={() => setActiveTab(tab.name)}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  padding: '10px 20px',
                  borderRadius: '10px',
                  fontSize: '12px',
                  fontWeight: 'bold',
                  border: 'none',
                  backgroundColor: activeTab === tab.name ? '#FAF9F6' : 'transparent',
                  color: activeTab === tab.name ? '#EF4444' : '#6B7280',
                  boxShadow: activeTab === tab.name ? 'inset 0 2px 4px 0 rgba(0,0,0,0.06)' : 'none',
                  cursor: 'pointer'
                }}
              >
                {tab.icon}
                {tab.name}
              </button>
            ))}
          </div>
        </div>

        {/* Tab Content */}
        <div style={{ maxWidth: '800px', margin: '0 auto', width: '100%' }}>
          {activeTab === 'Cargar Datos' && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
              {/* Merma Card */}
              <div style={{ backgroundColor: 'white', borderRadius: '24px', padding: '30px', border: '1px solid #E5E7EB' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '10px' }}>
                   <FileSpreadsheet size={20} color="#6B7280" />
                   <h3 style={{ fontSize: '16px', fontWeight: 'bold', margin: 0 }}>Reporte de Merma</h3>
                   <span style={{ backgroundColor: '#F0FDF4', color: '#166534', padding: '2px 8px', borderRadius: '4px', fontSize: '10px', fontWeight: 'bold' }}>DIARIO</span>
                </div>
                <p style={{ fontSize: '12px', color: '#9CA3AF', marginBottom: '20px' }}>Sube el archivo de merma diaria descargado de la intranet Prigo. Se acumulará a los datos históricos de merma.</p>
                
                <div style={{ 
                  border: '2px dashed #E5E7EB', 
                  borderRadius: '16px', 
                  padding: '40px', 
                  textAlign: 'center',
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  justifyContent: 'center',
                  cursor: 'pointer',
                  marginBottom: '20px'
                }}>
                   <Cloud size={32} color="#93C5FD" style={{ marginBottom: '10px' }} />
                   <div style={{ fontSize: '13px', color: '#666', fontWeight: '500' }}>Arrastra aquí o haz clic para seleccionar</div>
                   <div style={{ fontSize: '11px', color: '#9CA3AF', marginTop: '4px' }}>Merma_YYYYMMDD.xlsx o ReporteMermaDiaria_FECHA.xlsx</div>
                </div>
                <button style={{ backgroundColor: '#F97316', color: 'white', opacity: 0.5, border: 'none', padding: '12px 24px', borderRadius: '12px', fontSize: '12px', fontWeight: 'bold', cursor: 'default' }}>
                  Procesar y Subir
                </button>
              </div>

              {/* Sales Card */}
              <div style={{ backgroundColor: 'white', borderRadius: '24px', padding: '30px', border: '1px solid #E5E7EB' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '10px' }}>
                   <Clock size={20} color="#6B7280" />
                   <h3 style={{ fontSize: '16px', fontWeight: 'bold', margin: 0 }}>Ventas por Hora</h3>
                   <span style={{ backgroundColor: '#F0FDF4', color: '#166534', padding: '2px 8px', borderRadius: '4px', fontSize: '10px', fontWeight: 'bold' }}>DIARIO</span>
                </div>
                <p style={{ fontSize: '12px', color: '#9CA3AF', marginBottom: '20px' }}>Sube el archivo de ventas por hora descargado de Oracle (formato EKE). Se procesan automáticamente todas las tiendas y horas.</p>
                
                <div style={{ 
                  border: '2px dashed #E5E7EB', 
                  borderRadius: '16px', 
                  padding: '40px', 
                  textAlign: 'center',
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  justifyContent: 'center',
                  cursor: 'pointer',
                  marginBottom: '20px'
                }}>
                   <Clock size={32} color="#9CA3AF" style={{ marginBottom: '10px' }} />
                   <div style={{ fontSize: '13px', color: '#666', fontWeight: '500' }}>Arrastra aquí o haz clic para seleccionar</div>
                   <div style={{ fontSize: '11px', color: '#9CA3AF', marginTop: '4px' }}>Ventas por hora EKE XXXXXX.xlsx</div>
                </div>
                <div style={{ display: 'flex', gap: '12px' }}>
                  <button style={{ backgroundColor: '#F97316', color: 'white', opacity: 0.5, border: 'none', padding: '12px 24px', borderRadius: '12px', fontSize: '12px', fontWeight: 'bold', cursor: 'default' }}>
                    Procesar y Subir
                  </button>
                  <button 
                    onClick={handleClearSales}
                    disabled={isDeleting}
                    style={{ 
                      backgroundColor: '#FEF2F2', 
                      color: '#EF4444', 
                      border: '1px solid #FCA5A5', 
                      padding: '12px 24px', 
                      borderRadius: '12px', 
                      fontSize: '12px', 
                      fontWeight: 'bold', 
                      cursor: isDeleting ? 'not-allowed' : 'pointer',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '8px',
                      transition: 'all 0.2s'
                    }}
                  >
                    <Trash2 size={14} />
                    {isDeleting ? 'Eliminando...' : 'Eliminar Datos'}
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'Gestionar' && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
              <div style={{ backgroundColor: 'white', borderRadius: '24px', padding: '30px', border: '1px solid #E5E7EB' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '10px' }}>
                   <Settings size={20} color="#6B7280" />
                   <h3 style={{ fontSize: '16px', fontWeight: 'bold', margin: 0 }}>Gestión Estratégica</h3>
                </div>
                <p style={{ fontSize: '12px', color: '#9CA3AF', marginBottom: '20px' }}>Herramientas para la optimización financiera y operativa de Crosti.</p>
                
                <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                  <div style={{ backgroundColor: '#F9FAFB', padding: '20px', borderRadius: '16px', border: '1px solid #F3F4F6' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <div>
                        <div style={{ fontSize: '14px', fontWeight: 'bold', color: '#1A1A1A' }}>Categorización de Portafolio</div>
                        <div style={{ fontSize: '12px', color: '#6B7280', marginTop: '4px' }}>Organiza tus galletas en familias técnicas para habilitar el análisis de rentabilidad.</div>
                      </div>
                      <Link href="/admin/categorias" style={{ 
                        backgroundColor: '#1A1A1A', 
                        color: 'white', 
                        padding: '10px 20px', 
                        borderRadius: '10px', 
                        fontSize: '12px', 
                        fontWeight: 'bold', 
                        textDecoration: 'none',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '8px'
                      }}>
                        <Layers size={14} />
                        Gestionar Familias
                      </Link>
                    </div>
                  </div>

                  <div style={{ backgroundColor: '#F9FAFB', padding: '20px', borderRadius: '16px', border: '1px solid #F3F4F6' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <div>
                        <div style={{ fontSize: '14px', fontWeight: 'bold', color: '#1A1A1A' }}>Gestión de Almacén (Insumos)</div>
                        <div style={{ fontSize: '12px', color: '#6B7280', marginTop: '4px' }}>Controla el inventario de materia prima, costos de compra y alertas de stock bajo.</div>
                      </div>
                      <Link href="/admin/almacen" style={{ 
                        backgroundColor: '#10B981', 
                        color: 'white', 
                        padding: '10px 20px', 
                        borderRadius: '10px', 
                        fontSize: '12px', 
                        fontWeight: 'bold', 
                        textDecoration: 'none',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '8px'
                      }}>
                        <Package size={14} />
                        Gestionar Almacén
                      </Link>
                    </div>
                  </div>

                  <div style={{ backgroundColor: '#F9FAFB', padding: '20px', borderRadius: '16px', border: '1px solid #F3F4F6' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <div>
                        <div style={{ fontSize: '14px', fontWeight: 'bold', color: '#1A1A1A' }}>Gestión de Personal y Horarios</div>
                        <div style={{ fontSize: '12px', color: '#6B7280', marginTop: '4px' }}>Administra tu equipo, asigna turnos y controla el costo laboral dinámico.</div>
                      </div>
                      <Link href="/admin/personal" style={{ 
                        backgroundColor: '#6366F1', 
                        color: 'white', 
                        padding: '10px 20px', 
                        borderRadius: '10px', 
                        fontSize: '12px', 
                        fontWeight: 'bold', 
                        textDecoration: 'none',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '8px'
                      }}>
                        <Users size={14} />
                        Gestionar Personal
                      </Link>
                    </div>
                  </div>

                  <div style={{ backgroundColor: '#F9FAFB', padding: '20px', borderRadius: '16px', border: '1px solid #F3F4F6' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <div>
                        <div style={{ fontSize: '14px', fontWeight: 'bold', color: '#1A1A1A' }}>Configuración de Costos Fijos</div>
                        <div style={{ fontSize: '12px', color: '#6B7280', marginTop: '4px' }}>Gestiona los gastos mensuales de alquiler, suministros y otros costos indirectos.</div>
                      </div>
                      <Link href="/admin/configuracion" style={{ 
                        backgroundColor: '#F97316', 
                        color: 'white', 
                        padding: '10px 20px', 
                        borderRadius: '10px', 
                        fontSize: '12px', 
                        fontWeight: 'bold', 
                        textDecoration: 'none',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '8px'
                      }}>
                        <DollarSign size={14} />
                        Gestionar Costos
                      </Link>
                    </div>
                  </div>

                  <div style={{ backgroundColor: '#F9FAFB', padding: '20px', borderRadius: '16px', border: '1px solid #F3F4F6' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <div>
                        <div style={{ fontSize: '14px', fontWeight: 'bold', color: '#1A1A1A' }}>Limpieza de Recetas (Solo Galletas)</div>
                        <div style={{ fontSize: '12px', color: '#6B7280', marginTop: '4px' }}>Elimina permanentemente todas las recetas que no sean galletas o cookies.</div>
                      </div>
                      <button 
                        onClick={handleCleanupRecipes}
                        disabled={isCleaningRecipes}
                        style={{ 
                          backgroundColor: '#1A1A1A', 
                          color: 'white', 
                          padding: '10px 20px', 
                          borderRadius: '10px', 
                          fontSize: '12px', 
                          fontWeight: 'bold', 
                          cursor: isCleaningRecipes ? 'not-allowed' : 'pointer',
                          display: 'flex',
                          alignItems: 'center',
                          gap: '8px'
                        }}
                      >
                        <Trash2 size={14} />
                        {isCleaningRecipes ? 'Limpiando...' : 'Ejecutar Limpieza'}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {(activeTab === 'Inventarios' || activeTab === 'Migración Inicial') && (
            <div style={{ backgroundColor: 'white', borderRadius: '24px', padding: '60px', border: '1px solid #E5E7EB', textAlign: 'center' }}>
              <Settings size={48} color="#E5E7EB" style={{ marginBottom: '20px' }} />
              <div style={{ fontSize: '16px', fontWeight: 'bold', color: '#1A1A1A' }}>Módulo en Construcción</div>
              <div style={{ fontSize: '14px', color: '#9CA3AF', marginTop: '8px' }}>Esta funcionalidad estará disponible próximamente.</div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
