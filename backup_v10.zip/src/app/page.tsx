'use client';

import React from 'react';
import Link from 'next/link';
import { BookOpen, Clock, Settings, LogOut, Zap, TrendingUp } from 'lucide-react';

export default function Dashboard() {

  return (
    <div style={{
      backgroundColor: '#FAF9F6',
      minHeight: '100vh',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      padding: '60px 20px',
      fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif',
      color: '#1A1A1A'
    }}>
      <div style={{ textAlign: 'center', marginBottom: '40px' }}>
        <a href="https://www.instagram.com/crosticookies?igsh=dHd0dWQ5aWVrdWM5" target="_blank" rel="noopener noreferrer">
          <img src="/logo-crosti.jpg" alt="Crosti Logo" style={{ height: '80px', borderRadius: '16px', marginBottom: '20px', cursor: 'pointer' }} />
        </a>
        <h1 style={{ fontSize: '32px', fontWeight: 'bold', margin: '0 0 10px 0' }}>Crosti Hub</h1>
        <p style={{ fontSize: '16px', color: '#666', margin: 0 }}>Sistema de Gestión Operativa</p>
      </div>

      <div style={{
        display: 'inline-block',
        backgroundColor: '#1A1A1A',
        color: 'white',
        padding: '4px 16px',
        borderRadius: '20px',
        fontSize: '12px',
        fontWeight: 'bold',
        textTransform: 'uppercase',
        marginBottom: '40px'
      }}>
        Dirección
      </div>

      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
        gap: '24px',
        width: '100%',
        maxWidth: '1000px'
      }}>
        {/* Planificación Inteligente Tile */}
        <Link href="/planificacion" style={{ textDecoration: 'none' }}>
          <div style={{
            backgroundColor: 'white',
            padding: '40px',
            borderRadius: '24px',
            border: '1px solid #E5E7EB',
            textAlign: 'center',
            cursor: 'pointer',
            transition: 'transform 0.2s, box-shadow 0.2s'
          }}
          onMouseOver={(e) => { e.currentTarget.style.transform = 'translateY(-4px)'; e.currentTarget.style.boxShadow = '0 10px 25px -5px rgba(0, 0, 0, 0.1)'; }}
          onMouseOut={(e) => { e.currentTarget.style.transform = 'translateY(0)'; e.currentTarget.style.boxShadow = 'none'; }}
          >
            <div style={{ backgroundColor: '#FEE2E2', width: '64px', height: '64px', borderRadius: '16px', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 20px auto' }}>
              <Zap size={32} color="#EF4444" />
            </div>
            <h3 style={{ fontSize: '20px', fontWeight: 'bold', marginBottom: '8px', color: '#1A1A1A' }}>Planificación</h3>
            <p style={{ fontSize: '14px', color: '#666', margin: 0 }}>Gestión inteligente de producción basada en ventas y AI Vision.</p>
          </div>
        </Link>

        {/* Rentabilidad Tile */}
        <Link href="/analisis/rentabilidad" style={{ textDecoration: 'none' }}>
          <div style={{
            backgroundColor: 'white',
            padding: '40px',
            borderRadius: '24px',
            border: '1px solid #E5E7EB',
            textAlign: 'center',
            cursor: 'pointer',
            transition: 'transform 0.2s, box-shadow 0.2s'
          }}
          onMouseOver={(e) => { e.currentTarget.style.transform = 'translateY(-4px)'; e.currentTarget.style.boxShadow = '0 10px 25px -5px rgba(0, 0, 0, 0.1)'; }}
          onMouseOut={(e) => { e.currentTarget.style.transform = 'translateY(0)'; e.currentTarget.style.boxShadow = 'none'; }}
          >
            <div style={{ backgroundColor: '#ECFDF5', width: '64px', height: '64px', borderRadius: '16px', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 20px auto' }}>
              <TrendingUp size={32} color="#10B981" />
            </div>
            <h3 style={{ fontSize: '20px', fontWeight: 'bold', marginBottom: '8px', color: '#1A1A1A' }}>Rentabilidad</h3>
            <p style={{ fontSize: '14px', color: '#666', margin: 0 }}>Análisis de márgenes, matriz BCG y punto de equilibrio por familia.</p>
          </div>
        </Link>

        {/* Ingeniería de Menú Tile */}
        <Link href="/admin/escandallos" style={{ textDecoration: 'none' }}>
          <div style={{
            backgroundColor: 'white',
            padding: '40px',
            borderRadius: '24px',
            border: '1px solid #E5E7EB',
            textAlign: 'center',
            cursor: 'pointer',
            transition: 'transform 0.2s, box-shadow 0.2s'
          }}
          onMouseOver={(e) => { e.currentTarget.style.transform = 'translateY(-4px)'; e.currentTarget.style.boxShadow = '0 10px 25px -5px rgba(0, 0, 0, 0.1)'; }}
          onMouseOut={(e) => { e.currentTarget.style.transform = 'translateY(0)'; e.currentTarget.style.boxShadow = 'none'; }}
          >
            <div style={{ backgroundColor: '#FEF3C7', width: '64px', height: '64px', borderRadius: '16px', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 20px auto' }}>
              <BookOpen size={32} color="#D97706" />
            </div>
            <h3 style={{ fontSize: '20px', fontWeight: 'bold', marginBottom: '8px', color: '#1A1A1A' }}>Ingeniería de Menú</h3>
            <p style={{ fontSize: '14px', color: '#666', margin: 0 }}>Escandallos avanzados, cálculo de mermas y optimización de márgenes.</p>
          </div>
        </Link>

        {/* Ventas por Hora Tile */}
        <Link href="/consulta/ventas" style={{ textDecoration: 'none' }}>
          <div style={{
            backgroundColor: 'white',
            padding: '40px',
            borderRadius: '24px',
            border: '1px solid #E5E7EB',
            textAlign: 'center',
            cursor: 'pointer',
            transition: 'transform 0.2s, box-shadow 0.2s'
          }}
          onMouseOver={(e) => { e.currentTarget.style.transform = 'translateY(-4px)'; e.currentTarget.style.boxShadow = '0 10px 25px -5px rgba(0, 0, 0, 0.1)'; }}
          onMouseOut={(e) => { e.currentTarget.style.transform = 'translateY(0)'; e.currentTarget.style.boxShadow = 'none'; }}
          >
            <div style={{ backgroundColor: '#DBEAFE', width: '64px', height: '64px', borderRadius: '16px', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 20px auto' }}>
              <Clock size={32} color="#2563EB" />
            </div>
            <h3 style={{ fontSize: '20px', fontWeight: 'bold', marginBottom: '8px', color: '#1A1A1A' }}>Ventas por hora</h3>
            <p style={{ fontSize: '14px', color: '#666', margin: 0 }}>Análisis detallado de transacciones y flujo de clientes por franja horaria.</p>
          </div>
        </Link>

        {/* Admin Tile */}
        <Link href="/admin/importar" style={{ textDecoration: 'none' }}>
          <div style={{
            backgroundColor: 'white',
            padding: '40px',
            borderRadius: '24px',
            border: '1px solid #E5E7EB',
            textAlign: 'center',
            cursor: 'pointer',
            transition: 'transform 0.2s, box-shadow 0.2s'
          }}
          onMouseOver={(e) => { e.currentTarget.style.transform = 'translateY(-4px)'; e.currentTarget.style.boxShadow = '0 10px 25px -5px rgba(0, 0, 0, 0.1)'; }}
          onMouseOut={(e) => { e.currentTarget.style.transform = 'translateY(0)'; e.currentTarget.style.boxShadow = 'none'; }}
          >
            <div style={{ backgroundColor: '#F3F4F6', width: '64px', height: '64px', borderRadius: '16px', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 20px auto' }}>
              <Settings size={32} color="#1A1A1A" />
            </div>
            <h3 style={{ fontSize: '20px', fontWeight: 'bold', marginBottom: '8px', color: '#1A1A1A' }}>Admin</h3>
            <p style={{ fontSize: '14px', color: '#666', margin: 0 }}>Gestión de datos, carga de archivos y configuración del sistema.</p>
          </div>
        </Link>
      </div>

      <div style={{ marginTop: '40px', textAlign: 'center' }}>
        <Link href="/login" style={{
          display: 'flex',
          alignItems: 'center',
          gap: '8px',
          padding: '10px 20px',
          borderRadius: '12px',
          border: '1px solid #E0E0E0',
          backgroundColor: 'white',
          color: '#666',
          fontSize: '14px',
          textDecoration: 'none',
          fontWeight: '500'
        }}>
          <LogOut size={16} /> Cerrar sesión
        </Link>
        <p style={{ marginTop: '20px', fontSize: '12px', color: '#999' }}>
          Actualizado: {new Date().toLocaleDateString('es-ES')}
        </p>
      </div>
    </div>
  );
}
