import { NextRequest, NextResponse } from 'next/server';

export const runtime = 'edge';

export async function POST(req: NextRequest, context: any) {
  const { DB } = context.env;
  if (!DB) return NextResponse.json({ error: "DB not found" }, { status: 500 });

  try {
    const { inventory, location } = await req.json();
    const date = new Date().toISOString().split('T')[0];

    const statements = [];

    for (const item of inventory) {
      statements.push(
        DB.prepare(`
          INSERT INTO daily_operations (date, product_id, location, closing_stock, waste_units) 
          VALUES (?, ?, ?, ?, ?)
          ON CONFLICT(date, product_id, location) DO UPDATE SET 
            closing_stock = excluded.closing_stock,
            waste_units = excluded.waste_units
        `).bind(date, item.id, location || 'General', item.closing, item.waste)
      );
    }

    await DB.batch(statements);

    return NextResponse.json({ success: true });
  } catch (e: any) {
    console.error(e);
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
