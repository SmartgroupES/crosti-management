CREATE TABLE IF NOT EXISTS product_families (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    description TEXT
);

CREATE TABLE IF NOT EXISTS raw_materials (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    current_stock REAL DEFAULT 0,
    unit_measure TEXT,
    min_stock_alert REAL,
    average_cost_per_unit REAL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    family_id INTEGER,
    name TEXT NOT NULL,
    sale_price REAL NOT NULL,
    target_margin REAL DEFAULT 0.75,
    stock_available INTEGER DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    v_index REAL DEFAULT 0, -- Visibility index for AI Vision
    FOREIGN KEY (family_id) REFERENCES product_families(id)
);

CREATE TABLE IF NOT EXISTS recipes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    product_id INTEGER,
    material_id INTEGER,
    quantity_needed REAL,
    waste_factor REAL DEFAULT 1.0,
    FOREIGN KEY (product_id) REFERENCES products(id),
    FOREIGN KEY (material_id) REFERENCES raw_materials(id)
);

CREATE TABLE IF NOT EXISTS sales (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sale_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    product_name TEXT,
    quantity INTEGER DEFAULT 1,
    total_amount REAL,
    ticket_number TEXT,
    location TEXT
);

CREATE TABLE IF NOT EXISTS fixed_costs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    category TEXT NOT NULL,
    amount REAL NOT NULL,
    recurrence TEXT DEFAULT 'monthly',
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS daily_operations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    date DATE DEFAULT (DATE('now')),
    product_id INTEGER,
    location TEXT,
    closing_stock INTEGER DEFAULT 0,
    waste_units INTEGER DEFAULT 0,
    production_planned INTEGER DEFAULT 0,
    production_actual INTEGER DEFAULT 0,
    FOREIGN KEY (product_id) REFERENCES products(id),
    UNIQUE(date, product_id, location)
);

CREATE TABLE IF NOT EXISTS production_plans (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    plan_date DATE NOT NULL,
    product_id INTEGER,
    suggested_quantity INTEGER,
    approved_quantity INTEGER,
    status TEXT DEFAULT 'pending',
    FOREIGN KEY (product_id) REFERENCES products(id)
);

CREATE TABLE IF NOT EXISTS purchases (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    supplier_id INTEGER,
    material_id INTEGER,
    quantity REAL,
    total_cost REAL,
    invoice_date DATE,
    invoice_file_key TEXT
);

CREATE TABLE IF NOT EXISTS suppliers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    cif TEXT
);

CREATE TABLE IF NOT EXISTS historical_recipes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    micros_id TEXT,
    name TEXT NOT NULL,
    total_cost REAL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS historical_recipe_ingredients (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    recipe_id INTEGER,
    ingredient_name TEXT NOT NULL,
    is_sub_recipe BOOLEAN DEFAULT FALSE,
    unit TEXT,
    quantity_dirty REAL,
    quantity_clean REAL,
    cost_dirty REAL,
    cost_clean REAL,
    FOREIGN KEY (recipe_id) REFERENCES historical_recipes(id)
);

CREATE TABLE IF NOT EXISTS employees (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    position TEXT,
    hourly_rate REAL DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS schedules (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    employee_id INTEGER,
    date DATE NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    location TEXT,
    FOREIGN KEY (employee_id) REFERENCES employees(id)
);
