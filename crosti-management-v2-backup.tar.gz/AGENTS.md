<!-- BEGIN:nextjs-agent-rules -->
# This is NOT the Next.js you know

This version has breaking changes — APIs, conventions, and file structure may all differ from your training data. Read the relevant guide in `node_modules/next/dist/docs/` before writing any code. Heed deprecation notices.
<!-- END:nextjs-agent-rules -->

# Backup & Notification Policy
1. Whenever the user requests a "backup", create a compressed archive of the project.
2. Use a sequential identifier (v1, v2, v3...). Check `BACKUP_LOG.md` for the current count.
3. Generate a detailed report of changes (diffs, additions, fixes) since the last backup.
4. Prepare an email report for: ncarrillok@gmail.com.
