'use client';

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import { ChevronDown } from 'lucide-react';

export default function LoginPage() {
  const router = useRouter();
  const [profile, setProfile] = useState('Dirección');
  const [pin, setPin] = useState('');

  const handleLogin = () => {
    // Basic simulation for now
    router.push('/');
  };

  return (
    <div style={{
      backgroundColor: '#FAF9F6',
      minHeight: '100vh',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif',
      color: '#1A1A1A'
    }}>
      <div style={{ textAlign: 'center', marginBottom: '60px' }}>
        <img src="/logo-crosti.jpg" alt="Crosti Logo" style={{ height: '80px', borderRadius: '16px', marginBottom: '20px' }} />
        <h1 style={{ fontSize: '32px', fontWeight: 'bold', margin: '0 0 10px 0' }}>Crosti Hub</h1>
        <p style={{ fontSize: '16px', color: '#666', margin: 0 }}>Sistema de Gestión Operativa</p>
      </div>

      <div style={{
        width: '100%',
        maxWidth: '400px',
        textAlign: 'center'
      }}>
        <h2 style={{ fontSize: '24px', fontWeight: 'bold', marginBottom: '8px' }}>Acceso al Sistema</h2>
        <p style={{ fontSize: '14px', color: '#666', marginBottom: '32px' }}>Selecciona tu perfil e introduce tu clave</p>

        <div style={{ position: 'relative', marginBottom: '16px' }}>
          <select
            value={profile}
            onChange={(e) => setProfile(e.target.value)}
            style={{
              width: '100%',
              padding: '16px 20px',
              fontSize: '16px',
              borderRadius: '12px',
              border: '1px solid #E0E0E0',
              backgroundColor: 'white',
              appearance: 'none',
              cursor: 'pointer',
              fontWeight: '500'
            }}
          >
            <option>Dirección</option>
            <option>Gerente de Tienda</option>
            <option>Supervisor</option>
            <option>Admin</option>
          </select>
          <ChevronDown 
            size={20} 
            style={{ position: 'absolute', right: '16px', top: '50%', transform: 'translateY(-50%)', pointerEvents: 'none', color: '#666' }} 
          />
        </div>

        <div style={{
          backgroundColor: '#EDF2FF',
          borderRadius: '12px',
          padding: '24px',
          marginBottom: '24px',
          display: 'flex',
          justifyContent: 'center',
          gap: '12px'
        }}>
          {[1, 2, 3, 4].map((i) => (
            <div key={i} style={{
              width: '12px',
              height: '12px',
              borderRadius: '50%',
              backgroundColor: pin.length >= i ? '#1A1A1A' : '#D1D5DB'
            }} />
          ))}
        </div>

        <button
          onClick={handleLogin}
          style={{
            width: '100%',
            padding: '16px',
            fontSize: '16px',
            fontWeight: 'bold',
            borderRadius: '12px',
            border: 'none',
            backgroundColor: '#1A1A1A',
            color: 'white',
            cursor: 'pointer',
            transition: 'opacity 0.2s'
          }}
          onMouseOver={(e) => (e.currentTarget.style.opacity = '0.9')}
          onMouseOut={(e) => (e.currentTarget.style.opacity = '1')}
        >
          Entrar
        </button>
      </div>

      <div style={{ position: 'absolute', bottom: '40px', fontSize: '12px', color: '#999' }}>
        Actualizado: {new Date().toLocaleDateString('es-ES')}
      </div>
    </div>
  );
}
