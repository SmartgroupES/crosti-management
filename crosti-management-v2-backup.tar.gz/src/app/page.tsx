'use client';

import React from 'react';
import Link from 'next/link';
import { BarChart3, ClipboardList, Box, Settings, LogOut } from 'lucide-react';

export default function Dashboard() {
  const modules = [
    {
      title: 'Consulta Pre-Planificación',
      description: 'Ventas, merma, inventarios, costos, bonificaciones',
      icon: <BarChart3 size={40} color="#2563EB" />,
      href: '/consulta/ventas',
      borderColor: '#E5E7EB'
    },
    {
      title: 'Planificador de Producción',
      description: 'Planes semanales por tienda y categoría — datos en la nube',
      icon: <ClipboardList size={40} color="#D97706" />,
      href: '/produccion',
      borderColor: '#F59E0B'
    },
    {
      title: 'Inventario de Cierre',
      description: 'Conteo diario por tienda — acceso desde móvil',
      icon: <Box size={40} color="#D97706" />,
      href: '/inventario',
      borderColor: '#F59E0B'
    },
    {
      title: 'Admin — Carga de Datos',
      description: 'Subir merma, ventas y gestión del sistema',
      icon: <Settings size={40} color="#059669" />,
      href: '/admin/importar',
      borderColor: '#10B981'
    }
  ];

  return (
    <div style={{
      backgroundColor: '#FAF9F6',
      minHeight: '100vh',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      padding: '60px 20px',
      fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif',
      color: '#1A1A1A'
    }}>
      <div style={{ textAlign: 'center', marginBottom: '40px' }}>
        <img src="/logo-crosti.jpg" alt="Crosti Logo" style={{ height: '80px', borderRadius: '16px', marginBottom: '20px' }} />
        <h1 style={{ fontSize: '32px', fontWeight: 'bold', margin: '0 0 10px 0' }}>Crosti Hub</h1>
        <p style={{ fontSize: '16px', color: '#666', margin: 0 }}>Sistema de Gestión Operativa</p>
      </div>

      <div style={{
        display: 'inline-block',
        backgroundColor: '#1A1A1A',
        color: 'white',
        padding: '4px 16px',
        borderRadius: '20px',
        fontSize: '12px',
        fontWeight: 'bold',
        textTransform: 'uppercase',
        marginBottom: '40px'
      }}>
        Dirección
      </div>

      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
        gap: '24px',
        width: '100%',
        maxWidth: '900px'
      }}>
        {modules.map((mod, index) => (
          <Link key={index} href={mod.href} style={{ textDecoration: 'none' }}>
            <div style={{
              backgroundColor: 'white',
              padding: '40px 30px',
              borderRadius: '24px',
              border: `2px solid ${mod.borderColor}`,
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              textAlign: 'center',
              height: '100%',
              transition: 'transform 0.2s, box-shadow 0.2s',
              cursor: 'pointer'
            }}
            onMouseOver={(e) => {
              e.currentTarget.style.transform = 'translateY(-5px)';
              e.currentTarget.style.boxShadow = '0 10px 25px -5px rgba(0, 0, 0, 0.1)';
            }}
            onMouseOut={(e) => {
              e.currentTarget.style.transform = 'translateY(0)';
              e.currentTarget.style.boxShadow = 'none';
            }}>
              <div style={{ marginBottom: '20px' }}>{mod.icon}</div>
              <h3 style={{ fontSize: '20px', fontWeight: 'bold', margin: '0 0 12px 0', color: '#1A1A1A' }}>{mod.title}</h3>
              <p style={{ fontSize: '14px', color: '#666', lineHeight: '1.5', margin: 0 }}>{mod.description}</p>
            </div>
          </Link>
        ))}
      </div>

      <div style={{ marginTop: '40px', textAlign: 'center' }}>
        <Link href="/login" style={{
          display: 'flex',
          alignItems: 'center',
          gap: '8px',
          padding: '10px 20px',
          borderRadius: '12px',
          border: '1px solid #E0E0E0',
          backgroundColor: 'white',
          color: '#666',
          fontSize: '14px',
          textDecoration: 'none',
          fontWeight: '500'
        }}>
          <LogOut size={16} /> Cerrar sesión
        </Link>
        <p style={{ marginTop: '20px', fontSize: '12px', color: '#999' }}>
          Actualizado: {new Date().toLocaleDateString('es-ES')}
        </p>
      </div>
    </div>
  );
}
