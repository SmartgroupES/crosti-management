'use client';

import React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { ChevronDown, ArrowRight, ShoppingCart, Percent, Box, ClipboardList, BookOpen, Calculator } from 'lucide-react';

export default function ConsultaLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();

  const tabs = [
    { name: 'Ventas', href: '/consulta/ventas', icon: <ShoppingCart size={16} /> },
    { name: 'Merma', href: '/consulta/merma', icon: <Percent size={16} /> },
    { name: 'Inventarios', href: '/consulta/inventarios', icon: <Box size={16} /> },
    { name: 'Pedidos', href: '/consulta/pedidos', icon: <ClipboardList size={16} /> },
    { name: 'Planificación', href: '/consulta/planificacion', icon: <ClipboardList size={16} /> },
    { name: 'Recetas', href: '/consulta/recetas', icon: <BookOpen size={16} /> },
    { name: 'Costo Teórico', href: '/consulta/costo', icon: <Calculator size={16} /> },
  ];

  return (
    <div style={{ backgroundColor: '#F3F4F6', minHeight: '100vh', fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif' }}>
      {/* Header */}
      <header style={{ backgroundColor: '#1A1A1A', color: 'white', padding: '10px 40px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '20px' }}>
          <Link href="/">
            <img src="/logo-crosti.jpg" alt="Crosti Logo" style={{ height: '40px', borderRadius: '8px' }} />
          </Link>
          <span style={{ color: '#F97316', fontSize: '12px', fontWeight: 'bold', borderLeft: '1px solid #444', paddingLeft: '20px' }}>CONSULTA PRE-PLANIFICACIÓN</span>
        </div>
        
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <div style={{ backgroundColor: '#333', padding: '6px 12px', borderRadius: '8px', fontSize: '12px', display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer' }}>
            TODOS (Global) <ChevronDown size={14} />
          </div>
          <div style={{ backgroundColor: '#333', padding: '6px 12px', borderRadius: '8px', fontSize: '12px', display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer' }}>
            S16 (13 - 19 abr) <ChevronDown size={14} />
          </div>
          <div style={{ backgroundColor: '#F97316', padding: '6px 12px', borderRadius: '8px', fontSize: '12px', fontWeight: 'bold', cursor: 'pointer' }}>
            DATOS S12-S15
          </div>
          <div style={{ color: '#F97316', fontSize: '12px', fontWeight: 'bold', display: 'flex', alignItems: 'center', gap: '4px', cursor: 'pointer', marginLeft: '10px' }}>
            Ir al Planificador <ArrowRight size={14} />
          </div>
        </div>
      </header>

      {/* Week Banner */}
      <div style={{ backgroundColor: 'white', padding: '8px 40px', borderBottom: '1px solid #E5E7EB', display: 'flex', justifyContent: 'space-between', fontSize: '12px', color: '#666' }}>
        <div><strong>Semana 16:</strong> 13 de abril al 19 de abril 2026</div>
        <div>Base: promedio últimas 4 semanas (S12-S15)</div>
      </div>

      {/* Tabs */}
      <nav style={{ backgroundColor: 'white', padding: '15px 40px', display: 'flex', gap: '10px', overflowX: 'auto' }}>
        {tabs.map((tab) => {
          const isActive = pathname === tab.href;
          return (
            <Link 
              key={tab.name} 
              href={tab.href}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                padding: '8px 16px',
                borderRadius: '8px',
                fontSize: '13px',
                fontWeight: isActive ? 'bold' : 'normal',
                textDecoration: 'none',
                backgroundColor: isActive ? '#1A1A1A' : 'white',
                color: isActive ? 'white' : '#666',
                border: isActive ? 'none' : '1px solid #E5E7EB',
                whiteSpace: 'nowrap'
              }}
            >
              {tab.icon}
              {tab.name}
            </Link>
          );
        })}
      </nav>

      {/* Content */}
      <main style={{ padding: '20px 40px' }}>
        {children}
      </main>
    </div>
  );
}
