'use client';

import React from 'react';
import { BookOpen, Hash, Calculator, Clipboard, Search, FileText, Download } from 'lucide-react';

export default function RecetasPage() {
  const kpis = [
    { label: 'TOTAL RECETAS', value: '47', subvalue: 'Base de datos completa', icon: <BookOpen size={24} color="#EF4444" /> },
    { label: 'INGREDIENTES ÚNICOS', value: '312', subvalue: 'Materias primas', icon: <Hash size={24} color="#666" /> },
    { label: 'COSTO PROMEDIO', value: '1,24 €', subvalue: 'Costo receta promedio', icon: <Calculator size={24} color="#EF4444" /> },
    { label: 'MOSTRANDO', value: '4.075', subvalue: 'Registros filtrados', icon: <Clipboard size={24} color="#666" /> },
  ];

  const recipeGroups = [
    {
      id: '80110003',
      name: 'YOGURT GRANOLA',
      cost: '0.999 €',
      status: 'HISTÓRICOS',
      ingredients: [
        { id: '80110003', sub: 'No', item: 'YOGURT', unit: 'Litro', cost: '0.999', qtySucia: '0.170', qtyLimpia: '0.170', costSucia: '0.382', costLimpia: '0.065' },
        { id: '80110003', sub: 'No', item: 'TAPA VASO CON AGUJERO', unit: 'Pieza', cost: '0.999', qtySucia: '1.000', qtyLimpia: '1.000', costSucia: '0.025', costLimpia: '0.025' },
        { id: '80110003', sub: 'No', item: 'VASO PLASTICO SMOTHIES 16 OZ', unit: 'Pieza', cost: '0.999', qtySucia: '1.000', qtyLimpia: '1.000', costSucia: '0.068', costLimpia: '0.068' },
      ]
    },
    {
      id: '10310013',
      name: 'ZUMO DE NARANJA',
      cost: '0.997 €',
      status: 'HISTÓRICOS',
      ingredients: [
        { id: '10310013', sub: 'No', item: 'SUB ZUMO DE NARANJA', unit: 'LT', cost: '0.997', qtySucia: '0.330', qtyLimpia: '0.320', costSucia: '0.908', costLimpia: '0.300' },
        { id: '10310013', sub: 'Sí', item: 'NARANJA', unit: 'Kilo', cost: '0.997', qtySucia: '3.000', qtyLimpia: '3.000', costSucia: '2.750', costLimpia: '8.251' },
      ]
    },
    {
      id: '30310033',
      name: 'ZUMO DE NARANJA 1 LITRO',
      cost: '3.103 €',
      status: 'HISTÓRICOS',
      ingredients: [
        { id: '30310033', sub: 'No', item: 'BOTELLA PLAST 1LT', unit: 'Pieza', cost: '3.103', qtySucia: '1.000', qtyLimpia: '1.000', costSucia: '0.352', costLimpia: '0.352' },
        { id: '30310033', sub: 'No', item: 'SUB ZUMO DE NARANJA', unit: 'LT', cost: '3.103', qtySucia: '1.000', qtyLimpia: '1.000', costSucia: '2.750', costLimpia: '2.750' },
      ]
    }
  ];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      {/* KPI Cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '20px' }}>
        {kpis.map((kpi, idx) => (
          <div key={idx} style={{ backgroundColor: 'white', padding: '24px', borderRadius: '16px', border: '1px solid #E5E7EB' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '12px' }}>
              <div style={{ fontSize: '11px', fontWeight: 'bold', color: '#9CA3AF', letterSpacing: '0.5px' }}>{kpi.label}</div>
              {kpi.icon}
            </div>
            <div style={{ fontSize: '24px', fontWeight: '900', color: '#1A1A1A', marginBottom: '4px' }}>{kpi.value}</div>
            <div style={{ fontSize: '12px', color: '#6B7280' }}>{kpi.subvalue}</div>
          </div>
        ))}
      </div>

      {/* Filters Section */}
      <div style={{ backgroundColor: 'white', padding: '24px', borderRadius: '20px', border: '1px solid #E5E7EB' }}>
        <div style={{ display: 'flex', gap: '20px', alignItems: 'flex-end', flexWrap: 'wrap' }}>
          {['Receta', 'Sub-Receta', 'Ingrediente'].map(label => (
            <div key={label} style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
              <label style={{ fontSize: '11px', fontWeight: 'bold', color: '#9CA3AF', textTransform: 'uppercase' }}>{label}</label>
              <select style={{ padding: '10px', borderRadius: '8px', border: '1px solid #E5E7EB', fontSize: '13px', backgroundColor: '#F9FAFB', minWidth: '150px' }}>
                <option>Todas</option>
              </select>
            </div>
          ))}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', flex: 1, minWidth: '200px' }}>
            <label style={{ fontSize: '11px', fontWeight: 'bold', color: '#9CA3AF', textTransform: 'uppercase' }}>Buscar</label>
            <div style={{ position: 'relative' }}>
              <input type="text" placeholder="Buscar receta o ingrediente..." style={{ width: '100%', padding: '10px 10px 10px 40px', borderRadius: '8px', border: '1px solid #E5E7EB', fontSize: '13px' }} />
              <Search size={18} style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: '#9CA3AF' }} />
            </div>
          </div>
          <button style={{ backgroundColor: 'white', border: '1px solid #EF4444', color: '#EF4444', padding: '10px 20px', borderRadius: '8px', fontSize: '13px', fontWeight: 'bold', cursor: 'pointer' }}>Limpiar filtros</button>
          <button style={{ backgroundColor: '#F0FDF4', border: '1px solid #10B981', color: '#10B981', padding: '10px 20px', borderRadius: '8px', fontSize: '13px', fontWeight: 'bold', display: 'flex', alignItems: 'center', gap: '6px', cursor: 'pointer' }}><Download size={16} /> Excel</button>
          <button style={{ backgroundColor: '#FEF2F2', border: '1px solid #EF4444', color: '#EF4444', padding: '10px 20px', borderRadius: '8px', fontSize: '13px', fontWeight: 'bold', display: 'flex', alignItems: 'center', gap: '6px', cursor: 'pointer' }}><FileText size={16} /> PDF</button>
        </div>
      </div>

      {/* Table Section */}
      <div style={{ backgroundColor: 'white', padding: '30px', borderRadius: '20px', border: '1px solid #E5E7EB', overflowX: 'auto' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '20px' }}>
           <div style={{ backgroundColor: '#F3F4F6', padding: '6px', borderRadius: '6px' }}><BookOpen size={16} color="#666" /></div>
           <h3 style={{ fontSize: '16px', fontWeight: 'bold', margin: 0 }}>Detalle de Recetas</h3>
        </div>

        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '10px' }}>
          <thead>
            <tr style={{ textAlign: 'left', backgroundColor: '#1A1A1A', color: 'white' }}>
              <th style={{ padding: '12px 8px' }}>#</th>
              <th style={{ padding: '12px 8px' }}>MICROS ID</th>
              <th style={{ padding: '12px 8px' }}>SUB</th>
              <th style={{ padding: '12px 8px' }}>RECETA ▲</th>
              <th style={{ padding: '12px 8px' }}>INGREDIENTE</th>
              <th style={{ padding: '12px 8px' }}>UNIDAD</th>
              <th style={{ padding: '12px 8px', textAlign: 'right' }}>COSTO RECETA</th>
              <th style={{ padding: '12px 8px', textAlign: 'right' }}>CANT. SUCIA</th>
              <th style={{ padding: '12px 8px', textAlign: 'right' }}>CANT. LIMPIA</th>
              <th style={{ padding: '12px 8px', textAlign: 'right' }}>COSTO SUCIO</th>
              <th style={{ padding: '12px 8px', textAlign: 'right' }}>COSTO LIMPIO</th>
            </tr>
          </thead>
          <tbody>
            {recipeGroups.map((group, gIdx) => (
              <React.Fragment key={gIdx}>
                <tr style={{ backgroundColor: '#FAF9F6' }}>
                  <td colSpan={11} style={{ padding: '8px 12px', borderBottom: '1px solid #E5E7EB' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                      <span style={{ fontWeight: 'bold', color: '#D97706', fontSize: '11px' }}>🥣 {group.name}</span>
                      <span style={{ backgroundColor: '#FEF3C7', color: '#D97706', padding: '2px 8px', borderRadius: '4px', fontSize: '10px', fontWeight: 'bold' }}>{group.status}</span>
                      <span style={{ fontSize: '10px', color: '#666' }}>Costo: <strong style={{ color: '#EF4444' }}>{group.cost}</strong></span>
                      <span style={{ fontSize: '10px', color: '#9CA3AF' }}>MICROS: {group.id}</span>
                    </div>
                  </td>
                </tr>
                {group.ingredients.map((ing, iIdx) => (
                  <tr key={`${gIdx}-${iIdx}`} style={{ borderBottom: '1px solid #F3F4F6' }}>
                    <td style={{ padding: '8px', color: '#9CA3AF' }}>{iIdx + 1}</td>
                    <td style={{ padding: '8px', color: '#6B7280' }}>{ing.id}</td>
                    <td style={{ padding: '8px' }}><span style={{ backgroundColor: ing.sub === 'Sí' ? '#FEF3C7' : '#F0FDF4', color: ing.sub === 'Sí' ? '#D97706' : '#10B981', padding: '2px 6px', borderRadius: '4px', fontSize: '9px', fontWeight: 'bold' }}>{ing.sub}</span></td>
                    <td style={{ padding: '8px', fontWeight: 'bold' }}>{group.name}</td>
                    <td style={{ padding: '8px', color: ing.sub === 'Sí' ? '#6B7280' : '#1A1A1A', fontStyle: ing.sub === 'Sí' ? 'italic' : 'normal' }}>{ing.item}</td>
                    <td style={{ padding: '8px', color: '#6B7280' }}>{ing.unit}</td>
                    <td style={{ padding: '8px', textAlign: 'right', fontWeight: 'bold', color: '#EF4444' }}>{ing.cost} €</td>
                    <td style={{ padding: '8px', textAlign: 'right' }}>{ing.qtySucia}</td>
                    <td style={{ padding: '8px', textAlign: 'right' }}>{ing.qtyLimpia}</td>
                    <td style={{ padding: '8px', textAlign: 'right' }}>{ing.costSucia} €</td>
                    <td style={{ padding: '8px', textAlign: 'right' }}>{ing.costLimpia} €</td>
                  </tr>
                ))}
              </React.Fragment>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
