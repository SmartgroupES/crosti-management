'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { Camera, Upload, CheckCircle2, ChevronRight, AlertCircle, Trash2, ArrowLeft, Loader2, Save } from 'lucide-react';

export default function ReporteCierrePage() {
  const [step, setStep] = useState(1);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [photo, setPhoto] = useState<string | null>(null);
  
  // Mock products for the inventory step
  const [inventory, setInventory] = useState([
    { id: 1, name: 'Choco Chip Classic', closing: 5, waste: 0 },
    { id: 2, name: 'Red Velvet Stuffed', closing: 2, waste: 1 },
    { id: 3, name: 'Pistacho Gourmet', closing: 0, waste: 0 },
    { id: 4, name: 'Biscoff Lava', closing: 3, waste: 0 },
  ]);

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setPhoto(URL.createObjectURL(file));
      setIsAnalyzing(true);
      
      const formData = new FormData();
      formData.append('file', file);

      try {
        const res = await fetch('/api/vision/analyze', {
          method: 'POST',
          body: formData,
        });
        const data = await res.json();
        
        if (Array.isArray(data)) {
          // Map AI findings to our inventory structure
          const updatedInventory = inventory.map(item => {
            const found = data.find((aiItem: any) => 
              aiItem.name.toLowerCase().includes(item.name.toLowerCase()) || 
              item.name.toLowerCase().includes(aiItem.name.toLowerCase())
            );
            return found ? { ...item, closing: found.count } : item;
          });
          setInventory(updatedInventory);
        }
        setStep(2);
      } catch (e) {
        console.error('Error analyzing photo:', e);
        alert('Error al analizar la foto. Por favor, completa el inventario manualmente.');
        setStep(2);
      } finally {
        setIsAnalyzing(false);
      }
    }
  };

  const updateCount = (id: number, field: 'closing' | 'waste', val: number) => {
    setInventory(inventory.map(item => 
      item.id === id ? { ...item, [field]: Math.max(0, val) } : item
    ));
  };

  const handleSubmit = async () => {
    setIsAnalyzing(true);
    try {
      const res = await fetch('/api/planificacion/cierre', {
        method: 'POST',
        body: JSON.stringify({ inventory }),
      });
      const data = await res.json();
      if (data.success) {
        setStep(4);
      } else {
        alert('Error al guardar: ' + data.error);
      }
    } catch (e) {
      console.error(e);
      alert('Error de conexión');
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div style={{ backgroundColor: '#FAF9F6', minHeight: '100vh', fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif', color: '#1A1A1A' }}>
      {/* Header */}
      <header style={{ padding: '20px 24px', backgroundColor: 'white', borderBottom: '1px solid #E5E7EB', display: 'flex', alignItems: 'center', gap: '16px', position: 'sticky', top: 0, zIndex: 10 }}>
        <Link href="/planificacion" style={{ color: '#666' }}><ArrowLeft size={20} /></Link>
        <div>
          <h1 style={{ fontSize: '18px', fontWeight: 'bold', margin: 0 }}>Reporte de Cierre</h1>
          <p style={{ fontSize: '11px', color: '#9CA3AF', margin: 0, textTransform: 'uppercase', letterSpacing: '0.5px' }}>
            PASO {step} DE 3 • {new Date().toLocaleDateString('es-ES', { day: 'numeric', month: 'long' })}
          </p>
        </div>
      </header>

      <main style={{ padding: '24px', maxWidth: '600px', margin: '0 auto' }}>
        
        {/* Step 1: Photo Upload */}
        {step === 1 && (
          <div style={{ textAlign: 'center', animation: 'fadeIn 0.3s ease-in' }}>
            <div style={{ backgroundColor: '#FEE2E2', width: '80px', height: '80px', borderRadius: '24px', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 30px auto' }}>
              <Camera size={40} color="#EF4444" />
            </div>
            <h2 style={{ fontSize: '24px', fontWeight: 'bold', marginBottom: '12px' }}>Foto de Vitrina</h2>
            <p style={{ fontSize: '14px', color: '#666', marginBottom: '40px', lineHeight: '1.6' }}>
              Sube una foto de la vitrina al cierre. Nuestra IA identificará automáticamente las galletas restantes para ahorrarte tiempo.
            </p>

            <label style={{ 
              display: 'block', 
              backgroundColor: '#1A1A1A', 
              color: 'white', 
              padding: '18px', 
              borderRadius: '16px', 
              fontWeight: 'bold', 
              cursor: 'pointer',
              boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)',
              marginBottom: '20px'
            }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '10px' }}>
                {isAnalyzing ? <Loader2 size={20} className="animate-spin" /> : <Upload size={20} />}
                {isAnalyzing ? 'Analizando vitrina...' : 'Tomar Foto o Subir'}
              </div>
              <input type="file" accept="image/*" onChange={handlePhotoUpload} style={{ display: 'none' }} disabled={isAnalyzing} />
            </label>

            <button 
              onClick={() => setStep(2)}
              style={{ background: 'none', border: 'none', color: '#9CA3AF', fontSize: '14px', fontWeight: 'bold', cursor: 'pointer' }}
            >
              Omitir y completar manualmente
            </button>
          </div>
        )}

        {/* Step 2: Inventory Confirmation */}
        {step === 2 && (
          <div style={{ animation: 'fadeIn 0.3s ease-in' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '24px' }}>
              <CheckCircle2 size={20} color="#10B981" />
              <h2 style={{ fontSize: '18px', fontWeight: 'bold', margin: 0 }}>Confirmar Inventario</h2>
            </div>
            
            <div style={{ backgroundColor: '#F0FDF4', padding: '12px 16px', borderRadius: '12px', marginBottom: '24px', border: '1px solid #BBF7D0', display: 'flex', gap: '10px' }}>
              <AlertCircle size={18} color="#166534" />
              <p style={{ fontSize: '12px', color: '#166534', margin: 0 }}>
                La IA ha sugerido estos conteos basados en la foto. Por favor, valídalos.
              </p>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
              {inventory.map(item => (
                <div key={item.id} style={{ backgroundColor: 'white', padding: '20px', borderRadius: '20px', border: '1px solid #E5E7EB', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <div>
                    <div style={{ fontSize: '14px', fontWeight: 'bold' }}>{item.name}</div>
                    <div style={{ fontSize: '11px', color: '#9CA3AF' }}>Quedan en vitrina</div>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                    <button onClick={() => updateCount(item.id, 'closing', item.closing - 1)} style={{ width: '32px', height: '32px', borderRadius: '8px', border: '1px solid #E5E7EB', background: 'white' }}>-</button>
                    <span style={{ fontSize: '16px', fontWeight: 'bold', minWidth: '20px', textAlign: 'center' }}>{item.closing}</span>
                    <button onClick={() => updateCount(item.id, 'closing', item.closing + 1)} style={{ width: '32px', height: '32px', borderRadius: '8px', border: '1px solid #E5E7EB', background: 'white' }}>+</button>
                  </div>
                </div>
              ))}
            </div>

            <button 
              onClick={() => setStep(3)}
              style={{ width: '100%', backgroundColor: '#1A1A1A', color: 'white', padding: '18px', borderRadius: '16px', fontWeight: 'bold', marginTop: '30px', border: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px' }}
            >
              Siguiente: Reportar Merma <ChevronRight size={18} />
            </button>
          </div>
        )}

        {/* Step 3: Waste Reporting */}
        {step === 3 && (
          <div style={{ animation: 'fadeIn 0.3s ease-in' }}>
             <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '24px' }}>
              <Trash2 size={20} color="#EF4444" />
              <h2 style={{ fontSize: '18px', fontWeight: 'bold', margin: 0 }}>Reporte de Merma</h2>
            </div>
            
            <p style={{ fontSize: '14px', color: '#666', marginBottom: '24px' }}>
              ¿Cuántas unidades de cada producto se deben desechar por no estar en óptimas condiciones?
            </p>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
              {inventory.map(item => (
                <div key={item.id} style={{ backgroundColor: 'white', padding: '20px', borderRadius: '20px', border: '1px solid #E5E7EB', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <div>
                    <div style={{ fontSize: '14px', fontWeight: 'bold' }}>{item.name}</div>
                    <div style={{ fontSize: '11px', color: '#EF4444' }}>Unidades desperdicio</div>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                    <button onClick={() => updateCount(item.id, 'waste', item.waste - 1)} style={{ width: '32px', height: '32px', borderRadius: '8px', border: '1px solid #E5E7EB', background: 'white' }}>-</button>
                    <span style={{ fontSize: '16px', fontWeight: 'bold', minWidth: '20px', textAlign: 'center' }}>{item.waste}</span>
                    <button onClick={() => updateCount(item.id, 'waste', item.waste + 1)} style={{ width: '32px', height: '32px', borderRadius: '8px', border: '1px solid #E5E7EB', background: 'white' }}>+</button>
                  </div>
                </div>
              ))}
            </div>

            <button 
              onClick={handleSubmit}
              style={{ width: '100%', backgroundColor: '#EF4444', color: 'white', padding: '18px', borderRadius: '16px', fontWeight: 'bold', marginTop: '30px', border: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px' }}
            >
              <Save size={18} /> Finalizar Reporte
            </button>
          </div>
        )}

        {/* Step 4: Success */}
        {step === 4 && (
          <div style={{ textAlign: 'center', animation: 'scaleUp 0.4s ease-out' }}>
            <div style={{ backgroundColor: '#ECFDF5', width: '80px', height: '80px', borderRadius: '40px', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 30px auto' }}>
              <CheckCircle2 size={40} color="#10B981" />
            </div>
            <h2 style={{ fontSize: '24px', fontWeight: 'bold', marginBottom: '12px' }}>¡Cierre Completado!</h2>
            <p style={{ fontSize: '14px', color: '#666', marginBottom: '40px' }}>
              Los datos han sido guardados correctamente. El sistema está generando la propuesta de producción para mañana.
            </p>

            <Link href="/planificacion/propuesta" style={{ 
              display: 'block', 
              backgroundColor: '#1A1A1A', 
              color: 'white', 
              padding: '18px', 
              borderRadius: '16px', 
              fontWeight: 'bold', 
              textDecoration: 'none',
              marginBottom: '12px'
            }}>
              Ver Propuesta de Producción
            </Link>
            
            <Link href="/" style={{ 
              display: 'block', 
              color: '#666', 
              fontSize: '14px', 
              fontWeight: 'bold', 
              textDecoration: 'none'
            }}>
              Volver al Inicio
            </Link>
          </div>
        )}

      </main>

      <style jsx global>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes scaleUp {
          from { opacity: 0; transform: scale(0.9); }
          to { opacity: 1; transform: scale(1); }
        }
        .animate-spin {
          animation: spin 1s linear infinite;
        }
        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
}
