import { NextRequest, NextResponse } from 'next/server';

export const runtime = 'edge';

export async function GET(req: NextRequest, context: any) {
  const { DB } = context.env;
  if (!DB) return NextResponse.json({ error: "DB not found" }, { status: 500 });

  try {
    // 1. Get all sales aggregated by product
    const salesPromise = DB.prepare(`
      SELECT 
        product_name, 
        SUM(quantity) as total_units, 
        SUM(total_amount) as total_revenue,
        AVG(total_amount / quantity) as avg_price
      FROM sales 
      GROUP BY product_name
    `).all();

    // 2. Get unit costs from recipes (using historical_recipes as primary cost source)
    const costsPromise = DB.prepare(`
      SELECT name as product_name, total_cost 
      FROM historical_recipes
    `).all();

    // 3. Get fixed costs
    const fixedCostsPromise = DB.prepare(`
      SELECT SUM(amount) as total_fixed 
      FROM fixed_costs 
      WHERE recurrence = 'monthly'
    `).first();

    const [salesData, costsData, fixedCosts] = await Promise.all([
      salesPromise,
      costsPromise,
      fixedCostsPromise
    ]);

    const sales = salesData.results;
    const costs = costsData.results;
    const totalFixed = fixedCosts?.total_fixed || 0;

    // 4. Calculate profitability per product
    const analysis = sales.map((sale: any) => {
      const costItem = costs.find((c: any) => c.product_name === sale.product_name);
      const unitCost = costItem?.total_cost || 0;
      const margin = sale.avg_price - unitCost;
      const totalMargin = margin * sale.total_units;

      return {
        name: sale.product_name,
        units: sale.total_units,
        revenue: sale.total_revenue,
        unitCost,
        unitMargin: margin,
        marginPercent: sale.avg_price > 0 ? (margin / sale.avg_price) * 100 : 0,
        totalContribution: totalMargin
      };
    });

    // 5. Global Metrics
    const totalRevenue = analysis.reduce((acc, curr) => acc + curr.revenue, 0);
    const totalContribution = analysis.reduce((acc, curr) => acc + curr.totalContribution, 0);
    const netProfit = totalContribution - totalFixed;
    const breakEven = totalRevenue > 0 ? (totalFixed / (totalContribution / totalRevenue)) : 0;

    return NextResponse.json({
      products: analysis,
      summary: {
        totalRevenue,
        totalContribution,
        totalFixed,
        netProfit,
        breakEven
      }
    });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
