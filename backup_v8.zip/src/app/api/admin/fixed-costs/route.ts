import { NextRequest, NextResponse } from 'next/server';

export const runtime = 'edge';

export async function GET(req: NextRequest, context: any) {
  const { DB } = context.env;

  if (!DB) {
    return NextResponse.json({ error: "Database binding not found" }, { status: 500 });
  }

  try {
    const { results } = await DB.prepare("SELECT * FROM fixed_costs ORDER BY category ASC").all();
    return NextResponse.json(results);
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest, context: any) {
  const { DB } = context.env;
  const body = await req.json();
  const { category, amount, recurrence } = body;

  if (!DB) {
    return NextResponse.json({ error: "Database binding not found" }, { status: 500 });
  }

  if (!category || amount === undefined) {
    return NextResponse.json({ error: "Category and amount are required" }, { status: 400 });
  }

  try {
    // Check if category already exists to update, or insert new
    const existing = await DB.prepare("SELECT id FROM fixed_costs WHERE category = ?").bind(category).first();

    if (existing) {
      await DB.prepare("UPDATE fixed_costs SET amount = ?, recurrence = ?, updated_at = CURRENT_TIMESTAMP WHERE category = ?")
        .bind(amount, recurrence || 'monthly', category)
        .run();
    } else {
      await DB.prepare("INSERT INTO fixed_costs (category, amount, recurrence) VALUES (?, ?, ?)")
        .bind(category, amount, recurrence || 'monthly')
        .run();
    }

    return NextResponse.json({ success: true });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest, context: any) {
    const { DB } = context.env;
    const { searchParams } = new URL(req.url);
    const id = searchParams.get('id');

    if (!DB) {
        return NextResponse.json({ error: "Database binding not found" }, { status: 500 });
    }

    if (!id) {
        return NextResponse.json({ error: "ID is required" }, { status: 400 });
    }

    try {
        await DB.prepare("DELETE FROM fixed_costs WHERE id = ?").bind(id).run();
        return NextResponse.json({ success: true });
    } catch (e: any) {
        return NextResponse.json({ error: e.message }, { status: 500 });
    }
}
