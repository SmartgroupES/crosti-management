import { NextRequest, NextResponse } from 'next/server';

export const runtime = 'edge';

export async function POST(req: NextRequest, context: any) {
  const { DB } = context.env;
  if (!DB) return NextResponse.json({ error: "DB not found" }, { status: 500 });

  try {
    const { inventory } = await req.json();
    const date = new Date().toISOString().split('T')[0];

    for (const item of inventory) {
      // Upsert daily operation
      const existing = await DB.prepare("SELECT id FROM daily_operations WHERE date = ? AND product_id = ?")
        .bind(date, item.id)
        .first();

      if (existing) {
        await DB.prepare("UPDATE daily_operations SET closing_stock = ?, waste_units = ? WHERE id = ?")
          .bind(item.closing, item.waste, existing.id)
          .run();
      } else {
        await DB.prepare("INSERT INTO daily_operations (date, product_id, closing_stock, waste_units) VALUES (?, ?, ?, ?)")
          .bind(date, item.id, item.closing, item.waste)
          .run();
      }
    }

    return NextResponse.json({ success: true });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
