import { NextRequest, NextResponse } from 'next/server';

export const runtime = 'edge';

export async function GET(req: NextRequest, context: any) {
  const { DB } = context.env;
  if (!DB) return NextResponse.json({ error: "DB not found" }, { status: 500 });

  try {
    // Target date: tomorrow
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    const dayOfWeek = tomorrow.getDay(); // 0=Sun, 1=Mon, ..., 6=Sat

    // 1. Get closing stock from TODAY (the latest record in daily_operations)
    const todayStr = new Date().toISOString().split('T')[0];
    const { results: closingStock } = await DB.prepare(`
      SELECT product_id, closing_stock 
      FROM daily_operations 
      WHERE date = ?
    `).bind(todayStr).all();

    // 2. Get historical sales for the SAME day of the week
    // SQLite strftime('%w', date) returns 0-6 where 0 is Sunday
    const { results: historicalSales } = await DB.prepare(`
      SELECT 
        product_name,
        AVG(quantity) as avg_sales,
        COUNT(quantity) as sample_size,
        -- Manual calculation of standard deviation in SQLite (limited functions)
        -- We'll approximate or fetch raw data to calculate in TS
        GROUP_CONCAT(quantity) as raw_quantities
      FROM sales 
      WHERE strftime('%w', sale_date) = ?
      GROUP BY product_name
    `).bind(dayOfWeek.toString()).all();

    // 3. Map products to their IDs
    const { results: products } = await DB.prepare("SELECT id, name FROM products WHERE is_active = 1").all();

    // 4. Calculate predictions
    const Z_FACTOR = 1.28; // ~80% service level to avoid too much waste in bakery

    const predictions = products.map((p: any) => {
      const hist = historicalSales.find((h: any) => h.product_name === p.name);
      const stock = closingStock.find((s: any) => s.product_id === p.id);
      
      const currentStock = stock?.closing_stock || 0;
      let suggested = 0;
      let confidence = "Low";

      if (hist) {
        const avg = hist.avg_sales || 0;
        const raw = (hist.raw_quantities as string).split(',').map(Number);
        
        // Calculate Standard Deviation
        const n = raw.length;
        const mean = raw.reduce((a, b) => a + b, 0) / n;
        const stdDev = Math.sqrt(raw.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / n);
        
        // IPS Formula: Sug = Avg + (Z * StdDev)
        const safetyStock = Z_FACTOR * stdDev;
        const rawSuggested = avg + safetyStock;
        
        suggested = Math.max(0, Math.ceil(rawSuggested - currentStock));
        confidence = n > 3 ? "High" : "Medium";
      } else {
        // Fallback: Default stock level if no history
        suggested = 50 - currentStock;
      }

      return {
        id: p.id,
        name: p.name,
        avg_historical: hist?.avg_sales || 0,
        current_stock: currentStock,
        suggested_production: Math.max(0, suggested),
        confidence,
        reason: hist ? `Basado en promedio de ${hist.sample_size} días similares.` : "Datos insuficientes, usando valores base."
      };
    });

    return NextResponse.json({
      date: tomorrow.toISOString().split('T')[0],
      dayName: tomorrow.toLocaleDateString('es-ES', { weekday: 'long' }),
      predictions
    });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
