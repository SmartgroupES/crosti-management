import { GoogleGenerativeAI } from "@google/generative-ai";
import { NextRequest, NextResponse } from "next/server";

export const runtime = "edge";

export async function POST(req: NextRequest, context: any) {
  const { GOOGLE_AI_API_KEY } = context.env;
  
  if (!GOOGLE_AI_API_KEY) {
    return NextResponse.json({ error: "Google AI API Key not found in environment" }, { status: 500 });
  }

  const genAI = new GoogleGenerativeAI(GOOGLE_AI_API_KEY);
  const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

  try {
    const formData = await req.formData();
    const file = formData.get("file") as File;
    
    if (!file) {
      return NextResponse.json({ error: "No image file provided" }, { status: 400 });
    }

    const arrayBuffer = await file.arrayBuffer();
    const bytes = new Uint8Array(arrayBuffer);
    let binary = "";
    for (let i = 0; i < bytes.byteLength; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    const base64Data = btoa(binary);

    const prompt = `Identify the types of cookies in this showcase and count how many of each there are. 
    Return ONLY a JSON array of objects with the following structure:
    [{"name": "Cookie Name", "count": number}]
    Ensure the names are as accurate as possible. If unsure, describe the cookie.`;

    const result = await model.generateContent([
      prompt,
      {
        inlineData: {
          data: base64Data,
          mimeType: file.type,
        },
      },
    ]);

    const response = await result.response;
    const text = response.text();
    
    // Clean up response to get JSON
    const jsonMatch = text.match(/\[.*\]/s);
    if (!jsonMatch) {
      return NextResponse.json({ error: "Could not parse AI response", raw: text }, { status: 500 });
    }
    
    const json = JSON.parse(jsonMatch[0]);
    return NextResponse.json(json);
  } catch (e: any) {
    console.error("AI Vision Error:", e);
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
