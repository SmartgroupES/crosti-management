# Backup Log - Crosti Management

| Version | Date | Changes Summary | Archive Path |
| :--- | :--- | :--- | :--- |
| v1 | 2026-04-25 | Initial migration, Cloudflare Pages deployment fixed, Importer implemented, Logo added. | N/A (Initial state) |
| v2 | 2026-04-26 | Complete ERP transformation based on 13 reference images. Historical recipes integrated. Branding updated to Crosti Hub. Deployment successful. | ../crosti-management-v2-backup.tar.gz |
| v3 | 2026-04-29 | Intelligent Planning System (IPS) wizard, AI Vision UI, Profitability Engine (BCG Matrix, Marginal Contribution), and Schema expansion. Deployment successful. | ./backup_v3.zip |
| v4 | 2026-04-29 | Product Categorization (Families), Gemini 1.5 Flash Vision Integration, and Closing Report database persistence. Fixed build errors. Deployment successful. | ./backup_v4.zip |
| v5 | 2026-04-29 | Real Profitability Engine: Connected Sales, Unit Costs (Recipes), and Fixed Costs. Dynamic BCG Matrix and Break-even point calculations. Deployment successful. | ./backup_v5.zip |
| v6 | 2026-04-29 | IPS Prediction Algorithm implementation based on historical sales and service levels. Deployment successful. | ./backup_v6.zip |
| v7 | 2026-04-29 | Prep List (Material Explosion): Automated ingredient calculation based on production plans. Modal UI integrated. Deployment successful. | ./backup_v7.zip |
