import { NextRequest, NextResponse } from 'next/server';
import { getRequestContext } from '@cloudflare/next-on-pages';

export const runtime = 'edge';

export async function GET(req: NextRequest) {
  const { env } = getRequestContext();
  const DB = env.DB;
  
  if (!DB) return NextResponse.json({ error: "DB not found" }, { status: 500 });

  try {
    // 1. Hourly Distribution
    const hourlySales = await DB.prepare(`
      SELECT 
        CAST(strftime('%H', sale_date) as INTEGER) as hour, 
        SUM(total_amount) as total_amount
      FROM sales
      WHERE sale_date >= date('now', '-3 months')
      GROUP BY hour
      ORDER BY hour ASC
    `).all();

    // 2. Advanced KPIs
    // Venta Hoy
    const todaySales = await DB.prepare(`
      SELECT SUM(total_amount) as total FROM sales WHERE date(sale_date) = date('now')
    `).first();

    // Venta Semana (Últimos 7 días)
    const weekSales = await DB.prepare(`
      SELECT SUM(total_amount) as total FROM sales WHERE date(sale_date) >= date('now', '-7 days')
    `).first();

    // Venta Mes (Mes actual)
    const monthSales = await DB.prepare(`
      SELECT SUM(total_amount) as total FROM sales WHERE strftime('%Y-%m', sale_date) = strftime('%Y-%m', 'now')
    `).first();

    // Proyección Anual: Promedio diario del último mes * 365
    const projectionData = await DB.prepare(`
      SELECT AVG(daily_total) as avg_daily FROM (
        SELECT date(sale_date) as d, SUM(total_amount) as daily_total 
        FROM sales 
        WHERE date(sale_date) >= date('now', '-30 days')
        GROUP BY d
      )
    `).first();

    const projectedAnnual = (projectionData?.avg_daily || 0) * 365;

    // 3. Monthly Chart Data
    const monthlySales = await DB.prepare(`
      SELECT 
        strftime('%m', sale_date) as month_num,
        SUM(total_amount) as sales
      FROM sales
      WHERE sale_date >= date('now', '-1 year')
      GROUP BY month_num
      ORDER BY month_num ASC
    `).all();

    const monthNames = ['ENE', 'FEB', 'MAR', 'ABR', 'MAY', 'JUN', 'JUL', 'AGO', 'SEP', 'OCT', 'NOV', 'DIC'];
    const formattedMonthly = monthlySales.results.map((r: any) => ({
      month: monthNames[parseInt(r.month_num) - 1],
      sales: r.sales
    }));

    // 4. Top 5 Products
    const topProducts = await DB.prepare(`
      SELECT product_name as name, SUM(total_amount) as amount
      FROM sales
      GROUP BY product_name
      ORDER BY amount DESC
      LIMIT 5
    `).all();

    const maxProductSales = topProducts.results.length > 0 ? (topProducts.results[0] as any).amount : 1;
    const formattedTopProducts = topProducts.results.map((p: any) => ({
      ...p,
      percent: Math.round((p.amount / maxProductSales) * 100),
      amount: `${Math.round(p.amount).toLocaleString()}€`
    }));

    return NextResponse.json({
      hourly: hourlySales.results,
      kpis: {
        today: todaySales?.total || 0,
        week: weekSales?.total || 0,
        month: monthSales?.total || 0,
        projectedAnnual: projectedAnnual
      },
      monthly: formattedMonthly,
      topProducts: formattedTopProducts
    });

  } catch (e: any) {
    console.error("Sales Stats Error:", e);
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
