import { NextRequest, NextResponse } from 'next/server';
import { getRequestContext } from '@cloudflare/next-on-pages';

export const runtime = 'edge';
export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
  try {
    const context = getRequestContext() as any;
    const DB = context.env.DB;

    // 1. Heatmap Data (By Week, Day, Hour)
    const heatmapData = await DB.prepare(`
      SELECT 
        strftime('%W', sale_date) as week,
        strftime('%w', sale_date) as day,
        strftime('%H', sale_date) as hour,
        COUNT(*) as quantity,
        SUM(total_amount) as total
      FROM sales
      WHERE sale_date >= date('now', '-30 days')
      GROUP BY week, day, hour
      ORDER BY week DESC, day ASC, hour ASC
    `).all();

    // 2. Hourly Sales (Last 24h - used for small charts if any)
    const hourlySales = await DB.prepare(`
      SELECT 
        strftime('%H:00', sale_date) as hour,
        SUM(total_amount) as total
      FROM sales
      WHERE sale_date >= date('now', '-1 day')
      GROUP BY hour
      ORDER BY hour ASC
    `).all();

    // 3. KPIs
    const todayResult = await DB.prepare(`SELECT SUM(total_amount) as total FROM sales WHERE date(sale_date) = date('now')`).first();
    const weekResult = await DB.prepare(`SELECT SUM(total_amount) as total FROM sales WHERE sale_date >= date('now', '-7 days')`).first();
    const monthResult = await DB.prepare(`SELECT SUM(total_amount) as total FROM sales WHERE sale_date >= date('now', 'start of month')`).first();
    const latestResult = await DB.prepare(`SELECT SUM(total_amount) as total FROM sales WHERE date(sale_date) = (SELECT MAX(date(sale_date)) FROM sales)`).first();

    // 4. Top 10 Products (Current Month/Year)
    const topProducts = await DB.prepare(`
      SELECT 
        product_name,
        SUM(quantity) as quantity,
        SUM(total_amount) as total
      FROM sales
      WHERE strftime('%Y', sale_date) = '2026'
      GROUP BY product_name
      ORDER BY quantity DESC
      LIMIT 10
    `).all();

    // 5. Bottom 10 Products (Current Month/Year)
    const bottomProducts = await DB.prepare(`
      SELECT 
        product_name,
        SUM(quantity) as quantity,
        SUM(total_amount) as total
      FROM sales
      WHERE strftime('%Y', sale_date) = '2026'
      GROUP BY product_name
      HAVING quantity > 0
      ORDER BY quantity ASC
      LIMIT 10
    `).all();

    // 6. Sales by Family
    const salesByFamily = await DB.prepare(`
      SELECT 
        COALESCE(f.name, 'Sin Categoría') as name,
        SUM(s.total_amount) as value
      FROM sales s
      LEFT JOIN products p ON s.product_name = p.name
      LEFT JOIN product_families f ON p.family_id = f.id
      WHERE strftime('%Y', s.sale_date) = '2026'
      GROUP BY name
      ORDER BY value DESC
    `).all();

    // 7. Monthly Stats by Year (for comparison)
    const monthlyYearlyStats = await DB.prepare(`
      SELECT 
        strftime('%Y', sale_date) as year,
        strftime('%m', sale_date) as month,
        SUM(total_amount) as sales
      FROM sales
      GROUP BY year, month
      ORDER BY year DESC, month ASC
    `).all();

    // 8. Weekly Stats 2026
    const weeklyStats2026 = await DB.prepare(`
      SELECT 
        strftime('%W', sale_date) as week,
        SUM(total_amount) as sales
      FROM sales
      WHERE strftime('%Y', sale_date) = '2026'
      GROUP BY week
      ORDER BY week ASC
    `).all();

    // 9. Monthly Trend (Summary)
    const monthlyStats = await DB.prepare(`
      SELECT 
        strftime('%Y-%m', sale_date) as month,
        SUM(total_amount) as sales
      FROM sales
      GROUP BY month
      ORDER BY month DESC
      LIMIT 12
    `).all();

    return NextResponse.json({
      heatmapData: heatmapData.results || [],
      hourlySales: hourlySales.results || [],
      todaySales: { total: (todayResult?.total || latestResult?.total || 0) },
      weekSales: { total: (weekResult?.total || 0) },
      monthSales: { total: (monthResult?.total || 0) },
      monthlyStats: (monthlyStats.results || []).reverse(),
      monthlyYearlyStats: monthlyYearlyStats.results || [],
      weeklyStats2026: weeklyStats2026.results || [],
      topProducts: topProducts.results || [],
      bottomProducts: bottomProducts.results || [],
      salesByFamily: salesByFamily.results || []
    });
  } catch (error: any) {
    console.error('Sales API Error:', error);
    return NextResponse.json({ error: error.message, todaySales: { total: 0 } }, { status: 500 });
  }
}
