'use client';

import React, { useState, useEffect } from 'react';
import { 
  BookOpen, 
  Search, 
  Plus, 
  ChevronRight,
  Database,
  ChefHat,
  CheckCircle
} from 'lucide-react';

import RecipeForm from '@/components/recipes/RecipeForm';

export default function RecetasView() {
  const [data, setData] = useState<{ recetas: any[], subRecetas: any[] }>({ recetas: [], subRecetas: [] });
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [activeItems, setActiveItems] = useState<Record<string, boolean>>({});

  const fetchData = () => {
    setLoading(true);
    fetch('/api/recetas')
      .then(res => res.json())
      .then(json => {
        const recetas = Array.isArray(json.recetas) ? json.recetas : [];
        const subRecetas = Array.isArray(json.subRecetas) ? json.subRecetas : [];
        
        setData({ recetas, subRecetas });
        
        // Inicialmente todas inactivas (false)
        const initialActive: Record<string, boolean> = {};
        [...recetas, ...subRecetas].forEach((item, idx) => {
          const id = item['CODIGO PROD. TERMINADO'] || item['SUB RECETA'] || `item-${idx}`;
          initialActive[id] = false;
        });
        setActiveItems(initialActive);
        
        setLoading(false);
      })
      .catch(e => {
        console.error(e);
        setLoading(false);
      });
  };

  useEffect(() => {
    fetchData();
  }, []);

  const toggleActive = (id: string) => {
    setActiveItems(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const [viewTab, setViewTab] = useState<'activas' | 'maestro'>('maestro');

  const filterList = (list: any[]) => list.filter(r => {
    const searchLower = searchTerm.toLowerCase();
    const matchesSearch = 
      (r['PROD. TERMINADO']?.toString().toLowerCase() || '').includes(searchLower) ||
      (r['GRUPO']?.toString().toLowerCase() || '').includes(searchLower) ||
      (r['FAMILIA']?.toString().toLowerCase() || '').includes(searchLower);
      
    const id = r['CODIGO PROD. TERMINADO'] || r['SUB RECETA'];
    const isActive = activeItems[id];
    
    if (viewTab === 'activas') {
      return matchesSearch && isActive;
    } else {
      // En el maestro mostramos todo lo que coincida con la búsqueda O esté activo
      return matchesSearch || isActive;
    }
  });

  const filteredRecetas = filterList(data.recetas);
  const filteredSubRecetas = filterList(data.subRecetas);

  const Table = ({ title, items, icon: Icon, type }: { title: string, items: any[], icon: any, type: string }) => (
    <div style={{ backgroundColor: 'white', borderRadius: '24px', border: '1px solid #E5E7EB', overflow: 'hidden', marginBottom: '30px' }}>
      <div style={{ padding: '16px 24px', borderBottom: '1px solid #F3F4F6', display: 'flex', justifyContent: 'space-between', alignItems: 'center', backgroundColor: '#FAF9F6' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          {Icon}
          <h3 style={{ fontSize: '14px', fontWeight: '900', color: '#1A1A1A' }}>{title}</h3>
        </div>
        <span style={{ fontSize: '10px', fontWeight: '900', color: '#801515', backgroundColor: '#FEE2E2', padding: '4px 10px', borderRadius: '10px' }}>
          {items.length} REGISTROS
        </span>
      </div>
      <div style={{ overflowX: 'auto' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ backgroundColor: '#F9FAFB', textAlign: 'left' }}>
              <th style={{ padding: '12px 24px', width: '40px' }}>
                <input 
                  type="checkbox"
                  checked={items.length > 0 && items.every(item => {
                    const id = item['CODIGO PROD. TERMINADO'] || item['SUB RECETA'] || `${type}-${items.indexOf(item)}`;
                    return activeItems[id];
                  })}
                  onChange={(e) => {
                    const newValue = e.target.checked;
                    const newActive = { ...activeItems };
                    items.forEach((item, idx) => {
                      const id = item['CODIGO PROD. TERMINADO'] || item['SUB RECETA'] || `${type}-${idx}`;
                      newActive[id] = newValue;
                    });
                    setActiveItems(newActive);
                  }}
                  style={{ width: '18px', height: '18px', cursor: 'pointer', accentColor: '#801515' }}
                />
              </th>
              <th style={{ padding: '12px 24px', fontSize: '10px', color: '#9CA3AF', fontWeight: '900' }}>DESCRIPCIÓN PROD. TERMINADO</th>
              <th style={{ padding: '12px 24px', fontSize: '10px', color: '#9CA3AF', fontWeight: '900' }}>GRUPO</th>
              <th style={{ padding: '12px 24px', fontSize: '10px', color: '#9CA3AF', fontWeight: '900' }}>FAMILIA</th>
              <th style={{ padding: '12px 24px', fontSize: '10px', color: '#9CA3AF', fontWeight: '900' }}>DESCRIPCIÓN INGREDIENTE</th>
              <th style={{ padding: '12px 24px', fontSize: '10px', color: '#9CA3AF', fontWeight: '900', textAlign: 'center' }}>UNIDAD</th>
              <th style={{ padding: '12px 24px', fontSize: '10px', color: '#9CA3AF', fontWeight: '900', textAlign: 'right' }}>COSTO RECETA</th>
              <th style={{ padding: '12px 24px', fontSize: '10px', color: '#9CA3AF', fontWeight: '900', textAlign: 'right' }}>CANTIDAD</th>
              <th style={{ padding: '12px 24px', fontSize: '10px', color: '#9CA3AF', fontWeight: '900', textAlign: 'right' }}>COSTO INGREDIENTE</th>
            </tr>
          </thead>
          <tbody>
            {items.slice(0, 100).map((item, idx) => {
              const id = item['CODIGO PROD. TERMINADO'] || item['SUB RECETA'] || `${type}-${idx}`;
              const isActive = activeItems[id] || false;
              const costoIngrediente = Number(item['COSTO INGREDIENTES'] || item['COSTO INGREDIENTE'] || 0);
              
              return (
                <tr key={idx} style={{ 
                  borderBottom: '1px solid #F3F4F6',
                  opacity: (viewTab === 'activas' || isActive) ? 1 : 0.4,
                  backgroundColor: (viewTab === 'activas' || isActive) ? 'transparent' : '#F9FAFB',
                  transition: 'all 0.2s'
                }}>
                  <td style={{ padding: '12px 24px' }}>
                    <input 
                      type="checkbox" 
                      checked={isActive} 
                      onChange={() => toggleActive(id)}
                      style={{ 
                        width: '18px', height: '18px', cursor: 'pointer',
                        accentColor: '#801515'
                      }}
                    />
                  </td>
                  <td style={{ padding: '12px 24px', fontSize: '13px', fontWeight: '900', color: (isActive || viewTab === 'activas') ? '#1A1A1A' : '#9CA3AF' }}>
                    {item['PROD. TERMINADO']}
                  </td>
                  <td style={{ padding: '12px 24px', fontSize: '11px', fontWeight: '800', color: (isActive || viewTab === 'activas') ? '#801515' : '#9CA3AF' }}>
                    {item['GRUPO'] || 'OTROS'}
                  </td>
                  <td style={{ padding: '12px 24px', fontSize: '11px', fontWeight: '800', color: (isActive || viewTab === 'activas') ? '#B45309' : '#9CA3AF' }}>
                    {item['FAMILIA'] || 'VARIOS'}
                  </td>
                  <td style={{ padding: '12px 24px', fontSize: '12px', fontWeight: '700', color: (isActive || viewTab === 'activas') ? '#4B5563' : '#9CA3AF' }}>
                    {item['DESCRIPCIÓN INGREDIENTE']}
                  </td>
                  <td style={{ padding: '12px 24px', fontSize: '11px', fontWeight: '800', textAlign: 'center', color: (isActive || viewTab === 'activas') ? '#801515' : '#9CA3AF' }}>
                    {item['UNIDAD MANEJO'] || item['UNIDAD']}
                  </td>
                  <td style={{ padding: '12px 24px', fontSize: '12px', fontWeight: '800', textAlign: 'right', color: (isActive || viewTab === 'activas') ? '#6B7280' : '#9CA3AF' }}>
                    {Number(item['COSTO RECETA']).toFixed(3)}€
                  </td>
                  <td style={{ padding: '12px 24px', fontSize: '12px', fontWeight: '800', textAlign: 'right', color: (isActive || viewTab === 'activas') ? '#1A1A1A' : '#9CA3AF' }}>
                    {Number(item['CANTIDAD']).toFixed(3)}
                  </td>
                  <td style={{ padding: '12px 24px', fontSize: '13px', fontWeight: '900', textAlign: 'right', color: (isActive || viewTab === 'activas') ? '#10B981' : '#9CA3AF' }}>
                    {costoIngrediente.toFixed(3)}€
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
        {items.length > 100 && (
          <div style={{ padding: '10px', textAlign: 'center', fontSize: '11px', color: '#9CA3AF', fontWeight: '700' }}>
            MOSTRANDO PRIMEROS 100 REGISTROS...
          </div>
        )}
      </div>
    </div>
  );

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
      {/* 1. Header and Actions */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
         <div style={{ display: 'flex', gap: '20px', alignItems: 'center' }}>
            <div>
              <h2 style={{ fontSize: '14px', fontWeight: '900', color: '#1A1A1A', marginBottom: '4px' }}>RECETARIO MAESTRO</h2>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: '#801515', fontWeight: '800', fontSize: '12px' }}>
                 <Database size={14} /> {Object.values(activeItems).filter(v => v).length} ACTIVAS
              </div>
            </div>
            
            <div style={{ display: 'flex', backgroundColor: '#F3F4F6', padding: '4px', borderRadius: '12px', gap: '4px' }}>
              <button 
                onClick={() => setViewTab('activas')}
                style={{ 
                  padding: '6px 16px', borderRadius: '10px', border: 'none', fontSize: '10px', fontWeight: '900',
                  backgroundColor: viewTab === 'activas' ? 'white' : 'transparent',
                  color: viewTab === 'activas' ? '#801515' : '#6B7280',
                  cursor: 'pointer', transition: 'all 0.2s', boxShadow: viewTab === 'activas' ? '0 2px 4px rgba(0,0,0,0.05)' : 'none'
                }}
              >
                RECETAS ACTIVAS
              </button>
              <button 
                onClick={() => setViewTab('maestro')}
                style={{ 
                  padding: '6px 16px', borderRadius: '10px', border: 'none', fontSize: '10px', fontWeight: '900',
                  backgroundColor: viewTab === 'maestro' ? 'white' : 'transparent',
                  color: viewTab === 'maestro' ? '#801515' : '#6B7280',
                  cursor: 'pointer', transition: 'all 0.2s', boxShadow: viewTab === 'maestro' ? '0 2px 4px rgba(0,0,0,0.05)' : 'none'
                }}
              >
                RECETARIO MAESTRO (INACTIVAS)
              </button>
            </div>
         </div>
         <button 
           onClick={() => setShowForm(true)}
           style={{ 
            backgroundColor: '#1A1A1A', color: 'white', padding: '10px 20px', 
            borderRadius: '12px', fontSize: '11px', fontWeight: '900', border: 'none',
            display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer'
         }}>
            <Plus size={14} color="#F97316" /> NUEVA RECETA
         </button>
      </div>

      {/* 2. Search & Bulk Actions */}
      <div style={{ display: 'flex', gap: '12px' }}>
         <div style={{ position: 'relative', flex: 1 }}>
            <Search size={18} style={{ position: 'absolute', left: '16px', top: '50%', transform: 'translateY(-50%)', color: '#801515' }} />
            <input 
               type="text" 
               placeholder="BUSCAR RECETA O CÓDIGO EN EL MAESTRO..."
               value={searchTerm}
               onChange={(e) => setSearchTerm(e.target.value)}
               style={{ 
                  width: '100%', padding: '14px 14px 14px 48px', borderRadius: '16px',
                  border: '1px solid #E5E7EB', fontSize: '13px', fontWeight: '700',
                  boxShadow: '0 4px 15px rgba(0,0,0,0.03)', outline: 'none'
               }}
            />
         </div>
         {searchTerm && (
           <button 
             onClick={() => {
               const newActive = { ...activeItems };
               [...filteredRecetas, ...filteredSubRecetas].forEach((item, idx) => {
                 const id = item['CODIGO PROD. TERMINADO'] || item['SUB RECETA'] || `bulk-${idx}`;
                 newActive[id] = true;
               });
               setActiveItems(newActive);
             }}
             style={{ 
               backgroundColor: '#801515', color: 'white', padding: '0 20px', 
               borderRadius: '16px', fontSize: '11px', fontWeight: '900', border: 'none',
               cursor: 'pointer', transition: 'all 0.2s', display: 'flex', alignItems: 'center', gap: '8px'
             }}
           >
              <CheckCircle size={16} /> ACTIVAR RESULTADOS
           </button>
         )}
      </div>

      {loading ? (
        <div style={{ padding: '60px', textAlign: 'center' }}>
          <div style={{ fontSize: '13px', fontWeight: '800', color: '#9CA3AF' }}>SINCRONIZANDO RECETAS DESDE DROPBOX...</div>
        </div>
      ) : (
        <>
          <Table 
            title="RECETAS PROD. TERMINADO" 
            items={filteredRecetas} 
            icon={<BookOpen size={18} color="#801515" />} 
            type="receta"
          />
          <Table 
            title="RECETAS SUB-RECETAS" 
            items={filteredSubRecetas} 
            icon={<ChefHat size={18} color="#F97316" />} 
            type="subreceta"
          />
        </>
      )}

      {showForm && (
        <RecipeForm 
          onClose={() => setShowForm(false)} 
          onSuccess={() => {
            fetchData();
            setShowForm(false);
          }} 
        />
      )}
    </div>
  );
}
