'use client';

import React, { useState, useEffect } from 'react';
import SubPageLayout from '@/components/SubPageLayout';
import { 
  TrendingUp, 
  Target, 
  PieChart, 
  DollarSign, 
  ArrowLeft, 
  Info, 
  HelpCircle, 
  Zap,
  Loader2,
  AlertCircle,
  BarChart3,
  ChevronRight,
  ShieldCheck,
  Star
} from 'lucide-react';
import { useRouter } from 'next/navigation';

export default function RentabilidadDashboard() {
  const router = useRouter();
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetch('/api/analysis/profitability')
      .then(res => {
        if (!res.ok) throw new Error('Error al cargar datos de rentabilidad');
        return res.json();
      })
      .then(json => {
        setData(json);
        setLoading(false);
      })
      .catch(e => {
        console.error(e);
        setError(e.message);
        setLoading(false);
      });
  }, []);

  if (loading) {
    return (
      <SubPageLayout title="Rentabilidad IA">
        <div style={{ height: '60vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: '20px' }}>
          <Loader2 className="animate-spin" size={40} color="#F97316" />
          <p style={{ color: 'rgba(255,255,255,0.4)', fontWeight: '600' }}>Cruzando ventas con costos operativos...</p>
        </div>
      </SubPageLayout>
    );
  }

  if (error) {
    return (
      <SubPageLayout title="Rentabilidad IA">
        <div style={{ padding: '40px', backgroundColor: 'rgba(239, 68, 68, 0.1)', borderRadius: '24px', border: '1px solid rgba(239, 68, 68, 0.2)', color: '#EF4444', textAlign: 'center' }}>
          <AlertCircle size={40} style={{ margin: '0 auto 16px auto' }} />
          <h2 style={{ fontSize: '18px', fontWeight: '800' }}>Error de Conectividad</h2>
          <p style={{ fontSize: '14px', opacity: 0.8 }}>{error}</p>
        </div>
      </SubPageLayout>
    );
  }

  const products = data?.products || [];
  const summary = data?.summary || {};

  const bcgProducts = products.map((p: any) => {
    let type = 'Perro';
    const avgUnits = products.reduce((acc: number, curr: any) => acc + curr.units, 0) / products.length;
    const highVolume = p.units > avgUnits;
    const highMargin = p.marginPercent > 40;

    if (highVolume && highMargin) type = 'Estrella';
    else if (highVolume && !highMargin) type = 'Vaca';
    else if (!highVolume && highMargin) type = 'Interrogante';

    return { ...p, type };
  });

  const stats = [
    { label: 'CONTRIBUCIÓN TOTAL', value: `${summary.totalContribution?.toLocaleString('es-ES')} €`, sub: 'Margen Bruto Acumulado', icon: <TrendingUp size={18} color="#10B981" /> },
    { label: 'GASTOS FIJOS', value: `${summary.totalFixed?.toLocaleString('es-ES')} €`, sub: 'Alquiler + Nómina + Serv.', icon: <Zap size={18} color="#EF4444" /> },
    { label: 'PUNTO DE EQUILIBRIO', value: `${summary.breakEven?.toLocaleString('es-ES')} €`, sub: 'Ventas mínimas requeridas', icon: <Target size={18} color="#F97316" /> },
    { label: 'RECUPERACIÓN IA', value: `${summary.recoveryProfit?.toLocaleString('es-ES')} €`, sub: 'Merma evitada por BakeOS', icon: <ShieldCheck size={18} color="#FFD700" /> },
  ];

  return (
    <SubPageLayout title="Rentabilidad & Portafolio">
      {/* 1. Header Navigation */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '48px' }}>
        <button 
          onClick={() => router.push('/')}
          style={{ display: 'flex', alignItems: 'center', gap: '8px', background: 'none', border: 'none', color: 'rgba(0,0,0,0.4)', cursor: 'pointer', fontSize: '12px', fontWeight: '800' }}
        >
          <ArrowLeft size={16} /> VOLVER AL DASHBOARD
        </button>

        <div style={{ display: 'flex', gap: '16px' }}>
          <button style={{ backgroundColor: 'rgba(255,255,255,0.8)', color: '#2D2926', padding: '12px 24px', borderRadius: '14px', border: '1px solid rgba(0,0,0,0.05)', fontWeight: '800', fontSize: '12px' }}>CONFIGURAR COSTOS</button>
          <button style={{ backgroundColor: '#F97316', color: 'white', padding: '12px 24px', borderRadius: '14px', border: 'none', fontWeight: '800', fontSize: '12px', boxShadow: '0 10px 20px rgba(249, 115, 22, 0.2)' }}>SIMULACIÓN IA</button>
        </div>
      </div>

      {/* 2. KPI Section */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '20px', marginBottom: '40px' }}>
        {stats.map((kpi, idx) => (
          <div key={idx} style={{ backgroundColor: 'rgba(255,255,255,0.6)', backdropFilter: 'blur(30px)', padding: '24px', borderRadius: '32px', border: '1px solid rgba(0,0,0,0.05)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
              <div style={{ fontSize: '10px', fontWeight: '900', color: 'rgba(0,0,0,0.3)', letterSpacing: '2px' }}>{kpi.label}</div>
              <div style={{ width: '32px', height: '32px', borderRadius: '10px', backgroundColor: 'rgba(0,0,0,0.03)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{kpi.icon}</div>
            </div>
            <div style={{ fontSize: '32px', fontWeight: '900', color: '#2D2926', marginBottom: '4px' }}>{kpi.value}</div>
            <div style={{ fontSize: '11px', color: 'rgba(0,0,0,0.4)', fontWeight: '600' }}>{kpi.sub}</div>
          </div>
        ))}
      </div>

      {/* 3. Margen de Contribución Table */}
      <div style={{ backgroundColor: 'rgba(255,255,255,0.5)', backdropFilter: 'blur(40px)', borderRadius: '32px', border: '1px solid rgba(0,0,0,0.05)', overflow: 'hidden', marginBottom: '40px' }}>
        <div style={{ padding: '32px', borderBottom: '1px solid rgba(0,0,0,0.05)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <h3 style={{ fontSize: '16px', fontWeight: '900', letterSpacing: '1px', display: 'flex', alignItems: 'center', gap: '12px', color: '#2D2926' }}>
             <BarChart3 size={20} color="#F97316" /> Desglose de Contribución Marginal
          </h3>
        </div>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
            <thead>
              <tr style={{ backgroundColor: 'rgba(0,0,0,0.02)', borderBottom: '1px solid rgba(0,0,0,0.05)' }}>
                <th style={{ padding: '20px 32px', fontSize: '10px', color: 'rgba(0,0,0,0.4)', fontWeight: '900' }}>PRODUCTO</th>
                <th style={{ padding: '20px 32px', fontSize: '10px', color: 'rgba(0,0,0,0.4)', fontWeight: '900', textAlign: 'right' }}>UNIDADES</th>
                <th style={{ padding: '20px 32px', fontSize: '10px', color: 'rgba(0,0,0,0.4)', fontWeight: '900', textAlign: 'right' }}>COSTO UNIT.</th>
                <th style={{ padding: '20px 32px', fontSize: '10px', color: 'rgba(0,0,0,0.4)', fontWeight: '900', textAlign: 'right' }}>MARGEN %</th>
                <th style={{ padding: '20px 32px', fontSize: '10px', color: 'rgba(0,0,0,0.4)', fontWeight: '900', textAlign: 'right' }}>CONTRIBUCIÓN</th>
                <th style={{ padding: '20px 32px', fontSize: '10px', color: 'rgba(0,0,0,0.4)', fontWeight: '900', textAlign: 'center' }}>ESTADO IA</th>
              </tr>
            </thead>
            <tbody>
              {bcgProducts.map((p: any, idx: number) => (
                <tr key={idx} style={{ borderBottom: '1px solid rgba(0,0,0,0.03)', transition: 'background 0.2s' }} className="table-row">
                  <td style={{ padding: '24px 32px' }}>
                    <div style={{ fontSize: '14px', fontWeight: '800', color: '#2D2926' }}>{p.name}</div>
                  </td>
                  <td style={{ padding: '24px 32px', textAlign: 'right', fontSize: '14px', fontWeight: '600', color: '#2D2926' }}>{p.units}</td>
                  <td style={{ padding: '24px 32px', textAlign: 'right', fontSize: '14px', fontWeight: '600', color: 'rgba(0,0,0,0.5)' }}>{p.unitCost?.toFixed(2)} €</td>
                  <td style={{ padding: '24px 32px', textAlign: 'right', fontSize: '14px', fontWeight: '900', color: p.marginPercent > 50 ? '#10B981' : '#2D2926' }}>{p.marginPercent?.toFixed(1)}%</td>
                  <td style={{ padding: '24px 32px', textAlign: 'right', fontSize: '14px', fontWeight: '900', color: '#10B981' }}>{p.totalContribution?.toLocaleString('es-ES')} €</td>
                  <td style={{ padding: '24px 32px', textAlign: 'center' }}>
                    <span style={{ 
                      fontSize: '10px', 
                      fontWeight: '900', 
                      padding: '6px 12px', 
                      borderRadius: '8px',
                      backgroundColor: p.type === 'Estrella' ? 'rgba(239, 68, 68, 0.1)' : (p.type === 'Vaca' ? 'rgba(16, 185, 129, 0.1)' : (p.type === 'Interrogante' ? 'rgba(249, 115, 22, 0.1)' : 'rgba(0,0,0,0.05)')),
                      color: p.type === 'Estrella' ? '#EF4444' : (p.type === 'Vaca' ? '#10B981' : (p.type === 'Interrogante' ? '#F97316' : 'rgba(0,0,0,0.4)')),
                      border: `1px solid ${p.type === 'Estrella' ? 'rgba(239, 68, 68, 0.2)' : (p.type === 'Vaca' ? 'rgba(16, 185, 129, 0.2)' : (p.type === 'Interrogante' ? 'rgba(249, 115, 22, 0.2)' : 'rgba(0,0,0,0.1)'))}`
                    }}>
                      {p.type.toUpperCase()}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* 4. Strategic Insights Section */}
      <div style={{ backgroundColor: 'rgba(249, 115, 22, 0.03)', padding: '40px', borderRadius: '32px', border: '1px solid rgba(249, 115, 22, 0.1)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '32px' }}>
          <Star size={24} color="#F97316" fill="#F97316" />
          <h3 style={{ fontSize: '18px', fontWeight: '900', margin: 0, color: '#2D2926' }}>Smart Insights de Rentabilidad</h3>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '24px' }}>
          <div style={{ padding: '24px', backgroundColor: 'rgba(255,255,255,0.6)', borderRadius: '20px', border: '1px solid rgba(0,0,0,0.05)' }}>
            <div style={{ fontSize: '13px', fontWeight: '900', color: '#EF4444', marginBottom: '12px', letterSpacing: '1px' }}>PRODUCTOS ESTRELLA</div>
            <p style={{ fontSize: '13px', color: 'rgba(0,0,0,0.5)', lineHeight: '1.6' }}>
              Tu portafolio tiene un <strong>35% de Estrellas</strong>. Mantén el enfoque publicitario en "Choco Chip Classic" para maximizar el flujo de caja sin sacrificar margen.
            </p>
          </div>
          <div style={{ padding: '24px', backgroundColor: 'rgba(255,255,255,0.6)', borderRadius: '20px', border: '1px solid rgba(0,0,0,0.05)' }}>
            <div style={{ fontSize: '13px', fontWeight: '900', color: '#F97316', marginBottom: '12px', letterSpacing: '1px' }}>OPTIMIZACIÓN DE MARGEN</div>
            <p style={{ fontSize: '13px', color: 'rgba(0,0,0,0.5)', lineHeight: '1.6' }}>
              Los productos de tipo <strong>Interrogante</strong> tienen márgenes superiores al 60% pero baja rotación. Inicia campañas de degustación para convertirlos en Estrellas.
            </p>
          </div>
          <div style={{ padding: '24px', backgroundColor: 'rgba(255,255,255,0.6)', borderRadius: '20px', border: '1px solid rgba(0,0,0,0.05)' }}>
            <div style={{ fontSize: '13px', fontWeight: '900', color: '#10B981', marginBottom: '12px', letterSpacing: '1px' }}>FLUJO OPERATIVO</div>
            <p style={{ fontSize: '13px', color: 'rgba(0,0,0,0.5)', lineHeight: '1.6' }}>
              Tus productos <strong>Vaca</strong> están cubriendo el <strong>85% de tus costos fijos</strong>. La estructura es muy estable financieramente.
            </p>
          </div>
        </div>
      </div>

      <style jsx global>{`
        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        .animate-spin {
          animation: spin 1s linear infinite;
        }
        .table-row:hover {
          background-color: rgba(255, 255, 255, 0.03) !important;
        }
      `}</style>
    </SubPageLayout>
  );
}
