'use client';

import React from 'react';
import Header from '@/components/Header';
import { 
  BarChart3, 
  TrendingUp, 
  Calculator, 
  BookOpen, 
  Calendar, 
  ChefHat, 
  Trash2, 
  ShoppingCart, 
  Package, 
  Settings, 
  Camera, 
  Zap, 
  Users, 
  Clock, 
  Activity,
  ArrowRight
} from 'lucide-react';
import { useRouter } from 'next/navigation';
import { translations } from '@/lib/translations';

export default function HomePage() {
  const router = useRouter();
  const [lang, setLang] = React.useState('ES');

  React.useEffect(() => {
    const savedLang = localStorage.getItem('bakeos_lang');
    if (savedLang) setLang(savedLang);

    const handleLangChange = (e: any) => {
      setLang(e.detail);
    };

    window.addEventListener('languageChange', handleLangChange);
    return () => window.removeEventListener('languageChange', handleLangChange);
  }, []);

  const t = translations[lang as keyof typeof translations] || translations.ES;

  const sections = [
    {
      title: 'ANÁLISIS PREDICTIVO',
      items: [
        { label: 'SEGUIMIENTO DE VENTAS', href: "/HUB?tab=ventas", icon: <TrendingUp size={18} /> },
        { label: 'CUMPLIMIENTO DE PLAN', href: "/HUB?tab=analisis", icon: <Activity size={18} /> },
        { label: 'NORMALIZADOR DE EVENTOS', href: "/HUB?tab=eventos", icon: <Settings size={18} /> },
        { label: 'RENTABILIDAD Y COSTOS', href: "/HUB?tab=costos", icon: <Calculator size={18} /> }
      ]
    },
    {
      title: 'OPERACIONES Y CIERRE',
      items: [
        { label: 'PLANIFICADOR SEMANAL', href: "/HUB?tab=planificacion", icon: <Calendar size={18} /> },
        { label: 'INVENTARIO DE CIERRE', href: "/HUB?tab=inventarios", icon: <Package size={18} /> },
        { label: 'REGISTRO DE MERMA IA', href: "/HUB?tab=merma", icon: <Trash2 size={18} /> },
        { label: 'PRODUCCIÓN DIARIA', href: "/HUB?tab=planificacion", icon: <ChefHat size={18} /> }
      ]
    },
    {
      title: 'BAKEOS IA VISION',
      items: [
        { label: 'ESCÁNER DE INVENTARIO', href: "/HUB?tab=escanner", icon: <Camera size={18} /> },
        { label: 'CONTROL DE CALIDAD IA', href: "/HUB?tab=escanner", icon: <Zap size={18} /> },
        { label: 'PEDIDOS SUGERIDOS', href: "/HUB?tab=planificacion", icon: <Clock size={18} /> }
      ]
    },
    {
      title: 'SISTEMA Y EQUIPO',
      items: [
        { label: 'CARGA DE DATOS (ADMIN)', href: "/HUB?tab=admin", icon: <Settings size={18} /> },
        { label: 'GESTIÓN DE RECETAS', href: "/HUB?tab=recetas", icon: <BookOpen size={18} /> },
        { label: 'EQUIPO HUMANO', href: "/HUB?tab=planificacion", icon: <Users size={18} /> }
      ]
    }
  ];

  return (
    <div className="fade-in" style={{ 
      minHeight: '100vh', 
      width: '100%',
      padding: '140px 5% 60px 5%',
      display: 'flex',
      flexDirection: 'column',
      backgroundColor: '#EDE8D0', 
      position: 'relative',
      overflowX: 'hidden'
    }}>
      <Header />

      <div style={{
        maxWidth: '1600px',
        margin: '0 auto',
        width: '100%'
      }}>
        {/* Cuerpo del Panel: Título */}
        <div style={{ marginBottom: '60px' }}>
          <h1 style={{ 
            fontSize: '42px', 
            fontWeight: '900', 
            color: '#2D2926', 
            marginBottom: '12px', 
            letterSpacing: '-1px',
            fontFamily: '"Outfit", sans-serif'
          }}>
            {t.TITLE}
          </h1>
          <p style={{ color: 'rgba(0,0,0,0.5)', fontSize: '16px', fontWeight: '500', letterSpacing: '0.5px' }}>
            {t.SUBTITLE}
          </p>
        </div>

        {/* 4 Bloques Principales */}
        <div style={{ 
          display: 'grid', 
          gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', 
          gap: '32px',
          width: '100%'
        }}>
          {sections.map((section, idx) => (
            <div key={idx} style={{ 
              backgroundColor: 'rgba(255, 255, 255, 0.7)', 
              padding: '40px', 
              borderRadius: '32px',
              border: '1px solid rgba(0, 0, 0, 0.05)',
              display: 'flex', 
              flexDirection: 'column', 
              gap: '24px',
              backdropFilter: 'blur(16px)',
              boxShadow: '0 20px 40px rgba(0,0,0,0.05)',
              transition: 'transform 0.4s ease'
            }} className="section-card">
              {/* Títulos en mayúsculas amarillas/doradas */}
              <h2 style={{ 
                fontSize: '11px', 
                fontWeight: '900', 
                color: '#801515', 
                letterSpacing: '4px',
                textTransform: 'uppercase',
                margin: 0,
                opacity: 0.8
              }}>
                {section.title}
              </h2>
              
              {/* Estilo de Botones: Rectángulos con bordes redondeados */}
              <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                {section.items.map((item, i) => (
                  <button 
                    key={i}
                    onClick={() => router.push(item.href)}
                    style={{
                      backgroundColor: 'rgba(255, 255, 255, 0.9)', 
                      border: '1px solid rgba(0, 0, 0, 0.03)',
                      padding: '18px 24px',
                      borderRadius: '16px',
                      color: '#2D2926',
                      fontSize: '14px',
                      fontWeight: '700',
                      cursor: 'pointer',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
                      textAlign: 'left',
                      boxShadow: '0 2px 8px rgba(0,0,0,0.02)'
                    }}
                    onMouseOver={(e) => {
                      e.currentTarget.style.backgroundColor = 'white';
                      e.currentTarget.style.borderColor = 'rgba(128, 21, 21, 0.2)';
                      e.currentTarget.style.transform = 'translateX(4px)';
                      e.currentTarget.style.boxShadow = '0 5px 15px rgba(0,0,0,0.05)';
                    }}
                    onMouseOut={(e) => {
                      e.currentTarget.style.backgroundColor = 'rgba(255, 255, 255, 0.9)';
                      e.currentTarget.style.borderColor = 'rgba(0, 0, 0, 0.03)';
                      e.currentTarget.style.transform = 'translateX(0)';
                      e.currentTarget.style.boxShadow = '0 2px 8px rgba(0,0,0,0.02)';
                    }}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
                      <span style={{ color: '#F97316', display: 'flex' }}>{item.icon}</span>
                      {item.label}
                    </div>
                    <ArrowRight size={14} style={{ opacity: 0.3 }} />
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      <style jsx global>{`
        @import url('https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;800;900&display=swap');
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .fade-in {
          animation: fadeIn 0.8s cubic-bezier(0.16, 1, 0.3, 1) forwards;
        }
        .section-card:hover {
          transform: translateY(-5px);
          border-color: rgba(255, 215, 0, 0.2);
        }
      `}</style>
    </div>
  );
}
