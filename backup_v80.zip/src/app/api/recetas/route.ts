import { NextRequest, NextResponse } from 'next/server';

export const runtime = 'edge';
export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest, context: any) {
  const { DB } = (context as any).env || (globalThis as any).process?.env || {};
  
  // Note: In Next.js on Cloudflare, context.env is where bindings are.
  // If running locally with wrangler pages dev, it might be different.
  const db = DB;

  if (!db) {
    return NextResponse.json({ error: "Database binding not found" }, { status: 500 });
  }

  try {
    const recipes = await db.prepare("SELECT * FROM historical_recipes ORDER BY name ASC").all();
    const ingredients = await db.prepare("SELECT * FROM historical_recipe_ingredients").all();

    // Group ingredients by recipe_id
    const ingredientsByRecipe = ingredients.results.reduce((acc: any, ing: any) => {
      if (!acc[ing.recipe_id]) acc[ing.recipe_id] = [];
      acc[ing.recipe_id].push(ing);
      return acc;
    }, {});

    const fullRecipes = recipes.results.map((recipe: any) => ({
      ...recipe,
      ingredients: ingredientsByRecipe[recipe.id] || []
    }));

    return NextResponse.json(fullRecipes);
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest, context: any) {
  const { DB } = (context as any).env || {};
  const db = DB;

  if (!db) {
    return NextResponse.json({ error: "Database binding not found" }, { status: 500 });
  }

  try {
    const body = await req.json();
    const { micros_id, name, total_cost, ingredients } = body;

    if (!name) {
      return NextResponse.json({ error: "Recipe name is required" }, { status: 400 });
    }

    // Start a transaction-like batch
    const result = await db.prepare("INSERT INTO historical_recipes (micros_id, name, total_cost) VALUES (?, ?, ?) RETURNING id")
      .bind(micros_id, name, total_cost)
      .first();

    const recipeId = result.id;

    if (ingredients && ingredients.length > 0) {
      const statements = ingredients.map((ing: any) => 
        db.prepare("INSERT INTO historical_recipe_ingredients (recipe_id, ingredient_name, is_sub_recipe, unit, quantity_dirty, quantity_clean, cost_dirty, cost_clean) VALUES (?, ?, ?, ?, ?, ?, ?, ?)")
          .bind(recipeId, ing.ingredient_name, ing.is_sub_recipe ? 1 : 0, ing.unit, ing.quantity_dirty, ing.quantity_clean, ing.cost_dirty, ing.cost_clean)
      );
      await db.batch(statements);
    }

    return NextResponse.json({ success: true, id: recipeId });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
