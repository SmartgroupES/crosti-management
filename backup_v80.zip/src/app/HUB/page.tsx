'use client';

import React, { useState, useEffect } from 'react';
import Header from '@/components/Header';
import { 
  TrendingUp, 
  Trash2, 
  Package, 
  ShoppingCart, 
  Calendar, 
  BookOpen, 
  DollarSign,
  ChevronDown,
  LayoutDashboard
} from 'lucide-react';

import { useSearchParams } from 'next/navigation';

// Modules (To be populated with existing logic)
import VentasView from './views/VentasView';
import RentabilidadView from './views/RentabilidadView';
import RecetasView from './views/RecetasView';
import PlanificacionView from './views/PlanificacionView';
import AdminUploadView from './views/AdminUploadView';
import EventNormalizerView from './views/EventNormalizerView';
import VentasView from './views/VentasView';

type TabId = 'ventas' | 'merma' | 'inventarios' | 'pedidos' | 'planificacion' | 'recetas' | 'costos' | 'admin' | 'eventos' | 'analisis' | 'escanner';

export default function HubPage() {
  const searchParams = useSearchParams();
  const initialTab = searchParams.get('tab') as TabId || 'ventas';
  const [activeTab, setActiveTab] = useState<TabId>(initialTab);
  const [location, setLocation] = useState('POBLENOU | BCN');
  const [period, setPeriod] = useState('MES ACTUAL');

  useEffect(() => {
    const tab = searchParams.get('tab') as TabId;
    if (tab) setActiveTab(tab);
  }, [searchParams]);

  const tabs = [
    { id: 'ventas', label: 'VENTAS', icon: TrendingUp },
    { id: 'analisis', label: 'ANÁLISIS PREDICTIVO', icon: Activity },
    { id: 'eventos', label: 'EVENTOS', icon: Settings },
    { id: 'planificacion', label: 'PLANIFICACIÓN', icon: Calendar },
    { id: 'recetas', label: 'RECETAS', icon: BookOpen },
    { id: 'costos', label: 'COSTOS', icon: DollarSign },
    { id: 'inventarios', label: 'INVENTARIOS', icon: Package },
    { id: 'escanner', label: 'ESCÁNER IA', icon: Camera },
    { id: 'admin', label: 'ADMIN / CARGA', icon: ShieldCheck },
  ];

  return (
    <div style={{ backgroundColor: '#FAF9F6', minHeight: '100vh', paddingBottom: '40px' }}>
      <Header />

      <main style={{ padding: '24px 40px' }}>
        {/* 1. Global Filters Bar */}
        <div style={{ 
          display: 'flex', 
          justifyContent: 'space-between', 
          alignItems: 'center',
          backgroundColor: 'white',
          padding: '16px 24px',
          borderRadius: '20px',
          border: '1px solid #E5E7EB',
          marginBottom: '20px',
          boxShadow: '0 4px 6px rgba(0,0,0,0.02)'
        }}>
          <div style={{ display: 'flex', gap: '16px', alignItems: 'center' }}>
            {/* Location Selector */}
            <div style={{ position: 'relative' }}>
              <div style={{ fontSize: '10px', fontWeight: '900', color: '#9CA3AF', marginBottom: '4px' }}>SEDE / LOCAL</div>
              <button style={{ 
                display: 'flex', alignItems: 'center', gap: '8px', padding: '8px 16px', 
                backgroundColor: '#F3F4F6', border: 'none', borderRadius: '12px',
                fontSize: '13px', fontWeight: '800', cursor: 'pointer'
              }}>
                {location} <ChevronDown size={14} />
              </button>
            </div>

            {/* Period Selector */}
            <div style={{ position: 'relative' }}>
              <div style={{ fontSize: '10px', fontWeight: '900', color: '#9CA3AF', marginBottom: '4px' }}>PERIODO</div>
              <button style={{ 
                display: 'flex', alignItems: 'center', gap: '8px', padding: '8px 16px', 
                backgroundColor: '#F3F4F6', border: 'none', borderRadius: '12px',
                fontSize: '13px', fontWeight: '800', cursor: 'pointer'
              }}>
                {period} <ChevronDown size={14} />
              </button>
            </div>
          </div>

          <button style={{ 
            backgroundColor: '#1A1A1A', color: 'white', padding: '12px 24px', 
            borderRadius: '14px', fontSize: '13px', fontWeight: '900', border: 'none',
            display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer',
            boxShadow: '0 10px 20px rgba(0,0,0,0.1)'
          }}>
            <LayoutDashboard size={16} color="#F97316" />
            IR AL PLANIFICADOR
          </button>
        </div>

        {/* 2. Tab Navigation (Dark Glass Style) */}
        <div style={{ 
          display: 'flex', 
          gap: '8px', 
          backgroundColor: '#1A1A1A',
          padding: '8px',
          borderRadius: '20px',
          marginBottom: '30px',
          boxShadow: '0 20px 40px rgba(0,0,0,0.15)',
          overflowX: 'auto',
          whiteSpace: 'nowrap'
        }}>
          {tabs.map((tab) => {
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as TabId)}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '10px',
                  padding: '12px 24px',
                  borderRadius: '14px',
                  border: isActive ? 'none' : '1px solid rgba(255,255,255,0.1)',
                  backgroundColor: isActive ? '#FAF9F6' : 'transparent',
                  color: isActive ? '#1A1A1A' : 'rgba(255,255,255,0.6)',
                  fontSize: '12px',
                  fontWeight: '900',
                  cursor: 'pointer',
                  transition: 'all 0.2s cubic-bezier(0.4, 0, 0.2, 1)',
                  flexShrink: 0
                }}
              >
                <tab.icon size={16} color={isActive ? '#F97316' : 'inherit'} />
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* 3. Centralized View Container */}
        <div style={{ 
          transition: 'all 0.3s ease-in-out'
        }}>
          {activeTab === 'ventas' && <VentasView />}
          {activeTab === 'recetas' && <RecetasView />}
          {activeTab === 'costos' && <RentabilidadView />}
          {activeTab === 'planificacion' && <PlanificacionView />}
          {activeTab === 'admin' && <AdminUploadView />}
          {activeTab === 'eventos' && <EventNormalizerView />}
          
          {/* Placeholder for others */}
          {['merma', 'inventarios', 'pedidos', 'analisis', 'escanner'].includes(activeTab) && (
            <div style={{ 
              backgroundColor: 'white', padding: '100px', borderRadius: '32px', 
              textAlign: 'center', border: '1px solid #E5E7EB'
            }}>
              <LayoutDashboard size={48} color="#E5E7EB" style={{ marginBottom: '20px' }} />
              <h2 style={{ fontSize: '20px', fontWeight: '900', color: '#2D2926' }}>
                MÓDULO DE {activeTab.toUpperCase()} EN DESARROLLO
              </h2>
              <p style={{ color: '#9CA3AF', fontSize: '14px', marginTop: '8px' }}>
                Sincronizando con algoritmos del Proyecto Nelson MK-2026
              </p>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
    </div>
  );
}
