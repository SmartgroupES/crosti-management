'use client';

import React, { useState, useEffect } from 'react';
import { 
  BookOpen, 
  Search, 
  Plus, 
  ChevronRight,
  Flame,
  Clock,
  Layers
} from 'lucide-react';

export default function RecetasView() {
  const [recipes, setRecipes] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/escandallos')
      .then(res => res.json())
      .then(json => {
        setRecipes(json);
        setLoading(false);
      })
      .catch(e => console.error(e));
  }, []);

  if (loading) return <div style={{ padding: '60px', textAlign: 'center', fontWeight: '800', color: '#9CA3AF' }}>DESPLEGANDO RECETARIO MAESTRO...</div>;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '30px' }}>
      {/* 1. Search and Add */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
         <div style={{ position: 'relative', width: '400px' }}>
            <Search size={18} style={{ position: 'absolute', left: '16px', top: '50%', transform: 'translateY(-50%)', color: '#9CA3AF' }} />
            <input 
               type="text" 
               placeholder="BUSCAR RECETA O PRODUCTO..."
               style={{ 
                  width: '100%', padding: '14px 14px 14px 48px', borderRadius: '16px',
                  border: '1px solid #E5E7EB', fontSize: '13px', fontWeight: '700'
               }}
            />
         </div>
         <button style={{ 
            backgroundColor: '#1A1A1A', color: 'white', padding: '14px 24px', 
            borderRadius: '16px', fontSize: '12px', fontWeight: '900', border: 'none',
            display: 'flex', alignItems: 'center', gap: '10px', cursor: 'pointer'
         }}>
            <Plus size={16} color="#F97316" /> NUEVA RECETA
         </button>
      </div>

      {/* 2. Recipe Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '25px' }}>
         {recipes.map((recipe, idx) => (
            <div key={idx} style={{ 
               backgroundColor: 'white', borderRadius: '24px', border: '1px solid #E5E7EB',
               padding: '24px', cursor: 'pointer', transition: 'all 0.2s',
               boxShadow: '0 4px 6px rgba(0,0,0,0.01)'
            }}>
               <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '20px' }}>
                  <div style={{ 
                     width: '48px', height: '48px', borderRadius: '12px', 
                     backgroundColor: '#FAF9F6', display: 'flex', alignItems: 'center', justifyContent: 'center'
                  }}>
                     <BookOpen size={24} color="#F97316" />
                  </div>
                  <div style={{ textAlign: 'right' }}>
                     <div style={{ fontSize: '10px', fontWeight: '900', color: '#9CA3AF' }}>COSTO / UD</div>
                     <div style={{ fontSize: '16px', fontWeight: '900', color: '#1A1A1A' }}>{recipe.total_cost.toFixed(2)}€</div>
                  </div>
               </div>
               
               <h3 style={{ fontSize: '16px', fontWeight: '900', color: '#2D2926', marginBottom: '8px' }}>{recipe.name.toUpperCase()}</h3>
               <div style={{ display: 'flex', gap: '12px', marginBottom: '20px' }}>
                  <span style={{ fontSize: '11px', color: '#6B7280', fontWeight: '700', display: 'flex', alignItems: 'center', gap: '4px' }}>
                     <Clock size={12} /> 25 MIN
                  </span>
                  <span style={{ fontSize: '11px', color: '#6B7280', fontWeight: '700', display: 'flex', alignItems: 'center', gap: '4px' }}>
                     <Flame size={12} /> 180ºC
                  </span>
               </div>

               <div style={{ 
                  borderTop: '1px solid #F3F4F6', paddingTop: '16px', 
                  display: 'flex', justifyContent: 'space-between', alignItems: 'center'
               }}>
                  <div style={{ fontSize: '11px', fontWeight: '800', color: '#F97316' }}>GESTIONAR ESCANDALLO</div>
                  <ChevronRight size={16} color="#9CA3AF" />
               </div>
            </div>
         ))}
      </div>
    </div>
  );
}
