'use client';

import React, { useState, useEffect } from 'react';
import { 
  TrendingUp, 
  ArrowUpRight, 
  ArrowDownRight, 
  Download, 
  Calendar,
  Filter
} from 'lucide-react';

export default function VentasView() {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/sales/hourly')
      .then(res => res.json())
      .then(json => {
        setData(json);
        setLoading(false);
      })
      .catch(e => console.error(e));
  }, []);

  if (loading) return <div style={{ padding: '60px', textAlign: 'center', fontWeight: '800', color: '#9CA3AF' }}>SINCRONIZANDO DATOS DE VENTAS...</div>;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '30px' }}>
      {/* 1. KPIs */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '20px' }}>
        {[
          { label: 'VENTA HOY', val: data?.todaySales?.total || 0, color: '#F97316' },
          { label: 'SEMANA ACTUAL', val: data?.weekSales?.total || 0, color: '#F97316' },
          { label: 'MES EN CURSO', val: data?.monthSales?.total || 0, color: '#F97316' },
          { label: 'CIERRE ANUAL', val: (data?.monthSales?.total || 0) * 12, color: '#F97316' },
        ].map((kpi, idx) => (
          <div key={idx} style={{ 
            backgroundColor: kpi.color, color: 'white', padding: '30px', borderRadius: '32px',
            boxShadow: '0 10px 25px rgba(249, 115, 22, 0.2)', position: 'relative', overflow: 'hidden'
          }}>
            <div style={{ fontSize: '11px', fontWeight: '900', opacity: 0.8, letterSpacing: '1px' }}>{kpi.label}</div>
            <div style={{ fontSize: '32px', fontWeight: '900', marginTop: '12px' }}>{kpi.val.toLocaleString('es-ES')}€</div>
            <TrendingUp size={64} style={{ position: 'absolute', bottom: '-15px', right: '-15px', opacity: 0.1 }} />
          </div>
        ))}
      </div>

      {/* 2. Chart Section (Placeholder for Chart.js) */}
      <div style={{ 
        backgroundColor: '#D1D5DB', minHeight: '400px', borderRadius: '40px', padding: '40px',
        display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center',
        border: '1px solid #E5E7EB', position: 'relative'
      }}>
        <div style={{ position: 'absolute', top: '30px', left: '40px' }}>
          <h2 style={{ fontSize: '24px', fontWeight: '900', color: 'white' }}>Rendimiento Últimos 3 Meses</h2>
          <p style={{ fontSize: '12px', color: 'rgba(255,255,255,0.7)', fontWeight: '700' }}>Comparativa de volumen y ticket medio</p>
        </div>
        <div style={{ position: 'absolute', top: '30px', right: '40px' }}>
           <span style={{ fontSize: '10px', fontWeight: '900', color: '#F97316', letterSpacing: '1px' }}>DATA_SYNC_ACTIVE</span>
        </div>
        
        <TrendingUp size={120} color="white" style={{ opacity: 0.3 }} />
        <div style={{ color: 'white', fontWeight: '900', fontSize: '14px', marginTop: '20px' }}>MOTOR DE GRÁFICOS CARGANDO...</div>
      </div>

      {/* 3. Detail Table */}
      <div style={{ backgroundColor: 'white', borderRadius: '32px', border: '1px solid #E5E7EB', overflow: 'hidden' }}>
         <div style={{ padding: '24px 32px', borderBottom: '1px solid #F3F4F6', display: 'flex', justifyContent: 'space-between' }}>
            <h3 style={{ fontSize: '16px', fontWeight: '900' }}>Top Ventas por Categoría</h3>
            <button style={{ fontSize: '12px', fontWeight: '900', color: '#F97316', display: 'flex', alignItems: 'center', gap: '6px', backgroundColor: 'transparent', border: 'none' }}>
               <Download size={14} /> EXPORTAR CSV
            </button>
         </div>
         <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
               <tr style={{ backgroundColor: '#F9FAFB', textAlign: 'left' }}>
                  <th style={{ padding: '20px 32px', fontSize: '11px', color: '#9CA3AF', fontWeight: '900' }}>CATEGORÍA</th>
                  <th style={{ padding: '20px 32px', fontSize: '11px', color: '#9CA3AF', fontWeight: '900', textAlign: 'center' }}>UNIDADES</th>
                  <th style={{ padding: '20px 32px', fontSize: '11px', color: '#9CA3AF', fontWeight: '900', textAlign: 'right' }}>TOTAL FACTURADO</th>
               </tr>
            </thead>
            <tbody>
               {data?.monthlyStats?.map((stat: any, idx: number) => (
                  <tr key={idx} style={{ borderBottom: '1px solid #F3F4F6' }}>
                     <td style={{ padding: '24px 32px', fontSize: '14px', fontWeight: '900' }}>REPOSTERÍA ARTESANAL</td>
                     <td style={{ padding: '24px 32px', textAlign: 'center', fontSize: '14px', fontWeight: '700' }}>{stat.sales}</td>
                     <td style={{ padding: '24px 32px', textAlign: 'right', fontSize: '14px', fontWeight: '900', color: '#F97316' }}>{stat.sales.toLocaleString('es-ES')}€</td>
                  </tr>
               ))}
            </tbody>
         </table>
      </div>
    </div>
  );
}
