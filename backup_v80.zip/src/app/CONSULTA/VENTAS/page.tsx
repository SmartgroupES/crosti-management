'use client';

import React, { useState, useEffect } from 'react';
import SubPageLayout from '@/components/SubPageLayout';
import { 
  Download, 
  FileText, 
  Loader2,
  ChevronLeft,
  TrendingUp,
  CreditCard,
  Percent
} from 'lucide-react';
import { useRouter } from 'next/navigation';

const SALES_API_ENDPOINT = '/api/sales/hourly';

export default function VentasPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState<any>(null);
  const [hoveredBar, setHoveredBar] = useState<number | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch(SALES_API_ENDPOINT);
        const json = await response.json();
        setData(json);
      } catch (error) {
        console.error('Error fetching sales data:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  const handleExport = async (format: 'xlsx' | 'pdf') => {
    try {
      const response = await fetch('/api/export', {
        method: 'POST',
        body: JSON.stringify({
          format,
          data: data?.exportData || [],
          type: 'Ventas_Diarias_90d',
          location: 'Velazquez'
        }),
        headers: { 'Content-Type': 'application/json' }
      });
      
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `Ventas_Crosti_Velazquez_90d_${new Date().toISOString().split('T')[0]}.${format}`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Error exporting:', error);
    }
  };

  if (loading) {
    return (
      <SubPageLayout title="Seguimiento de Ventas">
        <div style={{ height: '50vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: '20px' }}>
          <Loader2 className="animate-spin" size={40} color="#F97316" />
          <p style={{ color: 'rgba(255,255,255,0.4)', fontWeight: '600' }}>Cargando analítica de ventas...</p>
        </div>
      </SubPageLayout>
    );
  }

  const kpis = [
    { label: 'Venta Hoy', value: `${Math.round(data?.kpis?.today || 0).toLocaleString()}€` },
    { label: 'Semana Actual', value: `${Math.round(data?.kpis?.week || 0).toLocaleString()}€` },
    { label: 'Mes en Curso', value: `${Math.round(data?.kpis?.month || 0).toLocaleString()}€` },
    { label: 'Cierre Anual', value: `${Math.round(data?.kpis?.projectedAnnual || 0).toLocaleString()}€` },
  ];

  return (
    <SubPageLayout title="Seguimiento de Ventas">
      {/* 1. Cabecera con Botones de Exportación */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '40px' }}>
        <button 
          onClick={() => router.push('/')}
          style={{ display: 'flex', alignItems: 'center', gap: '8px', background: 'none', border: 'none', color: 'rgba(255,255,255,0.4)', cursor: 'pointer', fontSize: '12px', fontWeight: '800' }}
        >
          <ChevronLeft size={16} /> VOLVER AL PANEL
        </button>

        <div style={{ display: 'flex', gap: '12px' }}>
          <button 
            onClick={() => handleExport('xlsx')}
            style={{ width: '44px', height: '44px', borderRadius: '50%', backgroundColor: 'rgba(16, 185, 129, 0.1)', border: '1px solid rgba(16, 185, 129, 0.2)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}
          >
            <Download size={20} color="#10B981" />
          </button>
          <button 
            onClick={() => handleExport('pdf')}
            style={{ width: '44px', height: '44px', borderRadius: '50%', backgroundColor: 'rgba(239, 68, 68, 0.1)', border: '1px solid rgba(239, 68, 68, 0.2)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}
          >
            <FileText size={20} color="#EF4444" />
          </button>
        </div>
      </div>

      {/* 2. KPIs (Globos Naranja) */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '20px', marginBottom: '60px' }}>
        {kpis.map((kpi, idx) => (
          <div key={idx} style={{ 
            backgroundColor: '#F97316', 
            padding: '24px', 
            borderRadius: '24px', 
            boxShadow: '0 15px 30px rgba(249, 115, 22, 0.3)',
            textAlign: 'center',
            transition: 'transform 0.3s ease'
          }} onMouseOver={(e) => e.currentTarget.style.transform = 'translateY(-5px)'} onMouseOut={(e) => e.currentTarget.style.transform = 'translateY(0)'}>
            <div style={{ fontSize: '10px', fontWeight: '900', color: 'rgba(255,255,255,0.7)', textTransform: 'uppercase', letterSpacing: '2px', marginBottom: '8px' }}>
              {kpi.label}
            </div>
            <div style={{ fontSize: '28px', fontWeight: '900', color: 'white' }}>
              {kpi.value}
            </div>
          </div>
        ))}
      </div>

      {/* 3. Gráfico Principal (Contenedor de Cristal) */}
      <div style={{ 
        backgroundColor: 'rgba(0, 0, 0, 0.3)', 
        backdropFilter: 'blur(30px)',
        padding: '60px', 
        borderRadius: '32px', 
        border: '1px solid rgba(255, 255, 255, 0.1)',
        marginBottom: '60px',
        boxShadow: '0 25px 50px rgba(0,0,0,0.3)',
        position: 'relative'
      }}>
        <div style={{ marginBottom: '40px', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
          <div>
            <h2 style={{ fontSize: '20px', fontWeight: '900', color: 'white', margin: 0 }}>Rendimiento Últimos 3 Meses</h2>
            <p style={{ fontSize: '12px', color: 'rgba(255,255,255,0.4)', marginTop: '6px' }}>Comparativa de volumen y ticket medio</p>
          </div>
          <div style={{ fontSize: '10px', fontWeight: '900', color: '#F97316', letterSpacing: '1px' }}>DATA_SYNC_ACTIVE</div>
        </div>

        <div style={{ height: '300px', display: 'flex', alignItems: 'flex-end', justifyContent: 'space-around', gap: '30px' }}>
          {(data?.monthly || []).map((monthData: any, i: number) => {
            const max = Math.max(...data.monthly.map((d: any) => d.sales));
            const height = (monthData.sales / max) * 260;
            return (
              <div 
                key={i} 
                onMouseEnter={() => setHoveredBar(i)}
                onMouseLeave={() => setHoveredBar(null)}
                style={{ flex: '1', maxWidth: '120px', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '16px', cursor: 'pointer', position: 'relative' }}
              >
                {/* Tooltip Pill */}
                {hoveredBar === i && (
                  <div style={{ 
                    position: 'absolute', 
                    top: '-100px', 
                    backgroundColor: '#FF8000', 
                    padding: '16px', 
                    borderRadius: '16px', 
                    zIndex: 10, 
                    boxShadow: '0 10px 30px rgba(255, 128, 0, 0.4)',
                    minWidth: '160px',
                    animation: 'slideUp 0.3s ease-out'
                  }}>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '11px', fontWeight: '800' }}>
                        <TrendingUp size={14} /> Venta: {Math.round(monthData.sales).toLocaleString()}€
                      </div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '11px', fontWeight: '800' }}>
                        <CreditCard size={14} /> Ticket: {Math.round(monthData.avgTicket).toLocaleString()}€
                      </div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '11px', fontWeight: '800', color: monthData.growth >= 0 ? '#10B981' : '#EF4444' }}>
                        <Percent size={14} /> Crec: {monthData.growth}%
                      </div>
                    </div>
                    {/* Arrow */}
                    <div style={{ position: 'absolute', bottom: '-8px', left: '50%', transform: 'translateX(-50%)', borderLeft: '8px solid transparent', borderRight: '8px solid transparent', borderTop: '8px solid #FF8000' }} />
                  </div>
                )}

                <div style={{ 
                  width: '100%', 
                  height: `${height || 10}px`, 
                  backgroundColor: 'rgba(96, 16, 16, 0.8)', // Rojo Borgoña 80%
                  border: '2px solid #FFD700', // Bordes Oro
                  borderRadius: '12px 12px 4px 4px',
                  transition: 'all 0.3s cubic-bezier(0.16, 1, 0.3, 1)',
                  boxShadow: hoveredBar === i ? '0 0 20px rgba(255, 215, 0, 0.4)' : 'none'
                }} />
                <span style={{ fontSize: '11px', fontWeight: '900', color: hoveredBar === i ? 'white' : 'rgba(255,255,255,0.3)', letterSpacing: '1px' }}>{monthData.month}</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* 4. Top Five List */}
      <div style={{ maxWidth: '800px' }}>
        <h2 style={{ fontSize: '14px', fontWeight: '900', color: '#F97316', marginBottom: '32px', letterSpacing: '3px', textTransform: 'uppercase' }}>
          Top 5 Best Sellers
        </h2>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          {(data?.topProducts || []).map((p: any, idx: number) => (
            <div key={idx} style={{ 
              display: 'flex', 
              alignItems: 'center', 
              gap: '32px', 
              padding: '24px', 
              backgroundColor: 'rgba(0,0,0,0.2)', 
              borderRadius: '20px',
              border: '1px solid rgba(255,255,255,0.05)',
              transition: 'transform 0.2s'
            }} className="top-item">
              <span style={{ fontSize: '16px', fontWeight: '900', color: '#F97316', width: '20px' }}>{idx + 1}</span>
              <span style={{ flex: 1, fontSize: '14px', fontWeight: '800' }}>{p.name}</span>
              
              <div style={{ width: '150px', height: '4px', backgroundColor: 'rgba(255,255,255,0.05)', borderRadius: '10px', overflow: 'hidden' }}>
                <div style={{ width: `${p.percent}%`, height: '100%', backgroundColor: '#EF4444', borderRadius: '10px', opacity: 0.8 }} />
              </div>
              
              <span style={{ fontSize: '16px', fontWeight: '900', width: '100px', textAlign: 'right', letterSpacing: '-0.5px' }}>{p.amount}</span>
            </div>
          ))}
        </div>
      </div>

      <style jsx global>{`
        @keyframes slideUp {
          from { opacity: 0; transform: translate(-50%, 10px); }
          to { opacity: 1; transform: translate(-50%, 0); }
        }
        .animate-spin {
          animation: spin 1s linear infinite;
        }
        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        .top-item:hover {
          transform: translateX(10px);
          background-color: rgba(0,0,0,0.3);
          border-color: rgba(249, 115, 22, 0.2);
        }
      `}</style>
    </SubPageLayout>
  );
}
